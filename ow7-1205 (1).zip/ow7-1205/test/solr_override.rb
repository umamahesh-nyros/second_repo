# Prevent Sunspot from making real solr requests
class RSolr::Client
  def request(path, params={}, *extra)
    # do nothing
  end  
end
