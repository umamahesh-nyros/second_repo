require File.dirname(__FILE__) + '/../test_helper'

class ArabicCandidatesControllerTest < ActionController::TestCase
  should_require_no_user_for(:get => [:new], :post => [:create])
end
