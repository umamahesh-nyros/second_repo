require File.dirname(__FILE__) + '/../test_helper'

class ApplicationsControllerTest < ActionController::TestCase
  should_require_employer_for(:get => [:index],
    :put => [:short_list, :unshort_list, :reject, :unreject, 
            :mass_short_list, :mass_unshort_list, :mass_reject, :mass_unreject])
            
  context "An Employer having job applications" do
      
    setup do
      @employer = Factory.create(:employer)
      @filters = {
        :degree_language_class_id => Candidate::DegreeLanguageClasses[:en_bachelor],
        :saudi_status_ids => [Candidate::SaudiStatus[:saudi]],
        :gender_ids => [Candidate::Gender[:female]],
        :job_mixing_ids => [Candidate::MixingLevels[:unsegregated_conservative]],
      }.with_indifferent_access

      @job = Factory.build(:job, :filters => @filters, :employer => @employer)
      @vacancy = Vacancy.new :city => City.saudi.rand
      @job.vacancies << @vacancy
      @job.save
      @all_applications = []
      
      3.times do
        candidate = Factory.build(:accepted_candidate,
          :gender_id => Candidate::Gender[:female],
          :job_mixing_id => Candidate::MixingLevels[:unsegregated_conservative],
          :degrees => [ 
            Factory.build(:degree, 
              :institution => Factory.create(:english_university),
              :level_id => Degree::Levels[:phd],
              :gpa => 3.8,
              :category => Factory.create(:category, :level_id => Category::Levels[:a]))
          ] 
        )
          
        candidate.countries << Country.saudi_arabia     
        candidate.save!
        @all_applications << @vacancy.add_application!(candidate)
      end
      @application = @all_applications.first
      @application2 = @all_applications.second
      @for_paying_application = @all_applications.third
      i = @for_paying_application.candidate.institutions.first
      i.country = Factory.create(:country)
      i.save
      EmployerSession.create(@employer)
    end

    [:all, :short_listed, :rejected].each do |filter|
      [true, false].each do |ajax|
        context "trying to list #{filter} applications#{ajax ? ' with ajax' : ''}" do
          setup do
            @application[filter] = true; @application.save;
            @application2[filter] = false; @application2.save;
            
            attrs = [:index, {:vacancy_id => @vacancy.id, :q => {:filter => filter.to_s}}]
            ajax ? xhr(:get, *attrs) : get(*attrs)
            @expected = filter == :all ? @all_applications : [@application]
          end
          should_respond_with :success
          should_render_template :index
          should("list the applications") { assert_equal @expected, assigns["applications"] }
        end      
      end
    end
    
    {:short_list => :short_listed, :reject => :rejected}.each do |action, field|
      context "trying to #{action} an application" do
        setup do
          xhr :put, action, :vacancy_id => @vacancy.id, :id => @application.id
          @application.reload
        end

        should("#{action} the application") { assert @application[field] }
      end

      context "trying to un#{action} the application" do
        setup do
          @application[field] = true
          @application.save
          xhr :put, "un#{action}", :vacancy_id => @vacancy.id, :id => @application.id
          @application.reload
        end

        should("un#{action} the application") { assert !@application[field] }
      end

      # mass actions
      context "trying to mass_#{action} applications" do
        setup do
          @applications = [@application]
          xhr :put, "mass_#{action}", :vacancy_id => @vacancy.id, :ids => @applications.collect(&:id)
          @applications.each{|a| a.reload}
        end

        should("mass_#{action} the applications") do
          assert @applications.inject(true){|s, a| s && a[field]}
        end
      end

      context "trying to mass_un#{action} applications" do
        setup do
          @applications = [@application]
          @applications.each {|a| a[field] = true; a.save }
          xhr :put, "mass_un#{action}", :vacancy_id => @vacancy.id, :ids => @applications.collect(&:id)
          @applications.each{|a| a.reload}
        end

        should("un#{action} the applications") do
          assert !@applications.inject(false){|s, a| s || a[field]}
        end
      end

    end # end of hash iterations

    # testing for_paying_only
    [true, false].each do |paying|
      [true, false].each do |expired| 
      context "being #{paying ? 'paying' : (expired ? 'expired' : 'non-paying')}" do
        setup { @employer.paying_till(Date.today + 3.months) if paying }

      {:short_list => :short_listed, :reject => :rejected}.each do |action, field|
        context "trying to #{action} an application" do
          setup do
            xhr :put, action, :vacancy_id => @vacancy.id, :id => @for_paying_application.id
            @for_paying_application.reload
          end

          paying ? should("#{action} the application") { assert @for_paying_application[field] } : should("not #{action} the application") { assert !@for_paying_application[field] }
          
        end
      
        context "trying to un#{action} the application" do
          setup do
            @for_paying_application[field] = true
            @for_paying_application.save
            xhr :put, "un#{action}", :vacancy_id => @vacancy.id, :id => @for_paying_application.id
            @for_paying_application.reload
          end

          paying ? should("un#{action} the application") { assert !@for_paying_application[field] } :
            should("not un#{action} the application") { assert @for_paying_application[field] }
        end

        # mass actions
        context "trying to mass_#{action} applications" do
          setup do
            xhr :put, "mass_#{action}", :vacancy_id => @vacancy.id, :ids => @all_applications.collect(&:id)
            @all_applications.each{|a| a.reload}
          end

          paying ? should("mass_#{action} the applications") { assert @all_applications.select(&(field)).include?(@for_paying_application) } :
            should("not mass_#{action} the for_paying_only application") { assert !@all_applications.select(&(field)).include?(@for_paying_application) }
        end

        context "trying to mass_un#{action} applications" do
          setup do
            @all_applications.each {|a| a[field] = true; a.save }
            xhr :put, "mass_un#{action}", :vacancy_id => @vacancy.id, :ids => @all_applications.collect(&:id)
            @all_applications.each{|a| a.reload}
          end

          paying ? should("un#{action} the applications") { assert @all_applications.reject(&(field)).include?(@for_paying_application) } :
            should("not un#{action} the for paying only application") { assert !@all_applications.reject(&(field)).include?(@for_paying_application) }
        end

      
      end
      
      end
      end  if !paying
    
    end # paying loop
    # end for paying only
  end
  
end
