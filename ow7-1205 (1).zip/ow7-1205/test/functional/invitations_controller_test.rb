require File.dirname(__FILE__) + '/../test_helper'

class InvitationsControllerTest < ActionController::TestCase
  should_require_admin_for({:get => [:index, :new, :edit],
                            :put => [:create, :update],
                              :delete => [:destroy]})
  
  context "A logged in admin" do
    setup do
      @admin = Factory.create :admin
      2.times { Factory.create :invitation }
      @count = Invitation.count
    end
    
    context "trying to view invitations" do
      setup { get :index }
      should_respond_with :success
      should_render_template :index
      should_assign_to :invitations, :invitation
      should("list invitations") {assert_equal Invitation.descend_by_created_at, assigns(:invitations)}
    end
    
    context "trying to view invitations with ajax" do
      setup { xhr :get, :index }
      should_render_template :index
      should_assign_to :invitations, :invitation
      should("list invitations") {assert_equal Invitation.descend_by_created_at, assigns(:invitations)}
    end
    
    context "trying to send an invitation" do
      context "with invalid params" do
        setup do
          xhr :put, :create, :invitation => {}
          @errors = assigns(:invitation).errors.full_messages
        end
        
        should_render_template :create
        should("respond with form with errors") { assert_match /#{@errors.first}/, @response.body }
      end
      
      context "with valid params" do
        setup do
          xhr :put, :create, :invitation => {:email => "test@email.com",
                                             :type_id => Invitation.types[:employer],
                                             :first_name => "haha", :last_name => "hoho"}
          @errors = assigns(:invitation).errors.full_messages
        end
        
        should_render_template :create
        should("succeed") do
          assert_equal 0, assigns(:invitation).errors.full_messages.length
          assert_equal I18n.t('flash.invitations.created'), assigns(:success)
          assert_equal @count + 1, Invitation.count
        end
      end
      
    end
    
    context "trying to delete an invitation" do
      context "that exists" do
        setup do
          @invitation = Invitation.first
          xhr :put, :destroy, :id => @invitation.id
        end
        
        should_render_template :destroy
        should("delete invitation") do
          assert_equal nil, Invitation.find_by_id(@invitation.id)
          assert_equal @count -1, Invitation.count 
        end
      end
      
      context "that does not exist" do
        setup do
          xhr :put, :destroy, :id => (Invitation.maximum :id) + 1
        end
        
        should_render_template :destroy
        should("respond with error") do
          assert_match /#{I18n.t('flash.invitations.not_found')}/, @response.body
        end
      end
    end
    
  end
end
