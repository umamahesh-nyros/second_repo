require File.dirname(__FILE__) + '/../test_helper'

class EmployersControllerTest < ActionController::TestCase
  def self.should_require_invitation_for(options, record=nil)
    context "A guest without an invitation" do
      options.each_pair do |method, actions|
        actions.each do |action|
          context "trying to #{method} to #{action}" do
            setup { send method, action, :id => "blah" }
            should_set_flash_of_to(:error, I18n.t('flash.ensure_invited'))
            should_redirect_to("root url") { root_url }              
          end
        end
      end
    end
  end
  
  should_require_no_employer_for(:get => [:new], :post => [:create])
  should_require_invitation_for(:get => [:new], :post => [:create])
  should_require_employer_for(:get => [:edit], :put => [:update])
  should_require_admin_for!(:put => [:block, :unblock, :mass_block, :mass_unblock, :paying, :non_paying])
  
  context "A guest that's invited" do
    setup { @invitation = Factory.create :invitation }
    
    context "visits the registration page" do
      setup { get :new, :ic => @invitation.code }
      should_respond_with :success
    end
    
    context "POSTs to create with valid params" do
      setup do
        @count = Employer.count
        @job_count = Job.count
        @vacancy_count = Vacancy.count
        
        filters = { :filter_1 => [], :filter_2 => [] }
        
        attrs = {
          :ic => @invitation.code,
          :employer => Factory.attributes_for(:employer,
            :city_id => Factory.create(:saudi_city).id,
            :jobs_attributes => {
            0 => Factory.attributes_for(:job,
                :vacancies_attributes => {0 =>{:city_id => City.saudi.rand.id}},
                :filters => filters
            )
          }
          )
        }
        attrs[:employer].delete :password_confirmation
        post :create, attrs
      end
      should("increment the employers count by 1") { assert_equal @count+1, Employer.count }
      should("increment the jobs count by 1") { assert_equal @job_count+1, Job.count}
      should("increment the vacancy count by 1") { assert_equal @vacancy_count+1, Vacancy.count}
      should_set_flash_of_to(:notice, I18n.t('flash.users.create.notice'))
      should_redirect_to("Employer home page") { employer_url Employer.last }
    end
    
    context "POSTs to create with invalid params" do
      setup { post :create, :employer => {}, :ic => @invitation.code }
      should_render_template :new
    end
  end
  
  context "A guest that's invited to be ngo" do
    setup {@invitation = Factory.create :ngo_invitation}
    
    context "visits the registration page" do
      setup { get :new, :ic => @invitation.code }
      should_respond_with :success
      should("set the employer as ngo") { assert assigns(:employer).ngo }
    end
    
    context "POSTs to create with valid params" do
      setup do
        @count = Employer.count
        @job_count = Job.count
        @vacancy_count = Vacancy.count
        
        filters = { :filter_1 => [], :filter_2 => [] }
        
        attrs = {
          :ic => @invitation.code,
          :employer => Factory.attributes_for(:employer,
            :city_id => Factory.create(:saudi_city).id,
            :jobs_attributes => {
            0 => Factory.attributes_for(:job,
                :employer_name => "employer _name",
                :employer_website => "www.employerwebsite.com",
                :employer_city_id => City.saudi.rand.id,
                :vacancies_attributes => {0 =>{:city_id => City.saudi.rand.id}},
                :filters => filters
            )
          }
          )
        }
        attrs[:employer].delete :password_confirmation
        post :create, attrs
      end
      should("increment the employers count by 1") { assert_equal @count+1, Employer.count }
      should("increment the jobs count by 1") { assert_equal @job_count+1, Job.count}
      should("increment the vacancy count by 1") { assert_equal @vacancy_count+1, Vacancy.count}
      should_set_flash_of_to(:notice, I18n.t('flash.users.create.notice'))
      should_redirect_to("Employer home page") { employer_url Employer.last }
      should("set the employer as ngo") { assert Employer.last.ngo }
    end
    
    context "POSTs to create with missing job employer params" do
      setup do
        @count = Employer.count
        @job_count = Job.count
        @vacancy_count = Vacancy.count
        
        filters = { :filter_1 => [], :filter_2 => [] }
        
        attrs = {
          :ic => @invitation.code,
          :employer => Factory.attributes_for(:employer,
            :city_id => Factory.create(:saudi_city).id,
            :jobs_attributes => {
            0 => Factory.attributes_for(:job,
                :vacancies_attributes => {0 =>{:city_id => City.saudi.rand.id}},
                :filters => filters
            )
          }
          )
        }
        attrs[:employer].delete :password_confirmation
        post :create, attrs
      end
      should_render_template :new
    end
  end
  
  context "An Employer" do
    
    setup do
      @employer = Factory.create(:employer)
      @another_employer = Factory.create(:employer)
      
      clear_employer_session
    end
    
    context "trying to edit his settings" do
      setup do
        EmployerSession.create(@employer)
        @new_name = "New Company Name"
        @new_email = "new@email.com"
        @new_password = "newpassword"
        
      end
      
      context "with valid data" do
        setup do
          attrs = {
            :employer => { :name => @new_name, :email => @new_email, :old_password => "kokowawa", :password => @new_password },
            :id => @employer.id,
            :form => 'info_form'
          }
          
          post :update, attrs
          @employer.reload        
        end
        
        should("apply the updates properly") do
          assert_equal @new_name, @employer.name
          assert_equal @new_email, @employer.email
        end
        should_redirect_to("Employer main page") { employer_path @employer }
        should_set_flash_of_to(:notice, I18n.t('flash.users.update.notice'))
      end
      
      context "with invalid old password" do
        setup do
          attrs = {
            :employer => { :name => @new_name, :email => @new_email, :old_password => "", :password => @new_password },
            :id => @employer.id,
            :form => 'info_form'
          }
          
          post :update, attrs
          @errors = assigns(:employer).errors.full_messages
        end
        
        should("not apply the updates") do
          assert_not_equal @new_name, @employer.name
          assert_not_equal @new_email, @employer.email
        end
        should("mark the employer with errors") do
          assert(@errors.length > 0)
          assert_match /#{I18n.t('activerecord.errors.models.employer.old_password')}/, @errors.to_s
        end
        should_render_template :edit
      end
      
      
    end
    
    context "with another employer logged in" do
      setup { EmployerSession.create(@another_employer) }
      
      {:get => [:edit], :put => [:update]}.each do |method, actions|
        
        actions.each do |action|
          context "trying to #{method} to #{action}" do
            setup { send(method, action, :id => @employer.id) }
            should_set_flash_of_to(:error, I18n.t('flash.users.user_is_not_current_employer'))
            should_redirect_to("employer_path") { employer_path(@another_employer) }
          end      
        end
        
      end
    end
    
  end
  
  context "A blocked logged in employer" do
    setup do
      @employer = Factory.create :employer
      @employer.block!
    end
    
    context "trying to request unblocking" do
      setup {put :request_unblock, :id => @employer.id}
      should_redirect_to("employer's settings page") { edit_employer_path(@employer) }
      should("change the employer's status to :unblock_requested") do
        assert @employer.reload.status_unblock_requested?
      end
    end
  end

  context "An Admin logged in employer" do
    setup do
      @employer = Factory.create :employer
      clear_employer_session
      @admin = Factory.create :admin
    end
    
    context "trying to mark employer as paying" do
      context "with valid params" do
        setup do
          @expiration_date = Date.today + 3.months
          put :paying, :id => @employer.id, :employer => {:paid_expiry_date => @expiration_date.to_s(:db)}
          @employer.reload
        end
        should_render_template :indvidual_action
        should("mark the employer as paying") do
          assert @employer.paying?
          assert_equal @expiration_date, @employer.paid_expiry_date 
        end
      end

      context "with invalid params" do
        setup do
          put :paying, :id => @employer.id, :employer => {:paid_expiry_date => ""}
          @employer.reload
        end
        should_render_template :indvidual_action
        should("mark the employer with errors") { assert assigns["employer"].errors.on(:paid_expiry_date).present? }
        should("not mark the employer as paying") do
          assert !@employer.paying?
        end
      end

    end

    context "trying to mark a paying employer as non-paying" do
      setup do
        @employer.paying_till(Date.today + 3.months)
        put :non_paying, :id => @employer.id
        @employer.reload
      end
      should_render_template :indvidual_action
      should("mark the employer as non-paying") do
        assert @employer.non_paying?
        assert_nil @employer.paid_expiry_date 
      end
    end

  end

end
