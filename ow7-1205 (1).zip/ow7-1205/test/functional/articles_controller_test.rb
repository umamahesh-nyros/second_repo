require File.dirname(__FILE__) + '/../test_helper'

class ArticlesControllerTest < ActionController::TestCase
  should_require_admin_or_employer_for({:get => [:new, :edit, :manage],
                                        :put => [:update, :draft, :publish, :mass_publish, :mass_draft],
                                        :post => [:create],
                                        :delete => [:destroy, :mass_destroy]})
  
  context "GETing the news page" do
    context "when there are no articles" do
      setup { get :index}
      should_respond_with :success
    end
    
    context "when there are articles" do
      setup do
        5.times { Factory.create(:admin_article); Factory.create(:employer_article)}
        get :index
      end
      should_respond_with :success
    end
  end
  
  context "A logged in admin" do
    setup { @admin = Factory.create(:admin); AdminSession.create(@admin)}
    context "without articles, can go to the manage page" do
      setup { get :manage }
      should_respond_with :success
    end
    context "with articles" do
      setup do
        @published_articles = (1..5).map { Factory.create(:admin_article, :creator => @admin) }
        @draft_articles = (1..5).map { Factory.create(:draft_admin_article, :creator => @admin) }
      end
      context "can go to the manage page" do
        setup { get :manage }
        should_respond_with :success
      end
      
      context "trying to publish a draft" do
        context "via normal request" do
          setup { put :publish, :id => @draft_articles.first.id}
          should_redirect_to("the article path") { article_path(@draft_articles.first) }
          should("mark the article as published") { assert @draft_articles.first.reload.status_published? }
        end
        context "via ajax request" do
          setup { xhr :put, :publish, :id => @draft_articles.first.id}
          should_respond_with :success
          should("mark the article as published") { assert @draft_articles.first.reload.status_published? }
        end
      end
      
      context "trying to draft a published article" do
        context "via normal request" do
          setup { put :draft, :id => @published_articles.first.id}
          should_redirect_to("the article path") { article_path(@published_articles.first) }
          should("mark the article as draft") { assert @published_articles.first.reload.status_draft? }  
        end
        context "via ajax request" do
          setup { xhr :put, :draft, :id => @published_articles.first.id}
          should_respond_with :success
          should("mark the article as draft") { assert @published_articles.first.reload.status_draft? }  
        end
      end
      
      context "trying to destroy an article" do
        context "via normal request" do
          setup { delete :destroy, :id => @published_articles.first.id}
          should_redirect_to("the articles path") { articles_path }
          should("decrement the articles count") {assert_equal(@published_articles.length+@draft_articles.length-1, @admin.articles.count)}
        end
        context "via ajax request" do
          setup { xhr :delete, :destroy, :id => @published_articles.first.id}
          should_respond_with :success
          should("decrement the articles count") {assert_equal(@published_articles.length+@draft_articles.length-1, @admin.articles.count)}  
        end
      end
      
      context "trying to mass destroy articles" do
        setup { delete :mass_destroy, :ids => (@published_articles.map &:id)}
        should_redirect_to("the manage articles path") { manage_articles_path }
        should("decrement the articles count") {assert_equal(@draft_articles.length, @admin.articles.count)}
      end

      context "trying to mass publish articles" do
        setup { put :mass_publish, :ids => (@draft_articles.map &:id)}
        should_redirect_to("the manage articles path") { manage_articles_path }
        should("have the proper count") {assert_equal(@draft_articles.length+@published_articles.length, @admin.articles.status_published.count)}
      end
      
      context "trying to mass draft articles" do
        setup { put :mass_draft, :ids => (@published_articles.map &:id)}
        should_redirect_to("the manage articles path") { manage_articles_path }
        should("have the proper count") {assert_equal(@draft_articles.length+@published_articles.length, @admin.articles.status_draft.count)}
      end
    end
  end
end
