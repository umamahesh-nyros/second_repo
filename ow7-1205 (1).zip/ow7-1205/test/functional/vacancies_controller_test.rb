require File.dirname(__FILE__) + '/../test_helper'

class VacanciesControllerTest < ActionController::TestCase
  should_require_employer_for(:get => [:new, :edit], :put => [:update, :create, :destroy])
  should_require_admin_for(:put => [:heat, :unheat, :remove, :unremove, :clear_reports,
                            :mass_heat, :mass_unheat, :mass_remove, :mass_unremove, :mass_clear_reports])
  should_require_user_for(:put => [:sms])

  context "An Employer having job vacancies" do
      
    setup do
      @employer = Factory.create(:employer)
      @another_employer = Factory.create(:employer)
      @job = Factory.build :job, :employer => @employer
      @vacancy_1 = Vacancy.new :city => City.saudi.rand
      @vacancy_2 = Vacancy.new :city => City.saudi.rand     
      @job.vacancies << @vacancy_1 << @vacancy_2
      @job.save
      clear_employer_session
    end
    
    context "A guest visiting the view job page of a job" do
      setup {get :show, :id => @vacancy_1.id}
      should_render_template :show
      should_respond_with :success
    end

    context "A guest applying to a job vacancy" do
      setup do
        xhr :put, :apply, :id => @vacancy_1.id
      end
      should("store the vacancy id") {assert_equal session[:after_login][:apply_to], @vacancy_1.id}
      should("redirect to candidates login") {assert_match /#{candidates_login_path}/, @response.body}
      should_respond_with :success
    end

    context "A guest reporting the job vacancy as inappropriate" do
      setup do
        @vacancy_1.clear_reports
        @times = 2
        2.times { put :report, :id => @vacancy_1.id }
        @vacancy_1.reload
      end
      should_render_template :report
      should("report the job") { assert @vacancy_1.reported }
      should("reflect the number of reports") {assert_equal @times, @vacancy_1.reports}
    end

    context "A logged in candidate" do
      setup do
        @candidate = Factory.create(:candidate)
        CandidateSession.create(@candidate)
      end

      context "trying to send an SMS" do
        context "with invalid params" do
          setup do
            xhr :put, :sms, :id => @vacancy_1.id, :sms => {:numbers => ["koko"]}
            @errors = assigns(:sms).errors.full_messages
          end
          
          should_render_template :sms
          should("respond with form with errors") { assert_match /#{@errors.first}/, @response.body }
        end
        
        context "with valid params" do
          setup do
            xhr :put, :sms, :id => @vacancy_1.id, :sms => {:numbers => ["012334458585"]}
          end
          
          should_render_template :sms
          should("succeed") do
            assert assigns(:sms).errors.blank?
            assert_equal I18n.t('flash.sms.sent'), assigns(:success)
            assert_equal assigns(:sms), TextMessage.all.last
          end
        end
        
      end

    end

    context "A candidate applying to a job vacancy" do
      setup do
        @candidate = Factory.create(:candidate)
        CandidateSession.create(@candidate)
        @count = @vacancy_1.applications.count
      end

      context "which has no redirection url" do
        setup do
          xhr :put, :apply, :id => @vacancy_1.id
        end
        should_render_template :apply
        should_respond_with :success
        should("apply for the job") do
          assert @response.body.include?(I18n.t('flash.jobs.vacancy.candidate.applied'))
          assert_equal @count + 1, @vacancy_1.applications.count
        end
      end

      context "which has a redirection url" do
        setup do
          @url = "http://applications.somecompany.com"
          @job.application_url = @url
          @job.save!
          xhr :put, :apply, :id => @vacancy_1.id
        end
        should_render_template :apply
        should_respond_with :success
        should("redirect to url") do
          assert @response.body.include?(@url)
          assert_equal @count, @vacancy_1.applications.count
        end
      end

    end

    context "A candidate trying to re-apply to a job vacancy" do
      setup do
        @candidate = Factory.create(:candidate)
        CandidateSession.create(@candidate)
        @vacancy_1.applications.create(:candidate => @candidate)
        @count = @vacancy_1.applications.count
        xhr :put, :apply, :id => @vacancy_1.id
      end
      should_render_template :apply
      should("not re-apply for the job") {
        assert_equal @count, @vacancy_1.applications.count
        assert @response.body.include?(I18n.t('flash.jobs.vacancy.candidate.already_applied'))
      }
    end
    
    context "trying to delete a vacancy of a job" do
      setup do
        EmployerSession.create(@employer)
        @vacancies_count = @employer.vacancies.count
        
        post :destroy, :id => @vacancy_2.id
        
      end
      should("decrement the vacancies count by 1") { assert_equal @vacancies_count-1, @employer.vacancies.count}
      should_set_flash_of_to(:notice, I18n.t('flash.jobs.vacancy.deleted'))
      should_redirect_to("Employer main page") { employer_path @employer }
    end

    context "with another employer logged in" do
      setup { EmployerSession.create(@another_employer) }
  
      {:get => [:edit], :put => [:update, :destroy]}.each do |method, actions|
        
          actions.each do |action|
            context "trying to #{method} to #{action}" do
              setup { send(method, action, :id => @vacancy_2.id) }
              should_set_flash_of_to(:error, I18n.t('flash.users.user_is_not_current_employer'))
              should_redirect_to("employer_path") { employer_path(@another_employer) }
            end      
          end
              
      end
    end
    context "An Admin" do
      setup do
        @admin = Factory.create(:admin)
        AdminSession.create(@admin)      
      end
      
      #individual actions
      context "trying to remove a job vacancy" do
        setup do
          @reason = "a reason"
          xhr :put, :remove, :id => @vacancy_1.id, :reason => @reason
          @vacancy_1.reload
        end

        should("remove the job") do
          assert @vacancy_1.removed
          assert_equal @reason, @vacancy_1.removal_reason
        end
      end

      context "trying to unremove a job vacancy" do
        setup do
          @vacancy_1.removed = true
          @vacancy_1.removal_reason = "some reason"
          @vacancy_1.save
          xhr :put, :unremove, :id => @vacancy_1.id
          @vacancy_1.reload
        end

        should("unremove the job") do
          assert !@vacancy_1.removed
          assert_nil @vacancy_1.removal_reason
        end
      end

      context "trying to mark a job vacancy as hot" do
        setup do
          xhr :put, :heat, :id => @vacancy_1.id
          @vacancy_1.reload
        end

        should("mark the job as hot") { assert @vacancy_1.hot }
      end

      context "trying to unmark hot job vacancy" do
        setup do
          @vacancy_1.hot = true
          @vacancy_1.save
          xhr :put, :unheat, :id => @vacancy_1.id
          @vacancy_1.reload
        end

        should("unmark the hot job") { assert !@vacancy_1.hot }
      end

      context "trying to clear reports on a job vacancy" do
        setup do
          @vacancy_1.report
          xhr :put, :clear_reports, :id => @vacancy_1.id
          @vacancy_1.reload
        end

        should("unmark the hot job") { assert !@vacancy_1.reported }
      end


      # mass actions
      context "trying to mass_remove vacancies" do
        setup do
          @vacancies = [@vacancy_1, @vacancy_2]
          xhr :put, :mass_remove, :ids => @vacancies.collect(&:id)
          @vacancies.each{|v| v.reload}
        end

        should("remove the vacancies") do
          assert @vacancies.inject(true){|s, v| s && v.removed}
        end
      end

      context "trying to mass_unremove vacancies" do
        setup do
          @vacancies = [@vacancy_1, @vacancy_2]
          @vacancies.each {|v| v.removed = true; v.save }
          xhr :put, :mass_unremove, :ids => @vacancies.collect(&:id)
          @vacancies.each{|v| v.reload}
        end

        should("unremove the vacancies") do
          assert !@vacancies.inject(false){|s, v| s || v.removed}
        end
      end

      context "trying to mass_mark vacancies as hot" do
        setup do
          @vacancies = [@vacancy_1, @vacancy_2]
          xhr :put, :mass_heat, :ids => @vacancies.collect(&:id)
          @vacancies.each{|v| v.reload}
        end

        should("mark the jobs as hot") { assert @vacancies.inject(true){|s, v| s && v.hot} }
      end

      context "trying to mass unmark hot vacancies" do
        setup do
          @vacancies = [@vacancy_1, @vacancy_2]
          @vacancies.each {|v| v.hot = true; v.save }
          xhr :put, :mass_unheat, :ids => @vacancies.collect(&:id)
          @vacancies.each {|v| v.reload}
        end

        should("unmark the hot vacancies") { assert !@vacancies.inject(false){|s, v| s || v.hot} }
      end

      context "trying to mass clear reports for vacancies" do
        setup do
          @vacancies = [@vacancy_1, @vacancy_2]
          @vacancies.each {|v| v.report }
          xhr :put, :mass_clear_reports, :ids => @vacancies.collect(&:id)
          @vacancies.each{|v| v.reload }
        end

        should("clear reports") { assert !@vacancies.inject(false){|s, v| s || v.reported} }
      end

    end 
  end
end
