require File.dirname(__FILE__) + '/../../test_helper'

class Admins::SessionsControllerTest < ActionController::TestCase
  Password = "passwordhahaha"
  should_require_no_user_for(:get => [:new], :post => [:create])
  should_require_admin_for(:delete => [:destroy])
  
  context "A non logged in admin" do
    context "that exists" do
      setup do
        @admin = Factory.create :admin
        @admin.password = @admin.password_confirmation = Password
        @admin.save
        clear_admin_session
        post :create, :admin_session => {:email => @admin.email, :password => Password}
      end
      should_redirect_to("admin home page") { admins_home_path }
    end
    
    context "that doesn't exist" do
      setup do
        post :create, :admin_session => {:email => "fjskdfjls@jflks.com", :password => Password}
      end
      should_render_template :new
    end
  end
end
