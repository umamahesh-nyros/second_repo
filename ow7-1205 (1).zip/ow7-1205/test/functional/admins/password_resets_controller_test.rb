require File.dirname(__FILE__) + '/../../test_helper'

class Admins::PasswordResetsControllerTest < ActionController::TestCase
  context "A logged in admin" do
    setup do
      @admin = Factory.create(:admin)
      AdminSession.create(@admin)
    end
    
    context "requesting the password reset email" do
      setup { post :create, :email => @admin.email}
      should_require_no_admin
    end
    
    context "requesting the page for entering the new password" do
      setup { get :edit, :id => @admin.perishable_token }
      should_require_no_admin
    end
    
    context "submitting a new password" do
      setup { put :update, :id => @admin.perishable_token, :password => "kokowawata"}
      should_require_no_admin
    end
  end

  context "A guest" do
    context "with a valid admin account already created" do
      setup do
        @admin = Factory.create(:admin)
        @admin.reset_perishable_token!
        clear_admin_session
        @admin = @admin.reload
      end
      
      context "requesting the password reset email (with a valid email)" do
        setup { post :create, :email => @admin.email}
        should_assign_to :admin
        should_set_flash_of_to :notice, I18n.t('flash.password_resets.create.notice')
        should_send_email
        should_redirect_to("admins_login_path") { admins_login_path }
      end
      
      context "requesting the password reset email (with an invalid email)" do
        setup { post :create, :email => "hawhaw@kawkaw.com"}
        should_set_flash_of_to :error, I18n.t('flash.password_resets.create.no_user')
        should_redirect_to("admins_password_resets_path") { admins_password_resets_path }
      end
      
      context "requesting the page for entering the new password (with a valid token)" do
        setup { get :edit, :id => @admin.perishable_token }
        should_respond_with :success
      end
      
      context "requesting the page for entering the new password (with an invalid token)" do
        setup { get :edit, :id => "he3he3" }
        should_assign_to_flash_of :error
        should_redirect_to("admins_password_resets_path") { admins_password_resets_path }
      end
      
      context "submitting a new password with invalid token" do
        setup { put :update, :id => "23o23o", :admin => {:password => "kokowawata"}}
        should_assign_to_flash_of :error
        should_redirect_to("admins_password_resets_path") { admins_password_resets_path }
      end
    
      context "submitting a new invalid password" do
        setup { put :update, :id => @admin.perishable_token, :admin => {:password => "ab"}}
        should_redirect_to("edit_admins_password_reset_path") {edit_admins_password_reset_path(@admin.perishable_token)}
      end
  
      context "submitting a new valid password" do
        setup { put :update, :id => @admin.perishable_token, :admin => {:password => "kokowawata", :password_confirmation => "kokowawata"}}
        should_assign_to :admin
        should_set_flash_of_to :notice, I18n.t('flash.password_resets.update.notice')
        should_redirect_to('root path') { root_path }
      end
  
      context "submitting a new valid password and additional parameters" do
        setup do
          @email = @admin.email
          put :update, :id => @admin.perishable_token, :admin => {:password => "kokowawata", :password_confirmation => "kokowawata", :email => "sewsew@weswes.com"}
        end
        should_assign_to :admin
        should("update password only") { assert_equal assigns(:admin).reload.email, @email }
        should_set_flash_of_to :notice, I18n.t('flash.password_resets.update.notice')
        should_redirect_to('root path') { root_path }
      end      
      
    end
  end
end