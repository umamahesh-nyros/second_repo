require File.dirname(__FILE__) + '/../../test_helper'

class Admins::HomeControllerTest < ActionController::TestCase

  should_require_admin_for(:get => [:show, :job_reports, :candidate_reports])
  context "A logged in admin" do
    setup do
    
      # Job Types
      [
      ["Full-time job", 1],
      ["Graduate program", 2],
      ["Internship", 3],
      ["Summer/part-time job", 4]
      ].each do |f|
        t = Jobs::Type.find_or_initialize_by_identifier f[1]
        t.name = f[0]
        t.save!
      end
          
      @admin = Factory.create :admin
      AdminSession.create @admin
    end
    [:show, :job_reports, :candidate_reports].each do |action|
      context "trying to view his homepage with #{action}" do
        setup do
          Candidate.mock(:solr_search_ids => []) do
            Country.mock(:find_by_iso => Country.all.rand) do
              get action
            end
          end
        end
        should_respond_with :success
        should_render_template action
      end
    end
  end

end
