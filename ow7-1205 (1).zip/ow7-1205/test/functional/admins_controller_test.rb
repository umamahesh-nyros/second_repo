require File.dirname(__FILE__) + '/../test_helper'

class AdminsControllerTest < ActionController::TestCase  
  
  should_require_admin_for(:get => [:new, :show, :edit, :index], :post => [:create, :update, :destroy])
  should_require_super_admin_for(:get => [:new, :index], :post => [:create, :destroy])
  
  context "A super admin" do
    setup do
      @super_admin = Factory.create(:super_admin)
      @count = Admin.count
    end

    context "POSTs to create with valid params" do
      setup do
        post :create, :admin => Factory.attributes_for(:admin)
      end
      should("increment the admins count by 1") { assert_equal @count+1, Admin.count }
      should_set_flash_of_to(:notice, I18n.t('flash.users.create.notice'))
      should_redirect_to("admins path") { admins_path }
    end

    context "POSTs to create with valid params with ajax" do
      setup do
        xhr :post, :create, :admin => Factory.attributes_for(:admin)
      end
      should("increment the admins count by 1") { assert_equal @count+1, Admin.count }
      should_set_flash_of_to(:notice, I18n.t('flash.users.create.notice'))
      should_render_template :create
    end

    context "POSTs to create with invalid params" do
      setup { post :create, :admin => {} }
      should_redirect_to("root path") { admins_path }
    end

    context "POSTs to create with invalid params with ajax" do
      setup { xhr :post, :create, :admin => {} }
      should_render_template :create
      should("return with errors") { assert_match /create.error/, @response.body}
    end

    context "POSTs to update with valid params with ajax" do
      setup do
        @admin = Factory.create(:admin)
        @new_name = "New Company Name"
        @new_email = "new@email.com"
        attrs = {
          :admin => { :name => @new_name, :email => @new_email, :super_admin => true},
          :id => @admin.id, :edit_form => '1'
        }
        xhr :post, :update, attrs
        @admin.reload
      end
      should("apply the updates properly") do
        assert_equal @new_name, @admin.name
        assert_equal @new_email, @admin.email
        assert @admin.super?
      end
    end

    context "POSTs to update with invalid params with ajax" do
      setup do
        @admin = Factory.create(:admin)
        xhr :post, :update, :id => @admin.id, :admin => {:email => ""}, :edit_form => '1'
        @admin.reload
      end 
      should_render_template :update
      should("return with errors") { assert_match /update.error/, @response.body}
    end

    context "POSTs to mark admin as super admin with ajax" do
      setup do
        @admin = Factory.create(:admin)
        attrs = {
          :admin => {:super_admin => true},
          :id => @admin.id
        }
        xhr :post, :update, attrs
        @admin.reload
      end
      should("apply the updates properly") do
        assert @admin.super?
      end
    end

    context "POSTs to unmark admin as super admin with ajax" do
      setup do
        @admin = Factory.create(:super_admin)
        attrs = {
          :admin => {:super_admin => false},
          :id => @admin.id
        }
        xhr :post, :update, attrs
        @admin.reload
      end
      should("apply the updates properly") do
        assert !@admin.super?
      end
    end

    context "POSTs to destroy an admin account with ajax" do
      setup do
        @admin = Factory.create(:admin)
        @count = Admin.count
        xhr :post, :destroy, :id => @admin.id
      end
      should("destroy the account") do
        assert_equal @count - 1, Admin.count
        assert_nil Admin.find_by_id(@admin.id)
      end
    end


  end

  context "An admin" do
    setup do
      @admin = Factory.create(:admin)
      @admin.password = @admin.password_confirmation = "kokowawa"
      @admin.save
      @another_admin = Factory.create(:admin)
      
      clear_admin_session
    end
    
    context "logged in" do
      setup { AdminSession.create(@admin) }
      # admin logged in
      context "trying to view admins list" do
        setup do
          get :index
        end
        should_set_flash_of_to(:error, I18n.t('flash.users.user_not_authorized'))
        should_redirect_to("root path") { root_path }
      end

      context "trying to view his settings page" do
        setup do
          get :edit, :id => @admin.id
        end
        should_render_template :edit
      end

      context "trying to edit his settings" do
        setup do
          @new_name = "New Company Name"
          @new_email = "new@email.com"
          @new_password = "newpassword"
        end
        #edit
        context "with valid data" do
          setup do
            attrs = {
              :admin => { :name => @new_name, :email => @new_email, :old_password => "kokowawa", :password => @new_password },
              :id => @admin.id
            }
            
            post :update, attrs
            @admin.reload
          end
          
          should("apply the updates properly") do
            assert_equal @new_name, @admin.name
            assert_equal @new_email, @admin.email
          end
          should_redirect_to("Admin home page") { admins_home_path }
          should_set_flash_of_to(:notice, I18n.t('flash.users.update.notice'))
        end
        
        context "with invalid old password" do
          setup do
            attrs = {
              :admin => { :name => @new_name, :email => @new_email, :old_password => "", :password => @new_password },
              :id => @admin.id
            }
            
            post :update, attrs
            @errors = assigns(:admin).errors.full_messages
          end
          
          should("not apply the updates") do
            assert_not_equal @new_name, @admin.name
            assert_not_equal @new_email, @admin.email
          end
          should("mark the admin with errors") do
            assert(@errors.length > 0)
            assert_match /#{I18n.t('activerecord.errors.models.employer.old_password')}/, @errors.to_s
          end
          should_render_template :edit
        end
      
        #end edit
      end
      # end admin logged in
          
    end

      context "with another admin logged in" do
        setup { AdminSession.create(@another_admin) }
        
        {:get => [:edit], :put => [:update]}.each do |method, actions|
          
          actions.each do |action|
            context "trying to #{method} to #{action}" do
              setup { send(method, action, :id => @admin.id) }
              should_set_flash_of_to(:error, I18n.t('flash.users.user_not_authorized'))
              should_redirect_to("root path") { root_path }
            end      
          end
          
        end
      end
  
  end

end
