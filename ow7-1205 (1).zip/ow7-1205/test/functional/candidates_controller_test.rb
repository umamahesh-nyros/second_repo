require File.dirname(__FILE__) + '/../test_helper'

class CandidatesControllerTest < ActionController::TestCase  
  should_require_no_candidate_for(:get => [:new], :post => [:create])
  should_require_candidate_for(:get => [:edit], :put => [:update])
  should_require_admin_or_employer_for(:get => [:index, :show, :mass_export])
  should_require_admin_for!(:put => [:block, :unblock, :reject, :unreject,
                            :mass_block, :mass_unblock, :mass_reject, :mass_unreject])
  [Admin, Employer].each do |klass|
    context "A logged-in #{klass.name}" do
      setup do
        "#{klass.name}Session".constantize.create(Factory.create(klass.name.underscore.to_sym))
      end
      context "trying to visit search candidates page" do
        setup {get :index}
        should_respond_with :success
        should_render_template :index
      end
      
      context "An #{klass.name} trying to search candidates with ajax" do
        setup do
          @results = []
          Sunspot::Search.class_mock(:results => @results) do
            xhr :get, :index, :q => {}
          end
        end
        should_respond_with :success
        should_render_template :index
      end
      
      context "trying to export candidates to a csv" do
        setup do
          5.times {|i| c = Factory.create(:candidate); CandidateSession.find.destroy }
          # force the cadidates to be accepted
          Candidate.update_all "status_id=#{Candidate::StatusC[:system_accepted].id}"
          get :mass_export, :ids => Candidate.all.collect {|c| c.id}, :fields => ["name", "level", "university"], :format => "csv"
        end
        should_respond_with :success
      end
    end
  end
  
  context "A guest" do
    context "POSTs to create with valid params" do
      setup do
        @count = Candidate.count
        @time = Time.now
        post :create, :candidate => Factory.attributes_for(:step_1_candidate)
      end
      should("increment the candidates count by 1") { assert_equal @count+1, Candidate.count }
      should_redirect_to("register path") { register_candidates_path }
      should("update last_updated") { assert assigns(:candidate).last_updated > @time}
    end
    
    context "POSTs to create with invalid params" do
      setup { post :create, :candidate => {} }
      should_render_template :new
    end
    
  end
  
  context "A candidate who has compelted step 1" do
    setup {@candidate = Factory.create :step_1_candidate; CandidateSession.create @candidate }
    context "trying to finish step 2" do
      context "with invalid params" do
        setup { put :complete_registration, :candidate => {}}
        should_render_template :register
        should("mark the candidate with errors") { assert(assigns(:candidate).errors.full_messages.length > 0) }
      end
      context "with valid params" do
        setup do
          @time = Time.now
          put :complete_registration, :candidate => {:job_start_date => 1.month.from_now.to_date.to_s(:db),
            :job_type_ids => [(Jobs::Type.find_by_identifier(Jobs::Type::Identifiers[:full_time]) || Factory.create(:full_time_job_type)).id],
            :job_city_ids => [((City.job.first || Factory.create(:job_city))).id]}
        end
        should_redirect_to("register path") { register_candidates_path }
        should("have no errors") { assert_equal 0, assigns(:candidate).errors.full_messages.length }
        should("update last_updated") { assert assigns(:candidate).last_updated > @time}
      end
    end    
  end

  context "A candidate who has compelted step 2" do
    setup do
      @vacancy_1 = Factory.create :vacancy, :city => City.saudi.rand 
      clear_employer_session    
    end
    context "trying to finish step 3" do
      setup {@candidate = Factory.create :step_2_candidate, :country_ids => [Country.saudi_arabia.id]; CandidateSession.create @candidate}

      context "with invalid params" do
        setup { put :complete_registration, :candidate => {}}
        should("mark the candidate with errors") { assert(assigns(:candidate).errors.full_messages.length > 0) }
        should_render_template :register
      end
      context "with valid params" do
        setup do
          @time = Time.now
          @attrs = [:complete_registration, {:candidate => {
            :residence_country_id => Country.saudi_arabia.id,
            :residence_city_id => ((City.job.first || Factory.create(:job_city))).id,
            :residence_phone_code => Country.saudi_arabia.dialing_codes.first.to_s,
            :residence_phone_number => "40598495489",
            :job_start_date => 1.month.from_now.to_date.to_s(:db),
            :entry_level => true,
            :confirmation => true
          }}]
        end

        context "after he had tried to apply for a job" do
          setup do
            session[:after_login] = {}
          end
          
          context "with a redirection url" do
            setup do
              @url = "http://applications.somecompany.com"
              job = @vacancy_1.job
              job.application_url = @url
              job.save!
              session[:after_login][:apply_to] = @vacancy_1.id
              put *@attrs
              @candidate.reload
            end
            
            should_redirect_to("url") { @url }
            should("have no errors") { assert_equal 0, assigns(:candidate).errors.full_messages.length }
            should("not add vacany to applications") {assert @candidate.vacancies.empty?}
          end


          context "with no redirection url" do
            setup do
              session[:after_login][:apply_to] = @vacancy_1.id
              put *@attrs
              @candidate.reload
            end
            
            should_redirect_to("candidate home path") { candidates_home_path }
            should_set_flash_of_to(:notice, I18n.t('flash.jobs.vacancy.candidate.applied'))
            should("have no errors") { assert_equal 0, assigns(:candidate).errors.full_messages.length }
            should("add vacany to applications") {assert_equal @vacancy_1, @candidate.vacancies.first}
          end
        end
        
        context "without applying for a job" do
          setup do
            put *@attrs
          end
          should_redirect_to("candidate home path") { candidates_home_path }
          should("have no errors") { assert_equal 0, assigns(:candidate).errors.full_messages.length }
          should("update last_updated") { assert assigns(:candidate).last_updated > @time}
        end
      end
    end    
  end
  
  context "A logged-in  candidate" do
    setup {@candidate = Factory.create :candidate; CandidateSession.create @candidate }
    context "trying to get to edit" do
      setup { get :edit, :id => @candidate.id }
      should_render_template :edit
    end
    
    context "trying to put to update" do
      context "with invalid params" do
        setup do
          
          put :update, 
            :id => @candidate.id,
            :candidate => { :country_ids => [""] }
        end
        should_render_template :edit
        should("mark the candidate with errors") { assert(assigns(:candidate).errors.full_messages.length > 0) }
      end
      context "with valid params" do
        setup do 
          put :update, 
              :id => @candidate.id,
              :candidate => {
                :job_start_date => 1.month.from_now.to_date.to_s(:db),
                :job_type_ids => [(Jobs::Type.find_by_identifier(Jobs::Type::Identifiers[:full_time]) || Factory.create(:full_time_job_type)).id],
                :job_city_ids => [((City.job.first || Factory.create(:job_city))).id]
          }
        end
        should_redirect_to("candidate home") { candidates_home_path }
        should("have no errors") { assert_equal 0, assigns(:candidate).errors.full_messages.length}
      end
    end    
  end
  
  context "with an already existing candidate" do
    setup { @candidate = Factory.create(:candidate); clear_candidate_session}
    context "an admin trying to view the candidate's cv" do
      setup do
        @admin = Factory.create :admin
        get :show, :id => @candidate.id
      end
      should_respond_with :success
      should_render_template :show
    end
    context "an employer trying to view the candidate's cv" do
      setup do
        @employer = Factory.create :employer
        get :show, :id => @candidate.id
      end
      should_respond_with :success
      should_render_template :show
    end
  end
  
  context "A blocked logged in candidate" do
    setup do
      @candidate = Factory.create :candidate
      @candidate.block!
    end
    
    context "trying to request unblocking" do
      setup {put :request_unblock, :id => @candidate.id}
      should_redirect_to("candidate's settings page") { edit_candidate_path(@candidate) }
      should("change the candidate's status to :unblock_requested") do
        assert @candidate.reload.status_unblock_requested?
      end
    end
  end

  context "with a for paying only candidate" do
    setup do
      @candidate = Factory.create(:for_paying_only_candidate)
      clear_candidate_session
    end
    context "an admin trying to view the candidate's cv" do
      setup do
        @admin = Factory.create :admin
        get :show, :id => @candidate.id
      end
      should_respond_with :success
      should_render_template :show
    end
    
    [true, false].each do |expired|
    context "a #{expired ? 'paying expired' : 'non-paying'} employer" do
      setup do
        @employer = Factory.create :employer
        (@employer.paying_till(Date.yesterday); @employer.expire_payment) if expired
      end

      context "trying to view the candidate's cv" do
        setup { get :show, :id => @candidate.id }
        should_render_template :inaccessible      end 

      context "trying to export candidates to a csv" do
        setup do
          Factory.create(:candidate)
          CandidateSession.find.destroy
          # force the cadidates to be accepted
          Candidate.update_all "status_id=#{Candidate::StatusC[:system_accepted].id}"
          get :mass_export, :ids => Candidate.all.collect {|c| c.id.to_s}, :fields => ["name", "level", "university"], :format => "csv"
        end
        should("not include for-paying-only candidate") { assert !assigns(:candidates).include?(@candidate) }
        should_respond_with :success
      end

    end
    
    end # loop

    # end non-paying / expired
    
    context "a paying employer" do
      setup do
        @employer = Factory.create :employer
        @employer.paying_till(Date.today + 3.months)
      end
      context "trying to view the candidate's cv" do
        setup do
          get :show, :id => @candidate.id
        end
        should_respond_with :success
        should_render_template :show
      end

      context "trying to export candidates to a csv" do
        setup do
          Factory.create(:candidate)
          CandidateSession.find.destroy
          # force the cadidates to be accepted
          Candidate.update_all "status_id=#{Candidate::StatusC[:system_accepted].id}"
          get :mass_export, :ids => Candidate.all.collect {|c| c.id.to_s}, :fields => ["name", "level", "university"], :format => "csv"
        end
        should("include for-paying-only candidate") { assert assigns(:candidates).include?(@candidate) }
        should_respond_with :success
      end

    end

  end


end
