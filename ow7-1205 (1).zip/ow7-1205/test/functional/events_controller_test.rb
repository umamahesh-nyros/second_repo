require File.dirname(__FILE__) + '/../test_helper'

class EventsControllerTest < ActionController::TestCase
  should_require_admin_or_employer_for({:get => [:new, :edit, :manage],
                                        :put => [:update, :draft, :publish, :mass_publish, :mass_draft],
                                        :post => [:create],
                                        :delete => [:destroy, :mass_destroy]})
  
  context "GETing the news page" do
    context "when there are no events" do
      setup { get :index}
      should_respond_with :success
    end
    
    context "when there are events" do
      setup do
        5.times { Factory.create(:admin_event); Factory.create(:employer_event)}
        get :index
      end
      should_respond_with :success
    end
  end
  
  context "A logged in admin" do
    setup { @admin = Factory.create(:admin); AdminSession.create(@admin)}
    context "without events, can go to the manage page" do
      setup { get :manage }
      should_respond_with :success
    end
    context "with events" do
      setup do
        @published_events = (1..5).map { Factory.create(:admin_event, :creator => @admin) }
        @draft_events = (1..5).map { Factory.create(:draft_admin_event, :creator => @admin) }
      end
      context "can go to the manage page" do
        setup { get :manage }
        should_respond_with :success
      end
      
      context "trying to publish a draft" do
        context "via normal request" do
          setup { put :publish, :id => @draft_events.first.id}
          should_redirect_to("the event path") { event_path(@draft_events.first) }
          should("mark the event as published") { assert @draft_events.first.reload.status_published? }
        end
        context "via ajax request" do
          setup { xhr :put, :publish, :id => @draft_events.first.id}
          should_respond_with :success
          should("mark the event as published") { assert @draft_events.first.reload.status_published? }
        end
      end
      
      context "trying to draft a published event" do
        context "via normal request" do
          setup { put :draft, :id => @published_events.first.id}
          should_redirect_to("the event path") { event_path(@published_events.first) }
          should("mark the event as draft") { assert @published_events.first.reload.status_draft? }  
        end
        context "via ajax request" do
          setup { xhr :put, :draft, :id => @published_events.first.id}
          should_respond_with :success
          should("mark the event as draft") { assert @published_events.first.reload.status_draft? }  
        end
      end
      
      context "trying to destroy an event" do
        context "via normal request" do
          setup { delete :destroy, :id => @published_events.first.id}
          should_redirect_to("the events path") { events_path }
          should("decrement the events count") {assert_equal(@published_events.length+@draft_events.length-1, @admin.events.count)}
        end
        context "via ajax request" do
          setup { xhr :delete, :destroy, :id => @published_events.first.id}
          should_respond_with :success
          should("decrement the events count") {assert_equal(@published_events.length+@draft_events.length-1, @admin.events.count)}  
        end
      end
      
      context "trying to mass destroy events" do
        setup { delete :mass_destroy, :ids => (@published_events.map &:id)}
        should_redirect_to("the manage events path") { manage_events_path }
        should("decrement the events count") {assert_equal(@draft_events.length, @admin.events.count)}
      end

      context "trying to mass publish events" do
        setup { put :mass_publish, :ids => (@draft_events.map &:id)}
        should_redirect_to("the manage events path") { manage_events_path }
        should("have the proper count") {assert_equal(@draft_events.length+@published_events.length, @admin.events.status_published.count)}
      end
      
      context "trying to mass draft events" do
        setup { put :mass_draft, :ids => (@published_events.map &:id)}
        should_redirect_to("the manage events path") { manage_events_path }
        should("have the proper count") {assert_equal(@draft_events.length+@published_events.length, @admin.events.status_draft.count)}
      end
    end
  end
end
