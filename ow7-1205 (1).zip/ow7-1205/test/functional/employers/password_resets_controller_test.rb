require File.dirname(__FILE__) + '/../../test_helper'

class Employers::PasswordResetsControllerTest < ActionController::TestCase
  context "A logged in employer" do
    setup do
      @employer = Factory.create(:employer)
      EmployerSession.create(@employer)
    end
    
    context "requesting the password reset email" do
      setup { post :create, :email => @employer.email}
      should_require_no_employer
    end
    
    context "requesting the page for entering the new password" do
      setup { get :edit, :id => @employer.perishable_token }
      should_require_no_employer
    end
    
    context "submitting a new password" do
      setup { put :update, :id => @employer.perishable_token, :password => "kokowawata"}
      should_require_no_employer
    end
  end

  context "A guest" do
    context "with a valid account already created" do
      setup do
        @employer = Factory.create(:employer)
        @employer.reset_perishable_token!
        clear_employer_session
        @employer = @employer.reload
      end
      
      context "requesting the password reset email (with a valid email)" do
        setup { post :create, :email => @employer.email}
        should_assign_to :employer
        should_set_flash_of_to :notice, I18n.t('flash.password_resets.create.notice')
        should_send_email
        should_redirect_to("employers_password_resets_path") { employers_password_resets_path }
      end
      
      context "requesting the password reset email (with an invalid email)" do
        setup { post :create, :email => "hawhaw@kawkaw.com"}
        should_set_flash_of_to :error, I18n.t('flash.password_resets.create.no_user')
        should_redirect_to("employers_password_resets_path") { employers_password_resets_path }
      end
      
      context "requesting the page for entering the new password (with a valid token)" do
        setup { get :edit, :id => @employer.perishable_token }
        should_respond_with :success
      end
      
      context "requesting the page for entering the new password (with an invalid token)" do
        setup { get :edit, :id => "he3he3" }
        should_assign_to_flash_of :error
        should_redirect_to("employers_password_resets_path") { employers_password_resets_path }
      end
      
      context "submitting a new password with invalid token" do
        setup { put :update, :id => "23o23o", :employer => {:password => "kokowawata"}}
        should_assign_to_flash_of :error
        should_redirect_to("employers_password_resets_path") { employers_password_resets_path }
      end
    
      context "submitting a new invalid password" do
        setup { put :update, :id => @employer.perishable_token, :employer => {:password => "ab"}}
        should_redirect_to("edit_employers_password_reset_path") {edit_employers_password_reset_path(@employer.perishable_token)}
      end
  
      context "submitting a new valid password" do
        setup { put :update, :id => @employer.perishable_token, :employer => {:password => "kokowawata", :password_confirmation => "kokowawata"}}
        should_assign_to :employer
        should_set_flash_of_to :notice, I18n.t('flash.password_resets.update.notice')
        should_redirect_to('root path') { root_path }
      end
  
      context "submitting a new valid password and additional parameters" do
        setup do
          @email = @employer.email
          put :update, :id => @employer.perishable_token, :employer => {:password => "kokowawata", :password_confirmation => "kokowawata", :email => "sewsew@weswes.com"}
        end
        should_assign_to :employer
        should("update password only") { assert_equal assigns(:employer).reload.email, @email }
        should_set_flash_of_to :notice, I18n.t('flash.password_resets.update.notice')
        should_redirect_to('root path') { root_path }
      end      
      
    end
  end
end