require File.dirname(__FILE__) + '/../../test_helper'

class Employers::SessionsControllerTest < ActionController::TestCase
  Password = "passwordhahaha"
  should_require_no_user_for(:get => [:new], :post => [:create])
  should_require_employer_for(:delete => [:destroy])
  
  context "A non logged in employer" do
    context "that exists" do
      setup do
        @employer = Factory.create :employer, :password => Password, :password_confirmation => Password
        clear_employer_session
        post :create, :employer_session => {:email => @employer.email, :password => Password}
      end
      should_redirect_to("employer's main page") { employer_path(@employer) }
    end
    
    context "that doesn't exist" do
      setup do
        post :create, :employer_session => {:email => "fjskdfjls@jflks.com", :password => Password}
      end
      should_render_template :new
    end
  end
end
