require File.dirname(__FILE__) + '/../test_helper'

class EnquiriesControllerTest < ActionController::TestCase

  context "A guest trying to make an enquiry" do
    context "with valid data" do
      setup do
        @deliveries_count = EnquiryMailer.deliveries.length
        xhr :put, :create, :enquiry => Factory.attributes_for(:enquiry)
      end
      should("send the enquiry") { assert_equal @deliveries_count + 1, EnquiryMailer.deliveries.length }
      should_set_flash_of_to(:notice, I18n.t('flash.enquiry_sent'))
      should_respond_with :success
      should_render_template :create
    end

    context "with invalid data" do
      setup do
        @deliveries_count = EnquiryMailer.deliveries.length
        xhr :put, :create, :enquiry => {}
      end
      should("not send the enquiry") { assert_equal @deliveries_count, EnquiryMailer.deliveries.length }
      should_respond_with :success
      should_render_template :create
    end

  end

end
