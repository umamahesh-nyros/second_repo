require File.dirname(__FILE__) + '/../test_helper'

class AutocompleteControllerTest < ActionController::TestCase

[:institutions, :countries, :cities].each do |collection|
  context "Using Autocompleter for #{collection}" do
    setup do
      @results = []
      Sunspot::Search.class_mock(:results => @results) do
        get collection
      end
    end
    should_respond_with :success
    should("return proper results") {assert_equal @response.body, @results.to_json}
  end
end

end
