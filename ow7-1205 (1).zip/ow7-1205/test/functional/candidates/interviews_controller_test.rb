require File.dirname(__FILE__) + '/../../test_helper'

class Candidates::InterviewsControllerTest < ActionController::TestCase
  should_require_candidate_for(:get => [:index, :show],
                               :put => [:update])
  
  context "with a logged in candidate" do
    setup { @candidate = Factory.create(:candidate); CandidateSession.create(@candidate) }
    context "who has been invited to an interview" do
      setup do
        @interview = Factory.create :interview_with_fake_slots
        @application = Vacancies::Application.create! :candidate_id => @candidate.id, :vacancy_id => @interview.vacancy_id
        @connection = @interview.connections.create!(:candidate_id => @candidate.id)
      end
      
      context "trying to view his interviews" do
        setup { get :index }
        should_respond_with :success
      end
      
      context "trying to view a certain interview" do
        setup { get :show, :id => @connection.id }
        should_respond_with :success
      end
      
      context "trying to register a slot" do
        setup { put :update, :id => @connection.id, :slot_id => @interview.slots.first.id }
        should_redirect_to("candidate interview path") {candidates_interview_path(@connection.id)}
      end
    end
  end
end
