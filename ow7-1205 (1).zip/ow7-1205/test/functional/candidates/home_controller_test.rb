require File.dirname(__FILE__) + '/../../test_helper'

class Candidates::HomeControllerTest < ActionController::TestCase
  should_require_candidate_for(:get => [:show])
  context "A logged in candidate" do
    setup do
      @candidate = Factory.create :candidate
      CandidateSession.create @candidate
    end
    context "trying to view his homepage" do
      setup do
        Sunspot::Search.class_mock(:results => []) do
          get :show
        end
      end
      should_respond_with :success
      should_render_template :show
      
    end
  end
end
