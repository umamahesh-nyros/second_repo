require File.dirname(__FILE__) + '/../../test_helper'

class Candidates::SessionsControllerTest < ActionController::TestCase
  Password = "passwordhahaha"
  should_require_no_user_for(:get => [:new], :post => [:create])
  should_require_candidate_for(:delete => [:destroy])
  
  context "A non logged in candidate" do
    context "who had tried to apply for a vacancy" do
      setup do
        @vacancy_1 = Factory.create :vacancy, :city => City.saudi.rand 
        clear_employer_session
        session[:after_login] = {}
      end
      
      context "that exists" do
        context "and has no redirection url" do
          setup { session[:after_login][:apply_to] = @vacancy_1.id }
          
          context "trying to login" do
            setup do
              @candidate = Factory.create :candidate, :password => Password
              clear_candidate_session
              post :create, :candidate_session => {:email => @candidate.email, :password => Password}
              @candidate.reload
            end
            
            should_set_flash_of_to(:notice, I18n.t('flash.jobs.vacancy.candidate.applied'))
            should_redirect_to("candidate home url") { candidates_home_path }
            should("add vacany to applications") {assert_equal @vacancy_1, @candidate.vacancies.first}
          end        
        end
        context "and has a redirection url" do
          setup do
            @url = "http://applications.somecompany.com"
            job = @vacancy_1.job
            job.application_url = @url
            job.save!
            session[:after_login][:apply_to] = @vacancy_1.id
          end
          
          context "trying to login" do
            setup do
              @candidate = Factory.create :candidate, :password => Password
              clear_candidate_session
              post :create, :candidate_session => {:email => @candidate.email, :password => Password}
              @candidate.reload
            end
            
            should_redirect_to("application url") { @url }
            should("not add vacany to applications") { assert @candidate.vacancies.empty? }
          end        
        
        end

      end

      context "that does not exist" do
        setup { session[:after_login][:apply_to] = @vacancy_1.id + 1 }
        
        context "trying to login" do
          setup do
            @candidate = Factory.create :candidate, :password => Password
            clear_candidate_session
            post :create, :candidate_session => {:email => @candidate.email, :password => Password}
            @candidate.reload
          end
          
          should_set_flash_of_to(:error, I18n.t('flash.jobs.job_not_found'))
          should_redirect_to("candidate home url") { candidates_home_path }
          should("not add vacany to applications") {assert_equal 0, @candidate.vacancies.count}
        end        
      end

    end

    context "who had tried to comment on a vacancy" do
      setup do
        @vacancy_1 = Factory.create :vacancy, :city => City.saudi.rand
        clear_employer_session
      end
      
      context "who had tried to comment on a vacancy" do
        setup do
          get :new, :go_to => vacancy_path(@vacancy_1)
        end
        
        context "trying to login" do
          setup do
            @candidate = Factory.create :candidate, :password => Password
            clear_candidate_session
            post :create, :candidate_session => {:email => @candidate.email, :password => Password}
          end
          
          should_redirect_to("vacancy path") { vacancy_path @vacancy_1 }
        end
      end
    end
    
    context "that doesn't exist" do
      setup do
        post :create, :candidate_session => {:email => "fjskdfjls@jflks.com", :password => Password}
      end
      should_render_template :new
    end
  end
end
