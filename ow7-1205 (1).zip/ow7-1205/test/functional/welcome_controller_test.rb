require File.dirname(__FILE__) + '/../test_helper'

class WelcomeControllerTest < ActionController::TestCase
  context "with hot jobs" do
    setup do
      @vacancies = []
      3.times do
        v = Factory.create(:vacancy)
        v.hot = true
        v.save
        @vacancies << v
      end
      
    end
    
    context "A guest visiting the front (welcome) page" do
      setup do
        Sunspot::Search.class_mock(:results => @vacancies) do
          xhr :get, :index
        end
      end
      should("return hot jobs") { assert_equal @vacancies, assigns["hot_jobs"]}
      should_render_template :index
      should_respond_with :success
    end
    
  end

  [:contact, :privacy, :terms, :about].each do |static|
    context "A guest visiting the #{static} page" do
      setup { get static }
      
      should_render_template static
      should_respond_with :success
    end
  end
  
end
