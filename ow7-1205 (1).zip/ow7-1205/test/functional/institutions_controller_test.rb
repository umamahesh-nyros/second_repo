require File.dirname(__FILE__) + '/../test_helper'

class InstitutionsControllerTest < ActionController::TestCase
  should_require_admin_for!({:get => [:index],
                            :put => [:update, :merge],
                            :delete => [:destroy]})
  
  context "A logged in admin" do
    setup { @admin = Factory.create(:admin); AdminSession.create(@admin) }
    context "POSTing to create a new institution" do
      setup { post :create, :institution => {:name => "Lolo", :country_id => Factory.create(:country).id} }
      should_respond_with :success
      should("mark the institution as system") { assert assigns(:institution).adder_type_system? }
      
      context "then trying to view a list of institutions" do
        setup {Sunspot::Search.class_mock(:results => WillPaginate::Collection.new(1,1,1)) {get(:index)}}
        should_respond_with :success
        should_render_template :index
      end
      
      context "then destroying the newly created institution" do
        setup { xhr :delete, :destroy, :id => Institution.last.id}
        should_respond_with :success
      end
      
      context "then trying to update the newly created institution with invalid params" do
        setup { xhr :put, :update, :id => Institution.last.id, :institution => {:name => ""}}
        should_respond_with ApplicationController::HTTP_STATUS[:failure]
      end
      
      context "then trying to update the newly created institution with valid params" do
        setup { xhr :put, :update, :id => Institution.last.id, :institution => {:name => "haw haw"}}
        should_respond_with :success
      end
      
      context "trying to destroy an institution associated with candidates" do
        setup do
          @institution = Factory.create(:candidate).degrees.first.institution
          xhr :delete, :destroy, :id => Institution.last.id
        end
        should_respond_with ApplicationController::HTTP_STATUS[:failure]
      end
    end
    
    context "trying to view a list of institutions with no institutions in the system" do
      setup {Sunspot::Search.class_mock(:results => WillPaginate::Collection.new(1,1,1)) {get(:index)}}
      should_respond_with :success
      should_render_template :index
    end
  end
  
  context "Anyone other than the admin" do
    context "POSTing to create a new institution" do
      setup { post :create, :institution => {:name => "Lolo", :country_id => Factory.create(:country).id} }
      should_respond_with :success
      should("mark the institution as system") { assert assigns(:institution).adder_type_other? }
    end
  end
end
