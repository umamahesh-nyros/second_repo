require File.dirname(__FILE__) + '/../test_helper'

class CommentsControllerTest < ActionController::TestCase
  
  context "A guest" do
    context "trying to create a new comment (POST to create)" do
      setup { post :create, {}}
      should_set_flash_of_to(:error, I18n.t('flash.users.user_not_authorized'))
      should_redirect_to("root_path") { root_path }
    end
    
    context "trying to delete a comment (DELETE to destroy)" do
      setup { delete :destroy, {}	}
      should_set_flash_of_to(:error, I18n.t('flash.users.user_not_authorized'))
      should_redirect_to("root_path") { root_path }
    end
    
    context "trying to create a new comment (POST to create) ajax" do
      setup { xhr :post, :create, {}}
      should("not be allowed") {assert_match /#{I18n.t('flash.users.user_not_authorized')}/, @response.cookies['flash_error']}
    end
    
    context "trying to delete a comment (DELETE to destroy) ajax" do
      setup { xhr :delete, :destroy, {}	}
      should("not be allowed") {assert_match /#{I18n.t('flash.users.user_not_authorized')}/, @response.cookies['flash_error']}
    end
    
    
  end
  
  [
  {:class => Vacancy, :factory => :vacancy, :name => 'vacancy'},
  ].each do |x|
    context "A logged in Employer" do
      setup do
        @employer = Factory.create :employer
        EmployerSession.create @employer
      end
      
      context "trying to add a comment on a #{x[:name]} with valid params" do
        setup do
          @commentable = Factory.create x[:factory]
          xhr	:post, :create,	{
	  				:commentable_type => x[:class].name,
	  				:commentable_id => @commentable.id,
	  				:comment => {:comment => "comment"}
          }
        end
        
        should ("increment the comments count by 1") { assert_equal(1, @commentable.comments.count) }
        should_respond_with :success
        should_render_template :create
      end
      
      context "trying to delete his comment on #{x[:name]}" do
        setup do
          @commentable = Factory.create x[:factory]
          @comment = Factory.create :comment, :commentable => @commentable, :commenter => @employer
          @count = @commentable.comments.count
          
          xhr(:post, :destroy, {:id => @comment.id })
        end
        
        should ("decrement comments count by 1") { assert_equal(@count - 1, @commentable.comments.count) }
        should("not find comment in #{x[:name]}'s comments") { assert_nil @commentable.comments.find_by_id(@comment.id) }
        should_respond_with :success
      end
      
      context "trying to delete a comment made on his #{x[:name]} profile" do
        setup do
          if x[:name] == 'vacancy'
            @job = Factory.create :job, :employer => @employer
            @commentable = Factory.create x[:factory], :job => @job
          end
          
          @another_user = Factory.create :employer
          @comment = Factory.create :comment, :commentable => @commentable, :commenter => @another_user
          @count = @commentable.comments.count	  					
          
          xhr(:post, :destroy, {:id => @comment.id })
        end
        
        should ("decrement comments count by 1") { assert_equal(@count - 1, @commentable.comments.count) }
        should("not find comment in #{x[:name]}'s comments") { assert_nil @commentable.comments.find_by_id(@comment.id) }
        should_respond_with :success
      end
      
      context "trying to delete a comment made on a #{x[:name]} when not authorized" do
        setup do
          @another_user = Factory.create :employer
          
          if x[:name] == 'vacancy'
            @job = Factory.create :job, :employer => @another_user
            @commentable = Factory.create x[:factory], :job => @job
          end
          
          @comment = Factory.create :comment, :commentable => @commentable, :commenter => @another_user
          @count = @commentable.comments.count	  					
          
          xhr(:post, :destroy, {:id => @comment.id })
        end
        
        should ("not change comments count") { assert_equal(@count, @commentable.comments.count) }
        should("find comment in #{x[:name]}'s comments") { assert @commentable.comments.exists?(@comment.id) }
        should_render_template :destroy
        should("not delete comment") { assert( @response.body.include?( I18n.t("flash.comments.not_deleted")) ) }
      end
    end	  
    
  end
end
