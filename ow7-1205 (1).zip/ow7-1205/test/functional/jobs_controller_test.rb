require File.dirname(__FILE__) + '/../test_helper'

class JobsControllerTest < ActionController::TestCase

  should_require_employer_for(:get => [:new, :edit], :put => [:update, :create])
  
  context "A visitor trying to search jobs" do
    setup {get :index}
    
    should_respond_with :success
    should_render_template :index
  end

  context "A visitor trying to search jobs with ajax" do
    setup do
      @results = [].paginate
      Sunspot::Search.class_mock(:results => @results) do
        xhr :get, :index, :q => {}
      end
    end
    should_respond_with :success
    should_render_template :index
  end

  context "An Employer having a job" do
      
    setup do
      @employer = Factory.create(:employer)
      @another_employer = Factory.create(:employer)
      @job = Factory.build :job, :employer => @employer
      @job.vacancies.build :city => City.saudi.rand
      @employer.jobs << @job
      @employer.save
      clear_employer_session
    end
    
    context "trying to post a new job" do
      setup do
        EmployerSession.create(@employer)
        @job_count = Job.count
        @vacancy_count = Vacancy.count
        
        filters = { :filter_1 => [], :filter_2 => [] }

        attrs = {
          :employer => @employer.attributes.merge(
            :city_id => Factory.create(:saudi_city).id,
            :jobs_attributes => {
              0 => Factory.attributes_for(:job,
                :vacancies_attributes => {0 =>{:city_id => City.saudi.rand.id}},
                :filters => filters
              )
            }
          )
        }

        post :create, attrs
        
      end
      should("increment the jobs count by 1") { assert_equal @job_count+1, Job.count}
      should("increment the vacancy count by 1") { assert_equal @vacancy_count+1, Vacancy.count}
      should_set_flash_of_to(:notice, I18n.t('flash.jobs.create.notice'))
      should_redirect_to("Employer main page") { employer_path @employer }
    end

    context "with another employer logged in" do
      setup { EmployerSession.create(@another_employer) }
  
      {:get => [:edit], :put => [:update]}.each do |method, actions|
        
          actions.each do |action|
            context "trying to #{method} to #{action}" do
              setup { send(method, action, :id => @job.id) }
              should_set_flash_of_to(:error, I18n.t('flash.users.user_is_not_current_employer'))
              should_redirect_to("employer_path") { employer_path(@another_employer) }
            end      
          end
              
      end
    end

  end
end
