require File.dirname(__FILE__) + '/../../test_helper'

class Vacancies::InterviewsControllerTest < ActionController::TestCase
  should_require_employer_for(:get => [:index, :show, :edit, :invite],
                              :put => [:update],
                              :post => [:create])
  
  context "with a logged in employer" do
    setup { @employer = Factory.create(:employer); EmployerSession.create @employer }
    
    context "trying to view another employer's vacancy interviews" do
      setup { @another_vacancy = Factory.create :vacancy }
      should("raise ActiveRecord::RecordNotFound") do
        assert_raise ActiveRecord::RecordNotFound do
          get :index, :vacancy_id => @another_vacancy.id
        end
      end
    end
    
    context "having a vacancy" do
      setup do
        @job = Factory.create :job_without_vacancies, :employer => @employer
        @vacancy = Factory.create :vacancy, :job => @job
      end
      context "trying to view its interviews" do
        setup { get :index, :vacancy_id => @vacancy.id }
        should_respond_with :success
      end
      
      context "trying to preview an interview with invalid params" do
        setup { post :create, :vacancy_id => @vacancy.id, :interviews_interview => {}, :preview => 1}
        should("have errors on @interview") { assert assigns(:interview).errors.length > 0 }
        should_render_template :new
      end
      
      context "trying to create an interview with invalid params" do
        setup { post :create, :vacancy_id => @vacancy.id, :interviews_interview => {}}
        should("have errors on @interview") { assert assigns(:interview).errors.length > 0 }
        should_render_template :new
      end
      
      context "trying to preview an interview with valid params" do
        setup { post :create, :vacancy_id => @vacancy.id, 
                     :interviews_interview => Factory.attributes_for(:interview_with_fake_slots,
                                                                     :vacancy => nil,
                                                                     :city_id => Factory.create(:city).id),
                     :preview => 1}
        should("have no errors on @interview") { assert_equal 0, assigns(:interview).errors.length }
        should_render_template :new
      end
      
      context "trying to create an interview with valid params" do
        setup { post :create, :vacancy_id => @vacancy.id, 
                     :interviews_interview => Factory.attributes_for(:interview_with_fake_slots,
                                                                     :vacancy => nil,
                                                                     :city_id => Factory.create(:city).id)}
        should("have no errors on @interview") { assert_equal 0, assigns(:interview).errors.length }
        should_redirect_to("interview path") { vacancy_interview_path(@vacancy, assigns(:interview)) }
      end
    end
  end
end
