require File.dirname(__FILE__) + '/../../test_helper'

class Vacancies::SlotsControllerTest < ActionController::TestCase
  should_require_employer_for(:delete => [:destroy])
end
