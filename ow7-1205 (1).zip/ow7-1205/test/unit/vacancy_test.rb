require File.dirname(__FILE__) + '/../test_helper'

class VacancyTest < ActiveSupport::TestCase
  should_validate_presence_of :city_id
  should_belong_to :job
  should_belong_to :city
  should("be rateable by candidate") { Vacancy.rateable_by?(Factory.create(:candidate)) }
  should("be not be rateable by a guest") { Vacancy.rateable_by?(nil) }
  [:admin, :employer].each do |user|
    should("be not be rateable by a #{user}") { Vacancy.rateable_by?(Factory.create(user)) }
  end
  
  context "Vacancy class" do
    context "having a candidate" do
      setup {@candidate = Factory.create :candidate}
      should("respond to for_candidate successfully") do
        assert Vacancy.for_candidate(@candidate)
      end
    end
  end
  
  context "A vacancy" do
    setup do
      @employer = Factory.create(:employer)
      @job = Factory.build :job, :employer => @employer
      @vacancy = Vacancy.new :city => City.saudi.rand
      @job.vacancies << @vacancy
      @job.save
    end
    [:title, :description, :weekend_id, :weekend,:employer_id, :employer, :type_id, :type,
     :saudi_status_ids, :gender_ids, :job_mixing_id, :degree_language_class_id,
     :degrees_group_ids,:degrees_institution_ids, :degrees_country_ids,
     :degrees_category_ids, :degrees_level_ids, :gpa_range_ids].each do |k|
       should("respond to #{k}") do
         assert @vacancy.respond_to?(k)
       end
    end
  end
  context "An Employer having job vacancies" do
      
    setup do
      @employer = Factory.create(:employer)
      @job = Factory.build :job, :employer => @employer
      @vacancy = Vacancy.new :city => City.saudi.rand
      @job.vacancies << @vacancy
      @job.save
      @applied = @vacancy.candidates.count
      @candidate = Factory.create(:candidate)
    end
    
    context "A candidate applying to a job vacancy" do
      setup do        
        @vacancy.add_application!(@candidate)
      end
      should("apply for the job") { assert @applied + 1, @vacancy.candidates.count }
    end

    context "A candidate trying to re-apply to a job vacancy" do
      setup do
        @vacancy.applications.create(:candidate => @candidate)
        @count = @vacancy.applications.count
      end
      should("not re-apply for the job") do
        #assert_raise_message("applied", RuntimeError) do
        assert_raise RuntimeError do
          @vacancy.add_application!(@candidate)
        end      
      end
    end
  end

  context "Deleting the last vacancy of a job" do
    setup do
      @job = Factory.build :job, :vacancies_attributes => []
      @vacancy = @job.vacancies.build(:city => City.saudi.first)
      @job.save!
      @job_count = Job.count
      @vacancy.destroy_job_if_last
    end
    should("delete the job") {assert_equal @job_count - 1, Job.count}
        
  end
end
