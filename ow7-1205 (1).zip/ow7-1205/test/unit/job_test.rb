require File.dirname(__FILE__) + '/../test_helper'

class JobTest < ActiveSupport::TestCase
  should_validate_presence_of :title
  should_validate_presence_of :type_id
  should_validate_presence_of :employer_id
  
  context "An ngo job" do
    setup { @job = Factory.create(:ngo).jobs.build }
    subject { @job }
    should_validate_presence_of :employer_name
    should_validate_presence_of :employer_city_id
    should_validate_presence_of :employer_website
    context "with company attributes set" do
      setup do
        @job.employer_name = "koko wawa"
        @job.employer_website = "http://www.kokowawahawhaw.com"
      end
      should("get the proper company_name") { assert_equal "koko wawa", @job.company_name }
      should("get the proper company_website") { assert_equal "http://www.kokowawahawhaw.com", @job.company_website }
      should("get the proper company_logo") { assert_equal @job.employer_logo, @job.company_logo }
    end
  end
  
  context "creating a job with filters set" do
    setup do
      @filters = {
        :degree_language_class_id => Candidate::DegreeLanguageClasses[:en_bachelor],
        :saudi_status_ids => [Candidate::SaudiStatus[:saudi]],
        :gender_ids => [Candidate::Gender[:female]],
        :job_mixing_ids => [Candidate::MixingLevels[:unsegregated_conservative]],
      }.with_indifferent_access
      
      @job = Factory.build(:job, :filters => @filters)
      @vacancy = Vacancy.new :city => City.saudi.rand
      @job.vacancies << @vacancy
      @job.save
      @applied = @vacancy.candidates.count
    end
    
    should("have filters set properly") { assert_equal @job.filters, @filters }
    
    context "with an accepted Candidate applying with Matching screening criteria" do
      setup do
        @candidate = Factory.build(:accepted_candidate,
          :gender_id => Candidate::Gender[:female],
          :job_mixing_id => Candidate::MixingLevels[:unsegregated_conservative],
          :degrees => [ 
        Factory.build(:degree, 
              :institution => Factory.create(:english_university),
              :level_id => Degree::Levels[:phd],
              :gpa => 3.8,
              :category => Factory.create(:category, :level_id => Category::Levels[:a]))
        ]
        )
        @candidate.countries << Country.saudi_arabia        
        @candidate.save!
        @vacancy.add_application!(@candidate)
      end
      should("pass screening") do
        assert @applied + 1, @vacancy.candidates.count
        assert @vacancy.applications.last.screening
      end
    end
    
    context "with a rejected Candidate applying with Matching screening criteria" do
      setup do
        @candidate = Factory.build(:rejected_candidate,
          :gender_id => Candidate::Gender[:female],
          :job_mixing_id => Candidate::MixingLevels[:unsegregated_conservative],
          :entry_level => false, # rejection cause
          :degrees => [ 
        Factory.build(:degree, 
              :institution => Factory.create(:english_university),
              :level_id => Degree::Levels[:phd],
              :gpa => 3.8,
              :category => Factory.create(:category, :level_id => Category::Levels[:a]))
        ]
        )
        @candidate.countries << Country.saudi_arabia   
        @candidate.save!
        @vacancy.add_application!(@candidate)
      end
      
      should("not pass screening") do
        assert @applied, @vacancy.candidates.count
        assert !@vacancy.applications.last.screening
      end
    end
    
    context "with an accepted Candidate applying with non-matching screening criteria" do
      setup do
        @candidate = Factory.build(:accepted_candidate,
          :gender_id => Candidate::Gender[:male], # non-matching criterion
          :job_mixing_id => Candidate::MixingLevels[:unsegregated_conservative],
          :degrees => [ 
        Factory.build(:degree, 
              :institution => Factory.create(:institution), # non-matching criterion
              :level_id => Degree::Levels[:diploma], # non-matching criterion
              :gpa => 3.8,
              :category => Factory.create(:category, :level_id => Category::Levels[:b]))
        ]
        )
        @candidate.countries << Country.saudi_arabia   
        @candidate.save!
        @vacancy.add_application!(@candidate)
        @candidate.reload
      end
      
      should("not pass screening") do
        assert @applied, @vacancy.candidates.count
        assert !@vacancy.applications.last.screening
      end
      
      context "and after changing his info into matching criteria" do
        setup do
          @candidate.update_attributes({
            :gender_id => Candidate::Gender[:female],
            :job_mixing_id => Candidate::MixingLevels[:unsegregated_conservative],
            :degrees => [ 
            Factory.build(:degree, 
                :institution => Factory.create(:english_university),
                :level_id => Degree::Levels[:phd],
                :gpa => 3.8,
                :category => Factory.create(:category, :level_id => Category::Levels[:a]))
            ]                
          })
          
        end
        
        should("update his screening status") do
          assert @candidate.applications.last.screening
        end
      end
    end
    
  end
end
