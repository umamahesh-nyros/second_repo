require File.dirname(__FILE__) + '/../test_helper'

class InvitationTest < ActiveSupport::TestCase
  should_allow_values_for :type_id, *Invitation.types.values
  [:employer, :ngo].each do |type_key|
    context "An #{type_key} invitation" do
      setup {@invitation = Invitation.new(:type_id => Invitation.types[type_key])}
      subject {@invitation}
      should_validate_presence_of :first_name
      should_validate_presence_of :last_name
    end
  end
  
  context "creating a new invitation" do
    setup { @i = Invitation.new }
    should("be marked as unused") do
      assert(@i.unused?)
      assert(!@i.used?)
    end
    
    context "its code" do 
      setup {@i = Invitation.new; @i.valid?}
      should("be created automatically") { assert(@i.code); assert_equal(nil, @i.errors.on(:code))}  
    end
    
    context "with an invalid email" do
      setup {@i.email = "koko"; @i.valid?}
      should("have errors on email") {assert @i.errors.on(:email).length > 0}
    end
    
    context "with a valid email" do
      setup {@i.email = "koko@soso.com"; @i.valid?}
      should("have no errors on email") {assert_equal nil, @i.errors.on(:email)}
    end    
  end
end
