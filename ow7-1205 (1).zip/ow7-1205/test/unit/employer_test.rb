require File.dirname(__FILE__) + '/../test_helper'

class EmployerTest < ActiveSupport::TestCase
  should_validate_presence_of :name
  should_validate_presence_of :person_name
  should_validate_presence_of :website
  should_validate_presence_of :city_id
  should_validate_presence_of :phone
  #TODO should validate format of website
  #TODO should validate format of phone
  
  should_not_allow_mass_assignment_of :crypted_password, :password_salt,
                                      :persistence_token, :single_access_token,
                                      :perishable_token, :email, :password,
                                      :status_id, :paid, :paid_expiry_date
  
  context "creating an employer without an invitation" do
    setup { @employer = Factory.build(:employer, :invitation => nil) }
    should("fail") do
      assert !@employer.save
      assert @employer.errors.on(:invitation)
    end
  end
  
  context "having an invitation" do
    setup { @invitation = Factory.create :invitation; raise if @invitation.used? }
    context "having a new employer use it" do
      setup { @employer = Factory.create :employer, :invitation => @invitation }
      should "mark the invitation as used" do
        assert @invitation.reload.used?
      end
    end
  end
  
  [:email, :password].each do |attr|
    should "validate presence of #{attr}" do
      u = Factory.build(:employer, attr => nil)
      assert u.new_record?
      assert !u.valid?
      assert u.errors.on(attr) 
    end  
  end
  
  context "for an employer" do
    setup { @employer = Factory.create :employer }
    ["block", "block!"].each do |m|
      context "calling #{m}" do
        should("change the employer's status to blocked") do
          assert @employer.send(m)
          assert @employer.status_blocked?
          assert_sent_email
        end
        ["unblock", "unblock!"].each do |m2|
          context "then calling #{m2}" do
            should("return the employer's status to its original value") do
              assert @employer.send(m2)
              assert @employer.status_active?
              assert_sent_email
            end
          end
        end
        context "then calling request_unblock!" do
          should("change the employer's status to unblock_requested") do
            assert @employer.request_unblock!
            assert @employer.status_unblock_requested?
          end
        end
      end  
    end
  end
  
  context "for a bunch of employers" do
    setup do 
      @employers = (1..5).collect {Factory.create(:employer)}.sort {|a,b| a.id <=> b.id}
      @status_id = @employers[0].status_id
      @ids = @employers.collect &:id
    end
    ["mass_block!"].each do |m|
      context "calling #{m}" do
        should("change the employer's status to blocked") do
          assert Employer.send(m, @ids)
          Employer.find(@ids).each {|c| assert c.status_blocked? }
        end
        ["mass_unblock!"].each do |m2|
          context "then calling #{m2}" do
            should("return the employer's status to active") do
              assert Employer.send(m2, @ids)
              Employer.find(@ids).each {|c| assert_equal @status_id, c.status_id }
            end
          end
        end
      end  
    end
  end
  
  context "an employer with comments and jobs with applications" do
    setup do
      @employer = Factory.create :employer
      @article = Factory.create :admin_article
      @comment = Factory.create :comment, :commenter => @employer, :commentable => @article
      
      @candidate = Factory.create :candidate
      @job = Factory.create :job, :employer => @employer
      @vacancy = Vacancy.new :city => City.saudi.rand
      @job.vacancies << @vacancy
      @vacancy.add_application!(@candidate)
      @application = Vacancies::Application.find_by_candidate_id_and_vacancy_id!(@candidate.id, @vacancy.id)
      
      [@comment, @vacancy, @application].map &:reload
      
      raise unless @comment.status_visible?
      raise unless @vacancy.status_visible?
      raise unless @application.status_visible?
    end
    context "when blocking him" do
      setup { @employer.block! }
      should("mark comments, vacancies, applications as hidden") do
        assert @comment.reload.status_hidden?
        assert @vacancy.reload.status_hidden?
        assert @application.reload.status_hidden?
      end
      
      context "then unblocking him" do
        setup { @employer.unblock! }
        should("mark comments, vacancies, applications as visible") do
          assert @comment.reload.status_visible?
          assert @vacancy.reload.status_visible?
          assert @application.reload.status_visible?
        end  
      end
    end
  end
  
  context "for a non-paying employer" do
    setup { @employer = Factory.create :employer }
    context "marking him as paying" do
      context "with invalid expiry date" do
        setup { @employer.paying_till("") }
        should("mark employer with errors") { assert @employer.errors.on(:paid_expiry_date).present? }
        should("not set the employer paying") { assert !@employer.paying? }
      end

      context "with valid expiry date" do
        setup { @employer.paying_till(Date.today + 3.months) }
        should("not mark employer with errors") { assert @employer.errors.blank? }
        should("set the employer as paying") { assert @employer.paying? }
      end

    end
  end

  context "for a paying employer" do
    setup { @employer = Factory.create :employer; @employer.paying_till(Date.today + 3.months) }
    context "marking him as non-paying" do
      setup { @employer.non_paying }
      should("set the employer as non-paying") { assert @employer.non_paying? }
    end
  end

  context "for paying employers including employers with expired payments" do
    setup do
      @employer = Factory.create :employer; @employer.paying_till(Date.today + 3.months)
      @employer_to_expire = Factory.create :employer; @employer_to_expire.paying_till(Date.yesterday)
      employer1 = Factory.create :employer; employer1.paying_till(Date.today + 1.day)
      employer7 = Factory.create :employer; employer7.paying_till(Date.today + 7.days)
      employer14 = Factory.create :employer; employer14.paying_till(Date.today + 14.days)
      @employers_to_notify = [employer1, employer7, employer14]
      @deliveries_count = EmployerMailer.deliveries.length
    end
    
    should("have criteria for expiry for expired payments") do
      assert @employer_to_expire.paying?
      assert @employer_to_expire.expiry_date_passed?
      assert @employer_to_expire.should_expire_payment?
    end
    
    should("have notification criteria set") do
      assert @employers_to_notify.inject(true) {|s, e| s && e.should_send_payment_expiry_notification? }
    end
    
    context "after running check payments task" do
      setup { Employer.check_payments; [@employer, @employer_to_expire].each &:reload; @employers_to_notify.each &:reload }
      should("have the employers set to proper states") do
        assert( (@employers_to_notify + [@employer]).inject(true) {|s, e| e.paying? } )
        assert @employer_to_expire.expired_paying?
      end
      should("send notifications for the right employers") do
        assert_equal @deliveries_count + @employers_to_notify.length, EmployerMailer.deliveries.length
        @employers_to_notify.each do |employer|
          assert_sent_email do |email|
            email.subject == I18n.t('email.employers.payment_expiry_notification.subject') &&
            email.to.include?(employer.email) &&
            email.body.include?("#{employer.days_to_expiry} day")
          end        
        end
      end
    end
  end
  
end
