require File.dirname(__FILE__) + '/../../test_helper'

class Vacancies::ApplicationTest < ActiveSupport::TestCase
  should_validate_presence_of :candidate_id
  should_validate_presence_of :vacancy_id
  
  #--Associations--#
  should_belong_to :candidate
  should_belong_to :vacancy
end
