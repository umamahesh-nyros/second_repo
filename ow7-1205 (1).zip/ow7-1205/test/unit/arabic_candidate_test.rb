require File.dirname(__FILE__) + '/../test_helper'

class ArabicCandidateTest < ActiveSupport::TestCase
  should_validate_presence_of :name
  should_validate_presence_of :cv
end
