require File.dirname(__FILE__) + '/../test_helper'

class InstitutionTest < ActiveSupport::TestCase
  should_validate_presence_of :name, :country_id
  should_not_allow_mass_assignment_of :adder_type_id
  
  context "A new institution" do
    setup do
      @institution = Institution.new :name => "koko"
      @institution.adder_type_id = Institution::AdderTypes[:system].id
    end
    context "with a country without a default language" do
      setup do
        @country = Factory.create :country
        @institution.country = @country
      end
      should "not be assigned a language" do
        assert @institution.save!
        assert_nil @country.degree_language_id
        assert_nil @institution.language_id
      end
      context "the institution having a language" do
        setup do
          @language = Factory.create :language
          @institution.language = @language 
        end
        should "have that assigned language set correctly" do
          assert @institution.save!
          assert_equal @language, @institution.language
        end
      end
    end
    
    context "with a country that has a default language" do
      setup do
        @country_language = Factory.create :language
        @country = Factory.create :country, :degree_language => @country_language
        @institution.country = @country
      end
      should "not be assigned the country's language" do
        assert @institution.save!
        assert_equal @country_language.id, @institution.language_id
      end
      context "and the institution having its own language set" do
        setup do
          @institution_language = Factory.create :language
          @institution.language = @institution_language 
        end
        should "take that language value, not the country's" do
          assert @institution.save!
          assert_equal @institution_language.id, @institution.language_id
        end
      end
    end
  end
  
  context "With one institution and a list of other institutions (none of them have candidates)" do
    setup do
      @institution = Factory.create :institution
      @institutions = (1..5).collect {|i| Factory.create(:institution)}
      @institutions_count = Institution.count
    end
    context "trying to merge the list into the one" do
      setup {Institution.merge!(@institution.id, @institutions.collect {|i| i.id})}
      should("succeed") {assert_equal @institutions_count-5, Institution.count}
    end
  end
  
  context "With one institution and a list of other institutions (all of them have candidates)" do
    setup do
      @institution = Factory.create(:candidate).degrees.first.institution
      @institutions = (1..5).collect {|i| Factory.create(:candidate).degrees.first.institution}
      @ids = @institutions.collect {|i| i.id}
      @institutions_count = Institution.count
      @degrees_count = Degree.institution_id_equals(@ids + [@institution.id]).count 
      raise("No degrees associated with institutions") if Degree.count(:conditions => {:institution_id => @ids}) == 0
    end
    context "trying to merge the list into the one" do
      setup {Institution.merge!(@institution.id, @ids)}
      should("succeed") do
        assert_equal @institutions_count-5, Institution.count
        assert_equal 0, Degree.institution_id_equals(@ids).count
        assert_equal @degrees_count, Degree.institution_id_equals(@institution.id).count
      end
    end
  end
end
