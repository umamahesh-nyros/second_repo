require File.dirname(__FILE__) + '/../test_helper'

class CategoryTest < ActiveSupport::TestCase
  should_validate_presence_of :name
  should_validate_presence_of :level_id
  
  context "A category" do
    setup do
      @parent = Factory.create :sub_category
      @category = Factory.build :category
    end
    context "that's set to be a level more than 2" do
      setup {@category.parent = @parent }
      should("not be accpeted") do
        assert !@category.valid?
        assert @category.errors.full_messages.include?(I18n.t("activerecord.errors.full_messages.category_2_levels_only"))
      end
    end
  end
end
