require File.dirname(__FILE__) + '/../test_helper'

class AdminTest < ActiveSupport::TestCase

  context "creating an admin" do
    setup do
      @deliveries_count = AdminMailer.deliveries.length
      @admin = Factory.create :admin
    end
    
    should("send an email with activation instructions") do
      assert_equal(@deliveries_count + 1, AdminMailer.deliveries.length)
    end
  end

end
