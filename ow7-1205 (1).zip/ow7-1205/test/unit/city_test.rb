require File.dirname(__FILE__) + '/../test_helper'

class CityTest < ActiveSupport::TestCase
  should_validate_presence_of :name, :country_id
  
  #--Associations--#
  should_belong_to :country

end
