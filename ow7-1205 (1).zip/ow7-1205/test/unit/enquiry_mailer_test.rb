require File.dirname(__FILE__) + '/../test_helper'

class EnquiryMailerTest < ActionMailer::TestCase

  context "A guest trying to make an enquiry" do
    setup do
      @e = Factory.build :enquiry
      @deliveries_count = EnquiryMailer.deliveries.length
      @email = EnquiryMailer.deliver_contact_us_enquiry(@e)
    end
    should("send the enquiry") { assert_equal(@deliveries_count + 1, EnquiryMailer.deliveries.length) }
    should("have email info set properly") do
      assert_equal ["#{AppConfig.contact_us}"], @email.to
      assert_equal [I18n.t('email.contact_us_enquiry.from')], @email.from
      assert_equal I18n.t('email.contact_us_enquiry.subject'), @email.subject
    end
    should("deliver enquiry data") do
      assert_match /#{@e.name}/, @email.body
      assert_match /#{@e.email}/, @email.body
      assert_match /#{@e.subject}/, @email.body
      assert_match /#{@e.email}/, @email.body
    end
  end

end
