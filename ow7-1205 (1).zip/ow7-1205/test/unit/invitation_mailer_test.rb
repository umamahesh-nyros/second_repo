require File.dirname(__FILE__) + '/../test_helper'

class InvitationMailerTest < ActionMailer::TestCase

  context "A logged in admin trying to invite an employer" do
    setup do
      @admin = Factory.create :admin
      @invitation = Factory.create :invitation, :admin => @admin
      @deliveries_count = InvitationMailer.deliveries.length
      @email = InvitationMailer.deliver_employer_invitation(@invitation)
    end
    should("send the message") { assert_equal(@deliveries_count + 1, InvitationMailer.deliveries.length) }
    should("have email recipient set") { assert_equal [@invitation.email], @email.to }
    should("deliver personal message") { assert_match /#{@invitation.message}/, @email.body }
  end

end
