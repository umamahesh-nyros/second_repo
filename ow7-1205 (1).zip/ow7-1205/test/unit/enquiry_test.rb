require File.dirname(__FILE__) + '/../test_helper'

class EnquiryTest < ActiveSupport::TestCase
  should_allow_values_for :type_id, *Enquiry::Type.values
  should_validate_presence_of :name
  should_validate_presence_of :email
  should_validate_presence_of :type_id

  context "A new Enquiry" do
    setup do
      @e = Enquiry.new
    end

    context "with an invalid email" do
      setup {@e.email = "koko"; @e.valid?}
      should("have errors on email") {assert @e.errors.on(:email).length > 0}
    end
    
    context "with a valid email" do
      setup {@e.email = "koko@soso.com"; @e.valid?}
      should("have no errors on email") {assert_equal nil, @e.errors.on(:email)}
    end    

  end

  context "sending an enquiry" do
    setup do
      @e = Factory.build :enquiry
      @e.send_email
      @deliveries_count = EnquiryMailer.deliveries.length
      @email = EnquiryMailer.deliver_contact_us_enquiry(@e)
    end
    should("send it") { assert_equal(@deliveries_count + 1, EnquiryMailer.deliveries.length) }
  end
  

end
