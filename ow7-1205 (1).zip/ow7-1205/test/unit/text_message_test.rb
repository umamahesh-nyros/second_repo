require File.dirname(__FILE__) + '/../test_helper'

class TextMessageTest < ActiveSupport::TestCase
  should_validate_presence_of :to
  should_validate_presence_of :body

  context "creating a new text message" do
    setup { @m = TextMessage.new(:body => "blah") }

    context "with phone numbers array" do
      setup {@m.numbers = ["koko", "wawa"]}
      should("have 'to' string set") do
        assert_equal "koko,wawa", @m.to
      end
    end

    context "with 'to' string" do
      setup {@m.to = "koko,wawa"}
      should("have phone numbers array built on request") do
        assert_equal ["koko", "wawa"], @m.numbers
      end
    end    


    context "with invalid phone numbers" do
      setup {@m.numbers = ["koko"]; @m.valid?}
      should("have errors on phone number") do
        assert @m.errors.on(:to).length > 0
        assert @m.number_errors["koko"]
      end
    end

    context "with no phone number" do
      setup {@m.valid?}
      should("have errors on email") do
        assert @m.errors.on(:to).length > 0
        assert @m.number_errors[:blank]
      end
    end    

    context "with blank phone number" do
      setup {@m.numbers = [""]; @m.valid?}
      should("have errors on email") do
        assert @m.errors.on(:to).length > 0
        assert @m.number_errors[:blank]
      end
    end

    context "with mixed blank and present phone numbers" do
      setup {@m.numbers = ["", "01388383838"]; @m.valid?}
      should("have no errors on email") do
        assert_equal nil, @m.errors.on(:to)
        assert !@m.number_errors["018928282828"]
      end
      should("have blank numbers removed") { assert @m.numbers = ["01388383838"]}
    end
    
    context "with a valid phone numbers" do
      setup {@m.numbers = ["018928282828", "2112121878127"]; @m.valid?}
      should("have no errors on email") do
        assert_equal nil, @m.errors.on(:to)
        assert !@m.number_errors["018928282828"]
      end
      
      context "after saving the sms" do
        setup { @m.save }
        should("have the message queued for sending") { assert_equal @m, TextMessage.all.last }
        context "after processing SMSs" do
          setup { TextMessage.process }
          should("have message sent") do
            assert TextMessage.all.empty?
            assert SMSSender.sms_requests.include?([@m.to, @m.body])
          end
        end
      end
    end

  end

end
