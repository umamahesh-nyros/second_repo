require File.dirname(__FILE__) + '/../test_helper'

class EventTest < ActiveSupport::TestCase
  should_validate_presence_of :creator_id
  should_allow_values_for :creator_type, Admin.name, Employer.name
  should_validate_presence_of :title, :start_time, :end_time, :location
  status_ids = Event::Status.all.collect {|s| s.id}.sort
  type_ids = Event::Types.all.collect {|s| s.id}.sort
  gender_ids = Event::AllowedGenderValues.sort
  should_ensure_value_in_range :status_id, status_ids.first..status_ids.last,
                                 :low_message => I18n.translate('activerecord.errors.models.event.inclusion'),
                                 :high_message => I18n.translate('activerecord.errors.models.event.inclusion')
  should_ensure_value_in_range :type_id, type_ids.first..type_ids.last,
                                 :low_message => I18n.translate('activerecord.errors.models.event.inclusion'),
                                 :high_message => I18n.translate('activerecord.errors.models.event.inclusion')
  should_ensure_value_in_range :employer_gender, gender_ids.first..gender_ids.last,
                                 :low_message => I18n.translate('activerecord.errors.models.event.inclusion'),
                                 :high_message => I18n.translate('activerecord.errors.models.event.inclusion')
  should_ensure_value_in_range :candidate_gender, gender_ids.first..gender_ids.last,
                                 :low_message => I18n.translate('activerecord.errors.models.event.inclusion'),
                                 :high_message => I18n.translate('activerecord.errors.models.event.inclusion')
  
  context "creating a draft event" do
    setup { @event = Factory.create :draft_admin_event}
    should("not set its published_at") do
      assert_nil @event.published_at
    end
    
    context "then publishing it" do
      setup { @event.status_id = Event::Status[:published].id; @event.save! }
      should("set its publish date") {assert !@event.published_at.blank?}
      context "having a certain number of employers" do
        setup {5.times {Factory.create :employer}}
        should("send emails to all of them") {assert ActionMailer::Base.deliveries.length >= Employer.count}
      end
    end
  end
  
  context "creating an event" do
    setup { @t = Time.now; @event = Factory.create :admin_event}
    should("set its published_at") { assert @event.published_at > @t}
  end
  
  context "A published event" do
    context "by an admin" do
      setup { @event = Factory.create(:admin_event) }
      [nil, Factory.create(:candidate), Factory.create(:employer), Factory.create(:admin)].each do |user|
        should("be viewable by #{user.nil? ? "guests" : user.class.name.pluralize}") { assert @event.viewable_by?(user) }
      end
      
      should("be editable by any admin") { assert @event.editable_by?(Factory.create(:admin))}
      should("not be editable by guests") { assert !@event.editable_by?(nil)}
      should("not be editable by candidates") { assert !@event.editable_by?(Factory.create(:candidate))}
      should("not be editable by employers") { assert !@event.editable_by?(Factory.create(:employer))}
    end
    
    context "by an employer" do
      setup { @event = Factory.create(:employer_event) }
      [nil, Factory.create(:candidate), Factory.create(:employer), Factory.create(:admin)].each do |user|
        should("be viewable by #{user.nil? ? "guests" : user.class.name.pluralize}") { assert @event.viewable_by?(user) }
      end
      
      should("not be editable by any admin") { assert !@event.editable_by?(Factory.create(:admin))}
      should("not be editable by guests") { assert !@event.editable_by?(nil)}
      should("not be editable by candidates") { assert !@event.editable_by?(Factory.create(:candidate))}
      should("not be editable by employers") { assert !@event.editable_by?(Factory.create(:employer))}
      should("be editable by creator") { assert @event.editable_by?(@event.creator)}
    end
  end
  
  context "A non-published event" do
    context "by an admin" do
      setup { @event = Factory.create :draft_admin_event }
      should("be viewable by any admin") { assert @event.viewable_by?(Factory.create(:admin))}
      should("not be viewable by guests") { assert !@event.viewable_by?(nil)}
      should("not be viewable by candidates") { assert !@event.viewable_by?(Factory.create(:candidate))}
      should("not be viewable by employers") { assert !@event.viewable_by?(Factory.create(:employer))}
      
      should("be editable by any admin") { assert @event.editable_by?(Factory.create(:admin))}
      should("not be editable by guests") { assert !@event.editable_by?(nil)}
      should("not be editable by candidates") { assert !@event.editable_by?(Factory.create(:candidate))}
      should("not be editable by employers") { assert !@event.editable_by?(Factory.create(:employer))}
    end
    
    context "by an employer" do
      setup { @event = Factory.create :draft_employer_event }
      should("be viewable by any admin") { assert @event.viewable_by?(Factory.create(:admin))}
      should("not be viewable by guests") { assert !@event.viewable_by?(nil)}
      should("not be viewable by candidates") { assert !@event.viewable_by?(Factory.create(:candidate))}
      should("not be viewable by employers") { assert !@event.viewable_by?(Factory.create(:employer))}
      should("be viewable by creator") { assert @event.viewable_by?(@event.creator)}
      
      should("not be editable by any admin") { assert !@event.editable_by?(Factory.create(:admin))}
      should("not be editable by guests") { assert !@event.editable_by?(nil)}
      should("not be editable by candidates") { assert !@event.editable_by?(Factory.create(:candidate))}
      should("not be editable by employers") { assert !@event.editable_by?(Factory.create(:employer))}
      should("be editable by creator") { assert @event.editable_by?(@event.creator)}
    end
  end
  
  context "with a couple of events" do
    setup do
      @may_2009_events = (1..5).collect {|i| Factory.create(:employer_event, :start_time => Time.parse("2009-05-05"), :end_time => Time.parse("2009-05-10"))}
      @jan_2011_events = (1..3).collect {|i| Factory.create(:employer_event, :start_time => Time.parse("2011-01-05"), :end_time => Time.parse("2011-01-10"))}
    end
    
    context "the named_scope year_month" do
      should("work properly using string and integers") do
        assert_equal @may_2009_events.length, Event.month_year(5, 2009).count
        assert_equal @may_2009_events.length, Event.month_year("5", "2009").count
        assert_equal @jan_2011_events.length, Event.month_year(1, 2011).count
        assert_equal @jan_2011_events.length, Event.month_year("1", "2011").count
      end
    end
  end
end
