require File.dirname(__FILE__) + '/../test_helper'

class CandidateTest < ActiveSupport::TestCase
  should_validate_presence_of :first_name, :last_name
  should_not_allow_mass_assignment_of :crypted_password, :password_salt,
                                      :persistence_token, :single_access_token,
                                      :perishable_token, :email, :password,
                                      :status_id, :skip_registration_steps
  should_have_many :degrees
  {
    :gender_id => Candidate::Gender,
    :marital_status_id => Candidate::MaritalStatus,
    #:iqama_id => Candidate::IqamaTypes,
    :language_id => Candidate::Languages
  }.each do |member, hash|
    values = hash.values.sort
    should_ensure_value_in_range member, values.first..values.last,
                                 :low_message => I18n.translate('activerecord.errors.models.candidate.inclusion'),
                                 :high_message => I18n.translate('activerecord.errors.models.candidate.inclusion')
  end
  
  [:email, :password].each do |attr|
    should "validate presence of #{attr}" do
      u = Factory.build(:candidate, attr => nil)
      assert u.new_record?
      assert !u.valid?
      assert u.errors.on(attr)
    end  
  end
  
  context "creating a candidate (skipping registration steps)" do
    setup { @candidate = Factory.create :candidate }
    should("succeed") { assert @candidate.id }
    should("mark the candidate as accepted or rejected") do
      assert @candidate.status_system_accepted? || @candidate.status_system_rejected?
    end
  end
  
  context "creating a candidate without a degree" do
    setup { begin;Factory.create(:candidate_without_degree);rescue => e; @e = e; end }
    should("fail") { assert @e; assert @e.message.include?(I18n.translate('activerecord.errors.full_messages')[:degree_presence]) }
  end
  
  context "creating a candidate without a nationality" do
    setup { @candidate = Factory.build :candidate, :country_ids => [] }
    should("fail") do
      assert !@candidate.save
      assert @candidate.errors.on(:nationality)
    end
  end
  
  context "creating a candidate without skipping registration steps" do
    setup {@candidate = Factory.create :step_1_candidate}
    should("mark the candidate as finishing step 1") do
      assert @candidate.status_completed_registration_step_1?
      assert_equal 1, @candidate.completed_registration_steps
    end
    context "Proceeding to step 2" do
      context "without providing step attributes" do
        should("fail") do
          assert !@candidate.save
          assert_equal 1, @candidate.completed_registration_steps
          assert_equal(0, Array(@candidate.errors.on(:job_mixing_id)).length) if @candidate.gender_female?
        end
        should("require job_mixing_id if female") do
          assert !@candidate.update_attributes({:gender_id => Candidate::Gender[:female]})
          assert Array(@candidate.errors.on(:job_mixing_id)).length > 0
        end
      end
      context "while providing the step attributes" do
        setup do
          @candidate.update_attributes({
            :job_start_date => 1.month.from_now.to_date.to_s(:db),
            :job_type_ids => [(Jobs::Type.find_by_identifier(Jobs::Type::Identifiers[:full_time]) || Factory.create(:full_time_job_type)).id],
            :job_city_ids => [((City.job.first || Factory.create(:job_city))).id]
          })
        end
        should("mark the candidate as finishing step 2") do
          assert_equal 0, @candidate.changes.length #assert that it was saved ! 
          assert @candidate.status_completed_registration_step_2?
          assert_equal 2, @candidate.completed_registration_steps
        end
        context "Proceeding to step 3" do
          context "without providing step attributes" do
            should("fail") do
              assert !@candidate.save
              assert_equal 2, @candidate.completed_registration_steps
            end
          end
          context "while providing the step attributes" do
            setup do
              assert @candidate.update_attributes({
                :confirmation => true,
                :entry_level => true,
                :residence_country => Factory.create(:country),
                :residence_phone => "2012345567",
              })
            end
            should("mark the candidate as accepted or rejected") do
              assert_equal 0, @candidate.changes.length #assert that it was saved !
              assert @candidate.status_system_accepted? || @candidate.status_system_rejected? 
              assert_equal 3, @candidate.completed_registration_steps
            end
          end
        end
      end
    end
  end
  
  context "for a candidate" do
    setup do
      @candidate = Factory.create :candidate
      @status_id = @candidate.status_id
    end
    context "an admin" do
      setup { @admin = Factory.create :admin }
      Candidate::StatusC.filter_and_ascend_by_name.each do |s|
        context "trying to view him when he's #{s.name.downcase}" do
          setup { @candidate.status_id = s.id; @candidate.save! }
          should("work") { assert @candidate.viewable_by?(@admin) }
        end
      end
    end
    
    context "an employer" do
      setup { @employer = Factory.create :employer }
      employer_viewable_statuses = [Candidate::StatusC[:system_accepted], Candidate::StatusC[:system_rejected], Candidate::StatusC[:rejected]]
      (Candidate::StatusC.filter_and_ascend_by_name - employer_viewable_statuses).each do |s|
        context "trying to view him when he's #{s.name.downcase}" do
          setup { @candidate.status_id = s.id; @candidate.save! }
          should("not work") { assert !@candidate.viewable_by?(@employer) }
        end
      end
      employer_viewable_statuses.each do |s|
        context "trying to view him when he's #{s.name.downcase}" do
          setup { @candidate.status_id = s.id; @candidate.save! }
          should("work") { assert @candidate.viewable_by?(@employer) }
        end
      end
    end
    
    context "another candidate" do
      setup { @candidate2 = Factory.create :candidate }
      Candidate::StatusC.filter_and_ascend_by_name.each do |s|
        context "trying to view him when he's #{s.name.downcase}" do
          setup { @candidate.status_id = s.id; @candidate.save! }
          should("not work") { assert !@candidate.viewable_by?(@candidate2) }
        end
      end
    end
    
    context "a guest" do
      Candidate::StatusC.filter_and_ascend_by_name.each do |s|
        context "trying to view him when he's #{s.name.downcase}" do
          setup { @candidate.status_id = s.id; @candidate.save! }
          should("not work") { assert !@candidate.viewable_by?(nil) }
        end
      end
    end
    
    ["block", "block!"].each do |m|
      context "calling #{m}" do
        should("change the candidate's status to blocked") do
          assert @candidate.send(m)
          assert @candidate.status_blocked?
          assert_sent_email
        end
        ["unblock", "unblock!"].each do |m2|
          context "then calling #{m2}" do
            should("return the candidate's status to its original value") do
              assert @candidate.send(m2)
              assert_equal @status_id, @candidate.status_id
              assert_sent_email
            end
          end
        end
        context "then calling request_unblock!" do
          should("change the candidate's status to unblock_requested") do
            assert @candidate.request_unblock!
            assert_equal Candidate::StatusC[:unblock_requested].id, @candidate.status_id
          end
        end
      end  
    end
    ["reject", "reject!"].each do |m|
      context "calling #{m}" do
        should("change the candidate's status to blocked") do
          assert @candidate.send(m)
          assert @candidate.status_rejected?
        end
        ["unreject", "unreject!"].each do |m2|
          context "then calling #{m2}" do
            should("return the candidate's status to its original value") do
              assert @candidate.send(m2)
              assert_equal @status_id, @candidate.status_id
            end
          end
        end
      end  
    end
  end
  context "for a bunch of candidates" do
    setup do 
      @candidates = (1..5).collect {Factory.create(:candidate)}.sort {|a,b| a.id <=> b.id}
      @status_id = @candidates[0].status_id
      @ids = @candidates.collect &:id
    end
    ["mass_block!"].each do |m|
      context "calling #{m}" do
        should("change the candidate's status to blocked") do
          assert Candidate.send(m, @ids)
          Candidate.find(@ids).each {|c| assert c.status_blocked? }
        end
        ["mass_unblock!"].each do |m2|
          context "then calling #{m2}" do
            should("return the candidate's status to its original value") do
              assert Candidate.send(m2, @ids)
              Candidate.find(@ids).each {|c| assert_equal @status_id, c.status_id }
            end
          end
        end
      end  
    end
    ["mass_reject!"].each do |m|
      context "calling #{m}" do
        should("change the candidate's status to blocked") do
          assert Candidate.send(m, @ids)
          Candidate.find(@ids).each {|c| assert c.status_rejected? }
        end
        ["mass_unreject!"].each do |m2|
          context "then calling #{m2}" do
            should("return the candidate's status to its original value") do
              assert Candidate.send(m2, @ids)
              Candidate.find(@ids).each {|c| assert_equal @status_id, c.status_id }
            end
          end
        end
      end  
    end
  end
  
  context "a candidate with comments and applications" do
    setup do
      @candidate = Factory.create :candidate
      @article = Factory.create :admin_article
      @comment = Factory.create :comment, :commenter => @candidate, :commentable => @article
      
      @employer = Factory.create(:employer)
      @job = Factory.create :job, :employer => @employer
      @vacancy = Vacancy.new :city => City.saudi.rand
      @job.vacancies << @vacancy
      @vacancy.add_application!(@candidate)
      @application = Vacancies::Application.find_by_candidate_id_and_vacancy_id!(@candidate.id, @vacancy.id)
     
      [@comment, @application, @candidate].map &:reload
      
      raise unless @comment.status_visible?
      raise unless @application.status_visible?
    end
    context "when blocking him" do
      setup { @candidate.block! }
      should("mark comments and applications as hidden") do
        assert @comment.reload.status_hidden?
        assert @application.reload.status_hidden?
      end
      
      context "then unblocking him" do
        setup { @candidate.unblock! }
        should("mark comments and applications as visible") do
          assert @comment.reload.status_visible?
          assert @application.reload.status_visible?
        end  
      end
    end
  end
end
