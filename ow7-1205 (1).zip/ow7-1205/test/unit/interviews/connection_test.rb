require File.dirname(__FILE__) + '/../../test_helper'

class Interviews::ConnectionTest < ActiveSupport::TestCase
  should_not_allow_mass_assignment_of :interview_id, :status_id, :slot_id, :time
  should_validate_presence_of :candidate_id, :interview_id
  #should_validate_uniqueness_of :candidate_id, :case_sensitive => false, :message => I18n.t('activerecord.errors.models.interviews/connection.already_invited'),
  #                              :scoped_to => :interview_id
  
  context "An interview" do
    setup {@interview = Factory.create :interview}
    context "with a candidate" do
      setup {@candidate = Factory.create :candidate}
      context "who doesn't have a vacancy application, trying to apply for the interview" do
        setup do
          @connection = @interview.connections.build :candidate_id => @candidate.id
          @connection.save
        end
        should("fail") {assert @connection.errors.on(:candidate_id) =~ /#{I18n.t('activerecord.errors.models.interviews/connection.no_application')}/}  
      end
      context "who is for-paying-only, the employer being unpaid, trying to apply for the interview" do
        setup do
          Candidate.class_mock(:for_paying_only? => true)
          @application = Vacancies::Application.create! :candidate_id => @candidate.id, :vacancy_id => @interview.vacancy_id
          @connection = @interview.connections.build :candidate_id => @candidate.id
          raise if @connection.save
        end
        should("fail") do
          assert @connection.errors.length > 0
          assert_equal I18n.t('activerecord.errors.models.interviews/connection.for_paying_only'), @connection.errors.full_messages.first
          Candidate.class_unmock(:for_paying_only?)
        end
      end
      context "who has a vacancy application, trying to apply for the interview" do
        setup do
          @application = Vacancies::Application.create! :candidate_id => @candidate.id, :vacancy_id => @interview.vacancy_id
          @connection = @interview.connections.build :candidate_id => @candidate.id
          @connection.save
        end
        should("succeed") { assert @connection.errors.length == 0 }
        should_send_email
        
        context "then trying to assign a slot to the connection" do
          setup do 
            @slot = Factory.create :interview_slot, :interview => @interview
            @connection.assign_slot!(@slot)
          end
          should("succeed") do
            assert_equal @slot.time, @connection.time
            assert @slot.status_booked?
          end
          should_send_email
          context "then removing that slot from connection" do
            setup {@connection.remove_slot!}
            should("succeed") do
              assert @slot.reload.status_open?
              assert @connection.slot_id.blank?
              assert @connection.time.blank?
            end
            should_send_email
          end
          context "then destroying the slot" do
            setup {@slot.destroy; @connection.reload}
            should("succeed") do
              assert @connection.slot_id.blank?
              assert @connection.time.blank?
            end
            should_send_email
          end
          context "then assigning a different slot to the connection" do
            setup {@new_slot = Factory.create :interview_slot, :interview => @interview}
            should("succeed") do
              assert @connection.assign_slot!(@new_slot)
              assert @slot.reload.status_open?
              assert @new_slot.status_booked?
              assert_equal @new_slot.id, @connection.slot_id
              assert_equal @new_slot.time, @connection.time
              #TODO assert an email sent to cancel interview with candidate and notify abt the new one
            end
          end
        end
      end
    end
  end
end
