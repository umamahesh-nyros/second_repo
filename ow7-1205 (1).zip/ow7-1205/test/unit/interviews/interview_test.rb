require File.dirname(__FILE__) + '/../../test_helper'

class Interviews::InterviewTest < ActiveSupport::TestCase
  [:employer_id, :vacancy_id,
   :city_id, :location, :contact_person
  ].each {|attr| should_validate_presence_of attr}
  should_not_allow_mass_assignment_of :employer_id
  should_validate_numericality_of :duration
  
  context "An interview" do
    setup { @interview = Interviews::Interview.new }
    context "with an invalid email" do
      setup {@interview.contact_email = "koko"; @interview.valid?}
      should("have errors on email") {assert @interview.errors.on(:contact_email).length > 0}
    end
    
    context "with a valid email" do
      setup {@interview.contact_email = "koko@soso.com"; @interview.valid?}
      should("have no errors on email") {assert_equal nil,@interview.errors.on(:contact_email)}
    end
  end
  #TODO validates_date :confirmation_deadline
  #TODO validate Proc.new {|record| Validator.phone_format_of(record, :contact_phone)}
  
end