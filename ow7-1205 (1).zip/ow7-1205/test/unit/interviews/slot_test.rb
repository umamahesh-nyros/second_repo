require File.dirname(__FILE__) + '/../../test_helper'

class Interviews::SlotTest < ActiveSupport::TestCase
  should_validate_presence_of :interview_id
  
  context "A slot" do
    setup {@slot = Interviews::Slot.new}
    context "when setting time parts then validating" do
      setup do
        @time = Time.now
        @slot.time_date = @time.to_date.to_s(:db)
        @slot.time_hour = @time.strftime("%I")
        @slot.time_minute = @time.strftime("%M")
        @slot.time_ampm = @time.strftime("%p")
        @slot.valid?
      end
      should("construct a time object") do
        assert @slot.time
        assert_equal @slot.time.to_date.to_s(:db), @time.to_date.to_s(:db)
        assert_equal @slot.time.strftime("%I"), @time.strftime("%I")
        assert_equal @slot.time.strftime("%M"), @time.strftime("%M")
        assert_equal @slot.time.strftime("%p"), @time.strftime("%p")
      end
    end
  end
end
