require 'test_helper'

class ApplicationsHelperTest < ActionView::TestCase
end
