require 'test_helper'

class EnquiriesHelperTest < ActionView::TestCase
end
