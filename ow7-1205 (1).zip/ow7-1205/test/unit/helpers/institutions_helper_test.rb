require 'test_helper'

class InstitutionsHelperTest < ActionView::TestCase
end
