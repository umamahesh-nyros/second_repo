require 'test_helper'

class Employers::CandidatesHelperTest < ActionView::TestCase
end
