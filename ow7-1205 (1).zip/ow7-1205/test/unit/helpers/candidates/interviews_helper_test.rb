require 'test_helper'

class Candidates::InterviewsHelperTest < ActionView::TestCase
end
