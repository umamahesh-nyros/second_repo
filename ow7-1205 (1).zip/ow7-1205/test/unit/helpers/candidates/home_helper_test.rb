require 'test_helper'

class Candidates::HomeHelperTest < ActionView::TestCase
end
