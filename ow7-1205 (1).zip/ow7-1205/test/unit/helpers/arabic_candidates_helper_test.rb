require 'test_helper'

class ArabicCandidatesHelperTest < ActionView::TestCase
end
