require 'test_helper'

class JavascriptsHelperTest < ActionView::TestCase
end
