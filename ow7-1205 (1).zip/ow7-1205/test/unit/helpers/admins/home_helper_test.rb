require 'test_helper'

class Admins::HomeHelperTest < ActionView::TestCase
end
