require 'test_helper'

class Vacancies::SlotsHelperTest < ActionView::TestCase
end
