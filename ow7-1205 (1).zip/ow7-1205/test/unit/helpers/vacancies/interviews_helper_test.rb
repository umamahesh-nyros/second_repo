require 'test_helper'

class Vacancies::InterviewsHelperTest < ActionView::TestCase
end
