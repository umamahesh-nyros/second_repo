require 'test_helper'

class VacanciesHelperTest < ActionView::TestCase
end
