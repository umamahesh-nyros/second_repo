require File.dirname(__FILE__) + '/../test_helper'

class DegreeTest < ActiveSupport::TestCase
  should_belong_to :candidate
  should_validate_presence_of :candidate_id
  should_validate_presence_of :category_id
  should_ensure_value_in_range :level_id, Degree::Levels.values.min..Degree::Levels.values.max
  should_ensure_value_in_range :method_of_study_id, Degree::MethodOfStudy.values.min..Degree::MethodOfStudy.values.max
  
  context "A degree" do
    setup { @degree = Degree.new }
    subject { @degree }
    context "that's level A" do
      setup { @degree.level_id = Degree::LevelAIds.first; raise("Not level A") unless @degree.level_class == "a"}
      should_validate_presence_of :gpa
      context "and setting a level B category to it" do
        setup { @degree.category = Factory.create(:b_category); @degree.valid? }
        should("have a mismatch error") { assert Array(@degree.errors.on(:category_id)).include?(I18n.translate('activerecord.errors.models.degree')[:category_level_mismatch])}
      end
    end
  end
end
