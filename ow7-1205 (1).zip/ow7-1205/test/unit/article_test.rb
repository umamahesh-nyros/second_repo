require File.dirname(__FILE__) + '/../test_helper'

class ArticleTest < ActiveSupport::TestCase
  should_validate_presence_of :creator_id
  should_allow_values_for :creator_type, Admin.name, Employer.name
  should_validate_presence_of :title, :body
  status_ids = Article::Status.all.collect {|s| s.id}.sort
  should_ensure_value_in_range :status_id, status_ids.first..status_ids.last
  
  context "creating a draft article" do
    setup { @article = Factory.create :draft_admin_article}
    should("not set its published_at") do
      assert_nil @article.published_at
    end
    
    context "then publishing it" do
      setup { @article.status_id = Article::Status[:published].id; @article.save! }
      should("set its publish date") {assert !@article.published_at.blank? }
    end
  end
  
  context "creating an article" do
    setup { @article = Factory.create :admin_article}
    should("set its published_at") { assert !@article.published_at.blank? }
  end
  
  context "A published article" do
    context "by an admin" do
      setup { @article = Factory.create(:admin_article) }
      [nil, Factory.create(:candidate), Factory.create(:employer), Factory.create(:admin)].each do |user|
        should("be viewable by #{user.nil? ? "guests" : user.class.name.pluralize}") { assert @article.viewable_by?(user) }
      end
      
      should("be editable by any admin") { assert @article.editable_by?(Factory.create(:admin))}
      should("not be editable by guests") { assert !@article.editable_by?(nil)}
      should("not be editable by candidates") { assert !@article.editable_by?(Factory.create(:candidate))}
      should("not be editable by employers") { assert !@article.editable_by?(Factory.create(:employer))}
    end
    
    context "by an employer" do
      setup { @article = Factory.create(:employer_article) }
      [nil, Factory.create(:candidate), Factory.create(:employer), Factory.create(:admin)].each do |user|
        should("be viewable by #{user.nil? ? "guests" : user.class.name.pluralize}") { assert @article.viewable_by?(user) }
      end
      
      should("not be editable by any admin") { assert !@article.editable_by?(Factory.create(:admin))}
      should("not be editable by guests") { assert !@article.editable_by?(nil)}
      should("not be editable by candidates") { assert !@article.editable_by?(Factory.create(:candidate))}
      should("not be editable by employers") { assert !@article.editable_by?(Factory.create(:employer))}
      should("be editable by creator") { assert @article.editable_by?(@article.creator)}
    end
  end
  
  context "A non-published article" do
    context "by an admin" do
      setup { @article = Factory.create :draft_admin_article }
      should("be viewable by any admin") { assert @article.viewable_by?(Factory.create(:admin))}
      should("not be viewable by guests") { assert !@article.viewable_by?(nil)}
      should("not be viewable by candidates") { assert !@article.viewable_by?(Factory.create(:candidate))}
      should("not be viewable by employers") { assert !@article.viewable_by?(Factory.create(:employer))}
      
      should("be editable by any admin") { assert @article.editable_by?(Factory.create(:admin))}
      should("not be editable by guests") { assert !@article.editable_by?(nil)}
      should("not be editable by candidates") { assert !@article.editable_by?(Factory.create(:candidate))}
      should("not be editable by employers") { assert !@article.editable_by?(Factory.create(:employer))}
    end
    
    context "by an employer" do
      setup { @article = Factory.create :draft_employer_article }
      should("be viewable by any admin") { assert @article.viewable_by?(Factory.create(:admin))}
      should("not be viewable by guests") { assert !@article.viewable_by?(nil)}
      should("not be viewable by candidates") { assert !@article.viewable_by?(Factory.create(:candidate))}
      should("not be viewable by employers") { assert !@article.viewable_by?(Factory.create(:employer))}
      should("be viewable by creator") { assert @article.viewable_by?(@article.creator)}
      
      should("not be editable by any admin") { assert !@article.editable_by?(Factory.create(:admin))}
      should("not be editable by guests") { assert !@article.editable_by?(nil)}
      should("not be editable by candidates") { assert !@article.editable_by?(Factory.create(:candidate))}
      should("not be editable by employers") { assert !@article.editable_by?(Factory.create(:employer))}
      should("be editable by creator") { assert @article.editable_by?(@article.creator)}
    end
  end
end
