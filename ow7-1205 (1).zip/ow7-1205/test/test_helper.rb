ENV["RAILS_ENV"] = "test"
require File.expand_path(File.dirname(__FILE__) + "/../config/environment")
require File.expand_path(File.dirname(__FILE__) + "/solr_override")
require File.expand_path(File.dirname(__FILE__) + "/object_mock")
require 'test_help'
require "authlogic/test_case"
require 'paperclip/../../shoulda_macros/paperclip'
require 'shoulda/rails'

class ActiveSupport::TestCase
  # Transactional fixtures accelerate your tests by wrapping each test method
  # in a transaction that's rolled back on completion.  This ensures that the
  # test database remains unchanged so your fixtures don't have to be reloaded
  # between every test method.  Fewer database queries means faster tests.
  #
  # Read Mike Clark's excellent walkthrough at
  #   http://clarkware.com/cgi/blosxom/2005/10/24#Rails10FastTesting
  #
  # Every Active Record database supports transactions except MyISAM tables
  # in MySQL.  Turn off transactional fixtures in this case; however, if you
  # don't care one way or the other, switching from MyISAM to InnoDB tables
  # is recommended.
  #
  # The only drawback to using transactional fixtures is when you actually 
  # need to test transactions.  Since your test is bracketed by a transaction,
  # any transactions started in your code will be automatically rolled back.
  #self.use_transactional_fixtures = true
  
  # Instantiated fixtures are slow, but give you @david where otherwise you
  # would need people(:david).  If you don't want to migrate your existing
  # test cases which use the @david style and don't mind the speed hit (each
  # instantiated fixtures translates to a database query per test method),
  # then set this back to true.
  #self.use_instantiated_fixtures  = false
  
  # Setup all fixtures in test/fixtures/*.(yml|csv) for all tests in alphabetical order.
  #
  # Note: You'll currently still have to declare fixtures explicitly in integration tests
  # -- they do not yet inherit this setting
  #fixtures :all
  
  # Add more helper methods to be used by all tests here...
  def self.should_require_no_candidate
    should_require_no_user(:html)
  end
  
  def self.should_require_candidate
    should_set_flash_of_to(:error, I18n.t('flash.require_user'))
    should_redirect_to("candidates_login_path") { candidates_login_path }
  end
  
  def self.should_assign_to_flash_of(of)
    should("assign to flash[:#{of}]") { assert_not_nil flash[of] }
  end
  
  def self.should_set_flash_of_to(of, to)
    should("set flash[:#{of}] to") { assert_equal to, flash[of] }
  end
  
  def self.should_send_email
    should("send an email") { assert_sent_email }
  end
  
  def clear_candidate_session
    CandidateSession.find.destroy if CandidateSession.find
  end
  
  def self.should_require_no_employer
    should_require_no_user(:html)
  end
  
  def self.should_require_employer
    should_set_flash_of_to(:error, I18n.t('flash.require_user'))
    should_redirect_to("employers_login_path") { employers_login_path }
  end
  def clear_employer_session
    EmployerSession.find.destroy if EmployerSession.find
  end
  
  def self.should_require_no_admin
    should_require_no_user(:html)
  end
  
  def self.should_require_admin
    should_set_flash_of_to(:error, I18n.t('flash.require_user'))
    should_redirect_to("admins_login_path") { admins_login_path }
  end

  def self.should_require_user(format = :html)
    error = I18n.t('flash.users.user_not_authorized')
    case format
      when :html
        should_set_flash_of_to(:error, error)
        should_redirect_to("root path") { root_path }
      when :js
        should("respond with error") { assert_match /#{error}/, @response.cookies['flash_error']}
    end
  end

  def self.should_require_no_user(format = :html)
    error = I18n.t('flash.require_no_user')
    case format
      when :html
        should_set_flash_of_to(:error, error)
        should_redirect_to("root path") { root_path }
      when :js
        should("respond with error") { assert_match /#{error}/, @response.cookies['flash_error']}
    end
  end
  
  def clear_admin_session
    AdminSession.find.destroy if AdminSession.find
  end    
end

class ActionController::TestCase
  setup :activate_authlogic
  
  # options should be on the format {:method => [action1, action2]}
  # ex: {:get => [:index, :show], :post => [:create]}
  def self.should_require_no_candidate_for(options, record=nil)
    should_require_no_session_for(:candidate, CandidateSession, options, record)
  end
  
  # options should be on the format {:method => [action1, action2]}
  # ex: {:get => [:index, :show], :post => [:create]}
  def self.should_require_candidate_for(options)
    should_require_session_for(:candidate, options)
  end
  
  # options should be on the format {:method => [action1, action2]}
  # ex: {:get => [:index, :show], :post => [:create]}
  def self.should_require_no_employer_for(options, record=nil)
    should_require_no_session_for(:employer, EmployerSession, options, record)
  end
  
  # options should be on the format {:method => [action1, action2]}
  # ex: {:get => [:index, :show], :post => [:create]}
  def self.should_require_employer_for(options)
    should_require_session_for(:employer, options)
  end
  
  # options should be on the format {:method => [action1, action2]}
  # ex: {:get => [:index, :show], :post => [:create]}
  def self.should_require_no_admin_for(options, record=nil)
    should_require_no_session_for(:admin, AdminSession, options, record)
  end
  
  # options should be on the format {:method => [action1, action2]}
  # ex: {:get => [:index, :show], :post => [:create]}
  def self.should_require_admin_for(options)
    should_require_session_for(:admin, options)
  end
  
  def self.should_require_user_for(options)
    should_require_session_for(:user, options)
  end
  
  def self.should_raise_not_found(&block)
    
  end
  
  # options should be on the format {:method => [action1, action2]}
  # ex: {:get => [:index, :show], :post => [:create]}
  def self.should_require_admin_or_employer_for(options)
    context "A guest" do
      options.each_pair do |method, actions|
        actions.each do |action|
          context "trying to #{method} to #{action}" do
            setup do
              @success = false
              begin
                send method, action, :id => "blah"
              rescue ActiveRecord::RecordNotFound
                @success = true
              end
            end
            should("raise ActiveRecord::RecordNotFound") { assert @success }
          end
        end
      end
    end
  end

  def self.should_require_super_admin_for(options)
    context "An admin" do
      setup { Factory.create :admin }
      options.each_pair do |method, actions|
        actions.each do |action|
          context "trying to #{method} to #{action}" do
            setup { send method, action, :id => "blah" }
            should_set_flash_of_to(:error, I18n.t('flash.users.user_not_authorized'))
            should_redirect_to("root_path") { root_path }
          end
        end
      end
    end
  end


  # options should be on the format {:method => [action1, action2]}
  # ex: {:get => [:index, :show], :post => [:create]}
  def self.should_require_admin_for!(options)
    context "A guest" do
      options.each_pair do |method, actions|
        actions.each do |action|
          context "trying to #{method} to #{action}" do
            setup do
              @success = false
              begin
                send method, action, :id => "blah"
              rescue ActiveRecord::RecordNotFound
                @success = true
              end
            end
            should("raise ActiveRecord::RecordNotFound") { assert @success }
          end
        end
      end
    end
  end
  def self.should_require_no_user_for(options)
    {:candidate => CandidateSession, :employer => EmployerSession, :admin => AdminSession}.each do |user, session|
      should_require_no_session_for(user, session, options)
    end
  end
  
  def self.should_require_session_for(user, options)
    context "A guest" do
      options.each_pair do |method, actions|
        actions.each do |action|
          context "trying to #{method} to #{action}" do
            setup { send method, action, :id => "blah" }
            send("should_require_#{user}")
          end
        end
      end
      
      if user == :user
        options.each_pair do |method, actions|
          actions.each do |action|
            context "trying to #{method} to #{action} with ajax" do
              setup { xhr method, action, :id => "blah" }
              should_require_user(:js)
            end
          end
        end
      end
    end
  end

  # options should be on the format {:method => [action1, action2]}
  # ex: {:get => [:index, :show], :post => [:create]}
  def self.should_require_no_session_for(user, session, options, record = nil)
    context "A logged in #{user}" do
      setup { @user = record || Factory.create(user); session.create(@user) }
      options.each_pair do |method, actions|
        actions.each do |action|
          context "trying to #{method} to #{action}" do
            setup { send method, action, :id => "blah" }
            should_require_no_user(:html)
          end
          context "trying to #{method} to #{action} with ajax" do
            setup { xhr method, action, :id => "blah" }
            should_require_no_user(:js)
          end
        end
      end
    end
  end

end


# Here we create sample saudi cities
# TODO: find some way to load the seeds into the test environment instead
5.times { Factory.create(:saudi_city)}

# create the default job type
Factory.create :full_time_job_type
Factory.create :graduate_program_job_type
