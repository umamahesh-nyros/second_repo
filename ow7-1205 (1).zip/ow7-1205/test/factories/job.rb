#require File.join(Rails.root, 'test', 'solr_override.rb')
require File.join(Rails.root, 'test', 'factories', 'vacancy.rb')

Factory.define :job do |j|
  j.sequence(:title) {|a| "title_#{a}"}
  j.association :type, :factory => :job_type
  j.association :employer, :factory => :employer
  j.vacancies_attributes {[Factory.attributes_for(:vacancy_without_job)]}
end

Factory.define :job_without_vacancies, :parent => :job do |j|
  j.vacancies_attributes []
  j.should_have_vacancies false
end
