Factory.define :article do |a|
  a.sequence(:title) {|i| "Title #{i}"}
  a.sequence(:body) {|i| "Body #{i}"}
  a.status_id Article::Status[:published].id
end

Factory.define :admin_article, :parent => :article do |a|
  a.association :creator, :factory => :admin
end

Factory.define :employer_article, :parent => :article do |a|
  a.association :creator, :factory => :employer
end

Factory.define :draft_admin_article, :parent => :article do |a|
  a.status_id Article::Status[:draft].id
  a.association :creator, :factory => :admin
end

Factory.define :draft_employer_article, :parent => :article do |a|
  a.status_id Article::Status[:draft].id
  a.association :creator, :factory => :employer
end