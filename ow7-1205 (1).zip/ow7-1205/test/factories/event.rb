Factory.define :event do |e|
  e.sequence(:title) {|i| "Title #{i}"}
  e.sequence(:description) {|i| "Description #{i}"}
  e.location "somewhere"
  e.status_id {Event::Status[:published].id}
  e.start_time { Time.now }
  e.end_time { Time.now + 2.days }
  e.type_id Event::Types[:career_event].id
  e.employer_gender {Event::Gender[:male].id | Event::Gender[:female].id}
  e.candidate_gender {Event::Gender[:male].id | Event::Gender[:female].id}
end

Factory.define :admin_event, :parent => :event do |e|
  e.association :creator, :factory => :admin
end

Factory.define :employer_event, :parent => :event do |e|
  e.association :creator, :factory => :employer
end

Factory.define :draft_admin_event, :parent => :event do |e|
  e.status_id {Event::Status[:draft].id}
  e.association :creator, :factory => :admin
end

Factory.define :draft_employer_event, :parent => :event do |e|
  e.status_id {Event::Status[:draft].id}
  e.association :creator, :factory => :employer
end