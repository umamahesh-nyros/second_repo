#require File.join(Rails.root, 'test', 'solr_override.rb')

Factory.define :city do |c|
  c.sequence(:name) {|a| "City_#{a}" }
  c.country {|c| c.association :country }
end

Factory.define :saudi_city, :parent => :city do |c|
  c.country {Country.saudi_arabia || Factory.create(:saudi_arabia)}
end

Factory.define :job_city, :parent => :saudi_city do |c|
  c.job true
end
