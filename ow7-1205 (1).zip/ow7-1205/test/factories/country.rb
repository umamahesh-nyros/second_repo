#require File.join(Rails.root, 'test', 'solr_override.rb')

Factory.define :country do |c|
  c.sequence(:iso) {|a| "i#{a}" }
  c.sequence(:iso3) {|a| "is#{a}" }
  c.sequence(:name) {|a| "COUNTRY#{a}" }
  c.sequence(:printable_name) {|a| "Country#{a}" }
end

Factory.define :saudi_arabia, :parent => :country do |c|
  c.iso "SA"
  c.iso3 "SAU"
  c.name "SAUDI ARABIA"
  c.printable_name "Saudi Arabia"
  c.dialing_code_1 966
  c.after_create {|country| raise "Multiple Saudi Arabias" if Country.count(:conditions => "iso = 'SA'") > 1}
end
