#require File.join(Rails.root, 'test', 'solr_override.rb')

require File.join(Rails.root, 'test', 'factories', 'institution.rb')
require File.join(Rails.root, 'test', 'factories', 'category.rb')

Factory.define :degree do |d|
  d.level_id Degree::Levels[:below_high_school]
  d.date Date.today
  d.method_of_study_id Degree::MethodOfStudy.values.rand
  d.institution_id {Factory.create(:institution).id}
  d.sub_category_id {Factory.create(:b_sub_category).id}
end