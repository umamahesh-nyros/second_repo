#require File.join(Rails.root, 'test', 'solr_override.rb')

Factory.define :invitation do |i|
  i.type_id Invitation.types[:employer]
  i.sequence(:email) {|a| "email_#{a}#{Time.now.to_s(:db).gsub(/\D/,'')}@example.com".downcase }
  i.sequence(:first_name) {|a| "First#{a}"}
  i.sequence(:last_name) {|a| "Last#{a}"}
end

Factory.define :ngo_invitation, :parent => :invitation do |e|
  e.type_id {Invitation.types[:ngo]}
end
