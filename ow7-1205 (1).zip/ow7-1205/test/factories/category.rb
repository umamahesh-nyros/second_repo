#require File.join(Rails.root, 'test', 'solr_override.rb')

Factory.define :category do |c|
  c.sequence(:name) {|a| "Category #{a}" }
end

Factory.define :b_category, :parent => :category do |c|
  c.level_id Category::Levels[:b]
end

Factory.define :sub_category, :parent => :category do |c|
  c.association :parent, :factory => :category
end

Factory.define :b_sub_category, :parent => :b_category do |c|
  c.association :parent, :factory => :b_category
end