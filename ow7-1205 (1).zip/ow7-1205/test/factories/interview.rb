Factory.define :interview, :class => Interviews::Interview do |i|
  i.association :vacancy, :factory => :vacancy
  i.association :city, :factory => :city
  i.location "location"
  i.duration 10
  i.confirmation_deadline {Date.today + 1.days}
  i.contact_person "Contact Person"
  i.contact_phone "834028492048"
  i.contact_email "koko@soso.com"
end

Factory.define :interview_with_fake_slots, :parent => :interview do |i|
  i.fake_slots {true}
  i.slot_count {3}
  i.start_time {(Time.now+2.days).to_s(:db)}
end