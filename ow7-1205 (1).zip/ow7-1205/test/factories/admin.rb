Factory.define :admin do |u|
  u.sequence(:email) {|a| "email_#{a}#{Time.now.to_s(:db).gsub(/\D/,'')}@example.com".downcase }
  u.password "kokowawa"
  u.password_confirmation "kokowawa"
end

Factory.define :super_admin, :parent => :admin do |u|
  u.super_admin true
end

