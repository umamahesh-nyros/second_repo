require File.join(Rails.root, 'test', 'factories', 'interview.rb')
# this wont work out of the box, u have to pass in interview & candidate
Factory.define :interview_slot, :class => Interviews::Slot do |i|
  i.association :interview, :factory => :interview
  i.time {Time.now + 2.days + (10..100).to_a.rand.minutes}
end
