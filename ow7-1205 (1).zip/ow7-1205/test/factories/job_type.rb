#require File.join(Rails.root, 'test', 'solr_override.rb')

Factory.define :job_type, :class => Jobs::Type do |c|
  c.sequence(:name) {|a| "JobType_#{a}" }
  c.identifier Jobs::Type::Identifiers.values.rand
end

Jobs::Type::Identifiers.each do |k, v|
  Factory.define "#{k.to_s}_job_type", :parent => :job_type do |j|
    j.identifier  v
  end 
end

