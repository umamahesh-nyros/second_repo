Factory.define :enquiry do |i|
  i.type_id Enquiry::Type[:other]
  i.sequence(:email) {|a| "email_#{a}#{Time.now.to_s(:db).gsub(/\D/,'')}@example.com".downcase }
  i.sequence(:name) {|a| "Name#{a}"}
  i.sequence(:subject) {|a| "Subject#{a}"}
  i.sequence(:message) {|a| "Message#{a}"}
end

