#require File.join(Rails.root, 'test', 'solr_override.rb')

Factory.define :institution do |i|
  i.sequence(:name) {|a| "Institution #{a}"}
  i.type_id Institution::Types[:other]
  #i.country {|u| u.association(:country)}
  i.country {Country.saudi_arabia}
  i.adder_type_id {Institution::AdderTypes[:system].id}
end

Factory.define :non_saudi_institution, :parent => :institution do |i|
  i.country {|u| u.association(:country)}
end


Factory.define :university, :parent => :institution do |i|
  i.type_id Institution::Types[:university]
  i.sequence(:name) {|a| "University #{a}"}
end

Factory.define :non_saudi_university, :parent => :university do |i|
  i.country {|u| u.association(:country)}
end

Factory.define :english_university, :parent => :university do |i|
  i.sequence(:name) {|a| "English University #{a}"}
  i.language {Language.find_by_name("English") || Language.create!(:name => "English")}
end

