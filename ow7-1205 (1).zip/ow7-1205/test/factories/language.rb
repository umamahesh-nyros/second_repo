Factory.define :language do |l|
  l.sequence(:name) {|a| "Language #{a}" }
end

Factory.define :arabic_language, :parent => :language do |l|
  l.name "Arabic"
end

Factory.define :english_language, :parent => :language do |l|
  l.name "English"
end