require File.join(Rails.root, 'test', 'solr_override.rb') if Rails.env == "test"

Factory.define :comment do |c|
  c.sequence(:comment) {|i| "comment_body_#{i}" }
  c.commenter {|c| c.association(:employer) }
  c.sequence(:created_at) {|i| Time.now + i.minutes}
end
