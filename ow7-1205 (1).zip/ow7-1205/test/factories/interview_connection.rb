require File.join(Rails.root, 'test', 'factories', 'interview.rb')
# this wont work out of the box, u have to pass in interview & candidate
Factory.define :interview_connection, :class => Interviews::Connection do |i|
  i.association :interview, :factory => :interview
  i.association :candidate, :factory => :candidate
end
