#require File.join(Rails.root, 'test', 'solr_override.rb')

Factory.define :employer do |e|
  e.sequence(:email) {|a| "email_#{a}#{Time.now.to_s(:db).gsub(/\D/,'')}@example.com".downcase }
  e.password "kokowawa"
  e.password_confirmation "kokowawa"
  e.invitation {|i| i.association(:invitation)}
  e.sequence(:name) {|a| "name_#{a}" }
  e.sequence(:person_name) {|a| "person_name_#{a}" }
  e.website "http://www.example.com"
  e.phone "20121234567"
  e.city_id {|x| x.association(:saudi_city)}
end

Factory.define :ngo, :parent => :employer do |e|
  e.invitation {Factory.create(:ngo_invitation)}
end