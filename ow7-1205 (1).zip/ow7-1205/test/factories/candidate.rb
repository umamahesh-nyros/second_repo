#TODO may be this needs a great rewrite?!
#doesn't feel clean !

require File.join(Rails.root, 'test', 'factories', 'city.rb')
require File.join(Rails.root, 'test', 'factories', 'job_type.rb')
require File.join(Rails.root, 'test', 'factories', 'degree.rb')
require File.join(Rails.root, 'test', 'factories', 'country.rb')


Factory.define :step_1_candidate, :class => Candidate do |u|
  u.sequence(:email) {|a| "email_#{a}#{Time.now.to_s(:db).gsub(/\D/,'')}@example.com".downcase }
  u.password "kokowawa"
  u.sequence(:first_name) {|n| "John_#{n}"}
  u.sequence(:last_name) {|n| "Doe_#{n}"}
  u.date_of_birth {(Date.today-25.years).to_s(:db)}
  u.gender_id Candidate::Gender[:male]
  u.degrees_attributes {[Factory.attributes_for(:degree)]}
  u.country_ids {[Factory.create(:country).id]}
  u.marital_status_id Candidate::MaritalStatus.values.rand
  u.iqama_id Candidate::IqamaTypes.values.rand
  u.last_updated {Time.now}
end

Factory.define :candidate, :parent => :step_1_candidate do |u|
  u.skip_registration_steps true
  u.entry_level true
  u.job_mixing_id Candidate::MixingLevels.values.rand
  u.job_start_date 1.month.from_now.to_date.to_s(:db)
  u.job_type_ids {[(Jobs::Type.find_by_identifier(Jobs::Type::Identifiers[:full_time]) || Factory.create(:full_time_job_type)).id]}
  u.job_city_ids {[((City.job.first || Factory.create(:job_city))).id]}
  u.association :residence_country, :factory => :country
  u.residence_phone "9661234567"
end

Factory.define :step_2_candidate, :parent => :step_1_candidate do |u|
  u.status_id {Candidate::Status[:completed_registration_step_1]}
  u.job_type_ids {[(Jobs::Type.find_by_identifier(Jobs::Type::Identifiers[:full_time]) || Factory.create(:full_time_job_type)).id]}
  u.job_city_ids {[((City.job.first || Factory.create(:job_city))).id]}
end

Factory.define :candidate_without_degree, :parent => :candidate do |u|
  u.degrees_attributes []
end

Factory.define :accepted_candidate, :parent => :candidate do |u|
  u.after_create {|x| raise("Candidate is not accepted") unless x.status_system_accepted? }
end

Factory.define :rejected_candidate, :parent => :candidate do |u|
  u.after_create {|x| raise("Candidate is not rejected") unless x.status_system_rejected? }
end

Factory.define :ivy_candidate, :parent => :candidate do |u|
  u.degrees_attributes do 
    [ Factory.attributes_for(:degree, 
        :institution => Factory.create(:english_university, :ivy_league => true),
        :level_id => Degree::Levels[:phd],
        :gpa => 4,
        :category => Factory.create(:category, :level_id => Category::Levels[:a])) ]
  end
end

Factory.define :for_paying_only_candidate, :parent => :ivy_candidate do |u|
  u.degrees_attributes do 
    [ Factory.attributes_for(:degree, 
        :institution => Factory.create(:non_saudi_university),
        :level_id => Degree::Levels[:phd],
        :gpa => 4,
        :category => Factory.create(:category, :level_id => Category::Levels[:a])) ]
  end
end
