require File.join(Rails.root, 'test', 'solr_override.rb') if Rails.env == "test"

require File.join(Rails.root, 'test', 'factories', 'city.rb')
require File.join(Rails.root, 'test', 'factories', 'job.rb')

Factory.define :vacancy do |v|
  v.association :city, :factory => :city
  v.association :job, :factory => :job_without_vacancies
end

Factory.define :vacancy_without_job, :class => Vacancy do |v|
  v.city_id {Factory.create(:city).id}
end

