eSpace.require("OW7.Institutions.Index", {
  checkedIds: function(){
    return $.map($('.L_institution input:checkbox:checked'), function(input, i){
      return $(input).val();
    });
  },
  
  initializeInstitution: function($institution, $institutionForm){
    $institution.find('input:checkbox').change(function(){
      if (!$(this).is(':checked')) {
        $('input#mass_select').attr('checked', false);
      }
    });
    var initialTokens = [];
    var countryContainer = $institutionForm.find('.L_country_id');
    if (countryContainer.attr('data-name')) {
      initialTokens.push({
        name: countryContainer.attr('data-name'),
        value: countryContainer.attr('data-value')
      });
    }
    var countryAutocompleter = OW7.Autocompleter.initialize(countryContainer, 'institution[country_id]', '/autocomplete/countries', {
      acLimit: 1,
      noteMessage: "Type the name of the country",
      initialTokens: initialTokens
    });
    eSpace.ajaxifyForms($institution.find("form.L_delete"));
    $institution.find(".L_edit").click(function(){
      $institution.toggle();
      $institutionForm.toggle();
    });
    eSpace.ajaxifyForms($institutionForm.find('form'));
    eSpace.ajaxifyForms($institutionForm.find('form .L_cancel')).click(function(){
      $institution.toggle();
      $institutionForm.toggle();
    });
  },
  
  initializeInstitutions: function(){
    $institutions = $('#institutions');
    $institutions.find('input#mass_select').change(function(){
      $institutions.find('.L_institution input:checkbox').attr('checked', $(this).is(":checked"));
    });
    var $massSelects = $institutions.find('#mass_select_top, #mass_select_bottom');
    $massSelects.change(function(){
      $this = $(this);
      $massSelects.val($this.val());
      if ($this.val().length > 0) {
        $('form#' + $this.val()).submit();
      }
    });
    var serializeIds = function($form, options){
      var ids = OW7.Institutions.Index.checkedIds();
      $form.find('input[name=ids[]]').remove();
      if (ids.length > 0) {
        $.each(ids, function(){
          $form.append('<input type="hidden" name="ids[]" value="' + this + '"/>');
        });
        return true;
      }
      OW7.Flash.error("Select institutions first");
      return false;
    }
    eSpace.ajaxifyForms($institutions.find('form.L_mass'), {
      beforeSerialize: serializeIds
    });
    
    $institutions.find('.pagination a, .L_sorter a').live('click', function(){
      $.getScript($(this).attr('href'));
      return false;
    });
    
    $institutions.find('.L_institution').each(function(){
      OW7.Institutions.Index.initializeInstitution($(this), $(this).next('.L_institution_form'));
    });
  },
  initialize: function(){
    var $mainActions = $('.L_main_actions');
    var $newForm = $('#new_institution');
    var $mergeForm = $('#merge_institutions');
    
    var initializeLinkAndForm = function($link, $form){
      eSpace.ajaxifyForms($form);
      $form.find('.L_cancel').click(function(){
        $form.slideUp('fast', function(){
          $mainActions.show();
        });
      });
      $link.click(function(){
        $mainActions.hide();
        $form.slideDown('fast').clearForm();
        //quick and dirty
        iC.clearTokens(false);
        iID.clearTokens(false);
        iIDs.clearTokens(false);
      });
    };
    
    var iC = OW7.Autocompleter.initialize($newForm.find('.L_country_id'), 'institution[country_id]', '/autocomplete/countries', {
      acLimit: 1,
      noteMessage: "Type the name of the country"
    });
    
    var iID = OW7.Autocompleter.initialize($mergeForm.find('.L_id'), 'id', '/autocomplete/institutions', {
      acLimit: 1,
      noteMessage: "Type the name of the Institution"
    });
    var iIDs = OW7.Autocompleter.initialize($mergeForm.find('.L_ids'), 'ids[]', '/autocomplete/institutions', {
      acLimit: 5,
      noteMessage: "Type the name of the Institution"
    });
    
    initializeLinkAndForm($mainActions.find('.L_add'), $newForm);
    initializeLinkAndForm($mainActions.find('.L_merge'), $mergeForm);
    
    OW7.Institutions.Index.hideActionForms = function(){
      $newForm.filter(':visible').slideUp('fast', function(){
        $mainActions.show();
      });
      $mergeForm.filter(':visible').slideUp('fast', function(){
        $mainActions.show();
      });
    };
    OW7.Institutions.Index.initializeInstitutions();
    eSpace.ajaxifyForms($('#institutions_filter_search'));
  }
});
