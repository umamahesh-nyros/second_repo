eSpace.require('OW7.Welcome', {


  Autocompleter: {
    //This depends on both jquery templates and jquery autocomplete
    template: $.template('<a href="javascript:void(0);" class="token">${name} <span class="close">&nbsp;</span><input type="hidden" name="${input_name}" value="${input_value}" /></a>'),

    initialize: function(container, name, url, options){
      var options = options || {}

      var temp = container.find(".L_template");
      temp = (temp.length > 0) ? $.template(temp.val()) : null
      var template = options.template || temp || this.template

      var process
      if (options.process && (typeof options.process === 'function')) {
        process = options.process
      }
      else {
        process = function(container, data){
          return {
            name: data.name,
            input_name: name,
            input_value: data.value
          }
        }
      }

      var cleanup = options.cleanup ||
      (function(close, item){
        close.next('input').disable().change();
        item.remove();
      })

      var note = container.find('.ac-note');
      var noteMessage = options && options.noteMessage || "Type a name";

      if (container.find(".tokenizer").length == 0) {
        container.append('<div class="tokenizer"><div class="tokenizer_input"><input type="text" /></div></div>');
      }

      var acInput = container.find('.tokenizer_input input');
      var updateInputVisibility = function(){
        if (options && options.acLimit && container.find('.token:visible').length >= options.acLimit) {
          acInput.hide();
        }
        else {
          acInput.show().val('');
        }
      };
      container.find('.token .close').live('click', function(){
        cleanup($(this), $(this).parent('.token'));
        updateInputVisibility();
        acInput.focus();
        options && options.removeCallback && options.removeCallback(container, $(this));
        return false
      });
      acInput.autocomplete(url, $.extend({
        dataType: 'json',
        minChars: 1,
        max: 10,
        scrollHeight: 300,
        inputContainer: container,
        parse: function(data){
          var rows = [];
          for (var i = 0; i < data.length; i++) {
            rows[i] = {};
            rows[i].data = data[i];
            rows[i].value = data[i].name;
            rows[i].name = data[i].name;
            rows[i].result = data[i].name;
          }
          return rows;
        },
        formatItem: function(data, i, n){
          return data.display_name || data.name;
        },
        extraParams: {
          "values": function(){
            return $.map(container.find('.token input'), function(x){
              return x.value;
            });
          }
        }
      }, options));

      //TODO: re-show hidden fields if present
      // prevent duplicate entries
      var addItem = function(data){
        container.find('.tokenizer_input').before(template.apply(process(container, data)));
        updateInputVisibility();
        container.find('.token:last input').change();
        options && options.addCallback && options.addCallback(container, data);
      }

      acInput.result(function(e, data){
        addItem(data);
        acInput.focus();
      }).beforeRequest(function(){
        note.html("").hide();
      }).focus(function(){
        note.html(noteMessage).show();
      }).blur(function(){
        note.html("").hide();
      });
      ;

      container.find('.tokenizer').click(function(){
        acInput.focus();
      });

      if (options.oldItems) {
        $.each(options.oldItems, function(){
          addItem(this)
        })
      }

      updateInputVisibility();
    }
  },
  
  initialize: function() {
    eSpace.ajaxifyForms($('#hot_jobs form'));

    form = $("#jobs_search")
    var process = function(container, data){
      return {
        name: data.name,
        id: data.value,
        num: calculateNum(container)
      }
    }

    var cleanup = function(close, item){
      var del = item.find('input.L_delete_checkbox');
      if (del.length > 0) {
        del.attr('checked', true);
        item.hide();
      }
      else {
        close.next('input').disable().change();
        item.remove();
      }
    }

      var calculateNum = function(container){
      var num;

      var extractIndex = function(e){
        return parseInt(e.attr('id').match(/L_item_(\d+)/)[1], 10);
      };

      var elements = container.find(".token");

      if (elements.length === 0) {
        num = 0;
      }
      else
        if (elements.length == 1) {
          num = extractIndex(elements) + 1;
        }
        else {
          var first = $(elements[0]);
          var last = $(elements[elements.length - 1]);
          num = Math.max(extractIndex(first), extractIndex(last)) + 1;
        }

      return num
    }

      this.Autocompleter.initialize(form.find(".L_job_cities"), "", '/autocomplete/cities?', {
      acLimit: 3,
      noteMessage: "Type a city name",
      process: process,
      cleanup: cleanup
    });

    var other = form.find("input.L_city_ids[value=-5]");

    var otherToggleCity = function(){
      if (other.is(':checked')) {
        form.submit();
       // form.find(".city-tokenizer").show().find('select').enable();
      }
      else {
       // form.find(".city-tokenizer").hide().find('select').disable();
      }
    };

    other.change(otherToggleCity);
    otherToggleCity();
      }

});

