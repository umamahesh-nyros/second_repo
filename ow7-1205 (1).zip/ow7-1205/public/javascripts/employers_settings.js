eSpace.require("OW7.Employers.Settings", {

  updateLogo: function(formId, src) {
    if (formId === 'upload_logo' || formId === 'delete_logo') {
      $('img#L_logo').attr('src', src);
    }
  },
  
  initialize: function(options){
    options = options || {};
    
    var cities_url = '/autocomplete/cities';
    var confirm_delete = options.confirm_delete || "Are you sure you want to delete your logo?";
    
    var form = $("form.L_edit_employer");
    var uploadForm = $("form#upload_logo");
    var deleteForm = $("form#delete_logo");
            
    var changeLogo = $("#L_toggle_upload_logo");
    uploadForm.find('.L_cancel_upload').click(function() {
      changeLogo.click();
    });
    uploadForm.find('.L_logo_file').change(function() {
      uploadForm.submit();
    });

    eSpace.ajaxifyForms(deleteForm, {
      beforeSubmit: function() {
        return confirm(confirm_delete);
      }
    });
    eSpace.ajaxifyForms(uploadForm, {
      success: function() {
        changeLogo.click();
      }
    });

    eSpace.toggleLink($("#L_toggle_more_info"), $("#L_more_info"), null, {
      collapsed: "collapsed", expanded: "expanded"
    });
    
    eSpace.toggleLink(changeLogo, $("div#L_upload_logo"), null, {
      collapsed: "button-change", expanded: "button-cancel-small"
    });

    var phone_code = form.find('.L_code');
    OW7.Employers.Registration.Autocompleter.initialize(form.find(".L_employer_city"), "employer[city_id]", cities_url, {
      acLimit:1,
      noteMessage: "Type a city name",
      addCallback: function(container, data){
        if (data.dialing_codes && data.dialing_codes.length > 0) {
          phone_code.val(data.dialing_codes[0]);
        }
      },
      removeCallback: function(container, close) {
        phone_code.val("");
      }
    });
  }
  
});

