eSpace.require("OW7.Candidates.Settings", {

  initialize: function(initialData1, initialData2, initialData3){
    OW7.Candidates.Registration.Step1.initialize(initialData1);
    OW7.Candidates.Registration.Step2.initialize(initialData2);
    var form = $('form.L_registration');
    var genderRadios = form.find('input.L_gender_id');
    var female = form.find("input.L_gender_id[value=" + OW7.Constants.Gender.female + "]");
    
    var femaleToggleSegregation = function(){
      if (female.is(':checked')) {
        form.find(".L_segregation").show().find('select').enable();
      }
      else {
        form.find(".L_segregation").hide().find('select').disable();
      }
    };
    
    genderRadios.change(femaleToggleSegregation);
    femaleToggleSegregation();

  
    var other = form.find("input.L_city_ids[value=-5]");

    var otherToggleCity = function(){
      if (other.is(':checked')) {
        form.find(".city-tokenizer").show().find('select').enable();
      }
      else {
        form.find(".city-tokenizer").hide().find('select').disable();
      }
    };

    other.change(otherToggleCity);
    otherToggleCity();

    OW7.Candidates.Registration.Step3.initialize(initialData3);
  }
  
});

