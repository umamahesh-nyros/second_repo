var eSpace = {
  ajaxifyForms: function(forms, xtras){
    xtras = xtras || {};
    xtras._beforeSend = xtras.beforeSend;
    xtras._complete = xtras.complete;
    delete xtras.beforeSend;
    delete xtras.complete;
    
    forms = forms.not('.L_ajaxified');
    
    forms.each(function(){
      var theForm = $(this);
      var spinner = theForm.find('.L_spinner');
      var loading = false;
      var options = {
        dataType: 'script',
        beforeSend: function(){
          if (loading) { return false; }

          var value = xtras._beforeSend && xtras._beforeSend.apply(this, arguments);
          if (value === false) { return false; }
          
          loading = true;
          spinner.show();
          return loading;
        },
        complete: function(){
          loading = false;
          spinner.hide();
          return xtras._complete ? xtras._complete.apply(this, arguments) : true
        }
      };
      $.extend(options, xtras);

      theForm.submit(function(){
        theForm.ajaxSubmit(options);
        return false;
      });
      
      theForm.find('.L_submit').click(function(){
        theForm.submit();
      });

    });
    return forms.addClass('L_ajaxified');
  },
  
  toggleLink: function(link, element, callback, linkStyles){
    linkStyles = linkStyles || {};
    var collapsed = linkStyles.collapsed || "";
    var expanded = linkStyles.expanded || "";
    
    function update(){
      if (element.is(":visible")) {
        link.removeClass(collapsed);
        link.addClass(expanded);
        element.find('input, textarea, select').enable();
      }
      else {
        link.removeClass(expanded);
        link.addClass(collapsed);
        element.find('input, textarea, select').disable();
      }
    }
    
    update();
    
    link.click(function(event){
      event.preventDefault();
      element.toggle(0, callback);
      update();
    })
  },
  
  hoverFunctions: function (item, functions) {
    item = item || '.L_item';
    functions = functions || '.L_functions';
    
    $(item).live('mouseover', function() {
      $(this).find(functions).show();
    }).live('mouseout', function() {
      $(this).find(functions).hide();
    });
  
  },
  
  require: function(namespaces, properties){
    namespacesArray = namespaces.split(".");
    var parent = window;
    $.each(namespacesArray, function(i, namespace){
      if (typeof parent[namespace] === "undefined") {
        parent[namespace] = {};
      }
      parent = parent[namespace];
    });
    $.extend(parent, properties);
  },
  
  cascadeLists: function(parentId, childId, callbackFunction){
    $("body").append('<select style="display:none" id="' + parentId + childId + '"></select>');
    var childOptions = $('#' + childId + ' option');
    $('#' + parentId + childId).html(childOptions);
    $('#' + parentId).change(function(){
      var parent = $('#' + parentId)[0];
      var selectedOptionValue = '';
      if (parent.selectedIndex > -1) 
        selectedOptionValue = parent.options[parent.selectedIndex].value;
      if (selectedOptionValue == '') 
        $('#' + childId).html($('#' + parentId + childId + ' option[value=""]').clone());
      else {
        var childs = $('#' + parentId + childId + ' option[parent="' + selectedOptionValue + '"]');
        if (childs.size() == 0) 
          $('#' + childId).html($('#' + parentId + childId + ' option[value=""]').clone());
        else 
          $('#' + childId).html($('#' + parentId + childId + ' option[parent="' + selectedOptionValue + '"]').clone());
      }
      $('#' + childId).trigger("change");
      
      if (callbackFunction != null) 
        callbackFunction(parent.options[parent.selectedIndex]);
    });
    $('#' + parentId).trigger("change");
  },
  
  alternateStyle: function(elements, evenClass){
    elements.filter(':even').toggleClass(evenClass, true);
    elements.filter(':odd').toggleClass(evenClass, false);
  },
  
  ajaxifyLinks: function(links, options){
    var options = options || {};
    
    links.click(function(e){
      e.preventDefault();
      
      if (options.confirmMessage && !confirm(options.confirmMessage)) {
        return false;
      }
      
      var loading = false;
      var link = $(this);
      
      $.ajax({
        type: options.type || 'GET',
        url: this.href,
        data: options.data,
        dataType: options.dataType || 'script',
        beforeSend: function(xhr){
          if (loading) {
            return false;
          }
          var value;
          if (options.beforeSend) {
            value = options.beforeSend(xhr, link);
          }
          
          loading = (value === false ? value : true);
          
          return loading;
        },
        complete: function(xhr, textStatus){
          loading = false;
          if (options.complete) {
            options.complete(xhr, textStatus, link);
          }
        },
        success: function(data, textStatus){
          if (options.success) {
            options.success(data, textStatus, link);
          }
        },
        error: (function(){
          if (options.error) {
            return function(xhr, textStatus, thrownError){
              options.error(xhr, textStatus, thrownError, link);
            };
          }
          else {
            return function(xhr, textStatus, thrownError){
              alert(xhr.responseText);
            };
          }
        })()
      });
    });
  }
  
};
