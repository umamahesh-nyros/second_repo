eSpace.require("OW7.Constants", {
  Gender: {male: 1, female: 2},
  SaudiArabia: {"name":"SAUDI ARABIA","iso3":"SAU","iso":"SA","id":180,"dialing_code_1":966,"dialing_code_2":null,"printable_name":"Saudi Arabia","dialing_code_3":null,"degree_language_id":1,"numcode":682},
  Flashes: ["notice","error","warning"],
  DateFormats: {"year_month":"yy-mm","full":"yy-mm-dd"},
  DateRegexes: {"year_month":/\d{4}-\d{2}/,"full":/\d{4}-\d{2}-\d{2}/},
  ConfirmDeleteComment: "Are you sure you want to delete this comment?"
});
