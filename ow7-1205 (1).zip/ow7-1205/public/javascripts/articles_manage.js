eSpace.require("OW7.Articles.Manage", {

  initializeArticle: function($article){
    $article.find('input:checkbox').change(function(){
      if(!$(this).is(':checked')){
        $('input#mass_select').attr('checked', false);
      }
    });
    eSpace.ajaxifyForms($article.find('form'));
  },
  
  initialize: function(){
    $('input#mass_select').change(function(){
      $('.L_article input:checkbox').attr('checked', $(this).is(":checked"));
    });
    $('form.L_mass').submit(function(){
      var $form = $(this);
      $form.find('input[name=ids[]]').remove();
      var ids = OW7.Articles.Manage.checked_ids();
      $.each(ids, function(){
        $form.append('<input type="hidden" name="ids[]" value="'+this+'"/>');
      });
      if(ids.length == 0){
        alert('Please select items first!');
        return false;
      }
    });
    $('.L_article').each(function(){
      OW7.Articles.Manage.initializeArticle($(this));
    });
  },
  
  checked_ids: function(){
    return $.map($('.L_article input:checkbox:checked'), function(input, i){
      return $(input).val();
    });
  }
  
});

$(function(){
  OW7.Articles.Manage.initialize();
});
