eSpace.require("OW7.Events.Manage", {

  initializeEvent: function($event){
    $event.find('input:checkbox').change(function(){
      if(!$(this).is(':checked')){
        $('input#mass_select').attr('checked', false);
      }
    });
    eSpace.ajaxifyForms($event.find('form'));
  },
  
  initialize: function(){
    $('input#mass_select').change(function(){
      $('.L_event input:checkbox').attr('checked', $(this).is(":checked"));
    });
    $('form.L_mass').submit(function(){
      var $form = $(this);
      $form.find('input[name=ids[]]').remove();
      var ids = OW7.Events.Manage.checked_ids();
      $.each(ids, function(){
        $form.append('<input type="hidden" name="ids[]" value="'+this+'"/>');
      });
      if(ids.length == 0){
        alert('Please select items first!');
        return false;
      }
    });
    $('.L_event').each(function(){
      OW7.Events.Manage.initializeEvent($(this));
    });
  },
  
  checked_ids: function(){
    return $.map($('.L_event input:checkbox:checked'), function(input, i){
      return $(input).val();
    });
  }
  
});

$(function(){
  OW7.Events.Manage.initialize();
});
