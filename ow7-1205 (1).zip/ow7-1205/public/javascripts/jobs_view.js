eSpace.require("OW7.Jobs.View", {

  report: {
    success: function(){
      this.button.disable().removeClass('button-report').addClass('button-reported');
    },
    
    initialize: function() {
      this.button = $('#report_form .L_report');
      eSpace.ajaxifyForms($('#report_form'));
      this.button.enable().removeClass('button-reported').addClass('button-report');
    }
  },
  
  sms: {
  
    refresh: function(form) {
      var form = $(form);
      $('#sms').replaceWith(form);
      eSpace.ajaxifyForms(form);    
    },
  
    success: function() {
      this.hideForm();
    },
    
    error: function(form) {
      this.refresh(form);
    },
    
    initialize: function () {
      var sms = this;
      var newForm = $('#sms').remove();
      var container = $('#sms_form_container').hide();
      sms.new_phone = $(container.find('.L_template').val());
      
      var link = $('#toggle_sms');

      link.click(function (){
        if (container.is(':visible')) {
          sms.hideForm();
        } else {
          sms.showForm();
        }
        
        return false;     
      });
      
      $('#sms .L_add').live('click', function(){
        container.find('.L_add_container').append(sms.new_phone.clone());
      });
      
      $('#sms .L_remove').live('click', function(){
        $(this).parents('.L_added').remove();
      });

      $('#sms .L_cancel').live('click', function(){
        sms.hideForm();
      });
      
      sms.showForm = function () {
        var form = newForm.clone();
        container.append(eSpace.ajaxifyForms(form));
        container.show();
      };

      sms.hideForm = function () {
        container.hide();
        $('#sms').remove();
      };
            
    }
      
  },
  
  initializeRating: function(){
    eSpace.ajaxifyForms($('.L_rating form'));
    $('.L_rating select').rating({
      showCancel: false
    }).change(function(){
      $(this).parents('form').submit();
    });
  },
  
  initialize: function(comments){
    OW7.Comments.initialize(comments);
    this.report.initialize();
    this.sms.initialize();
    var params = $.extend($.deparam.querystring(), $.deparam.fragment());
    if (params.applied) {
      $('#apply_form').remove();
    }
    else {
      eSpace.ajaxifyForms($('#apply_form'));
    }
    OW7.Jobs.View.initializeRating();
  }
  
});

