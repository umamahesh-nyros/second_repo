
eSpace.require("OW7.Jobs.Candidates", {

  checkedIds: function(){
    return $.map($('.L_application input:checkbox:checked'), function(input, i){
      return $(input).val();
    });
  },
  
  checkedCandidateIds: function(){
    return $.map($('.L_application input:checkbox:checked'), function(input, i){
      return $(input).attr('data-candidate_id');
    });
  },

  update: function(){
    $.getScript($('#refresh?vacancy_id=input[name=vacancy_id]').attr('href'));
  },
  
  initialize: function(){
    var serializeIdsIntoForm = function($form, options){
      var ids = OW7.Jobs.Candidates.checkedIds();
      if (ids.length > 0) {
        $form.find('input[name=ids[]]').remove();
        $.each(ids, function(){
          $form.append('<input type="hidden" name="ids[]" value="' + this + '"/>');
        });
        return true;
      }
      return false;
    };
    $('input#mass_select').change(function(){
      $('.L_application input:checkbox').attr('checked', $(this).is(":checked"));
    });
    
    var $massSelects = $('#mass_select_top, #mass_select_bottom');
    
    $massSelects.change(function(){
      $this = $(this);
      $massSelects.val($this.val());
      if ($this.val().length > 0) {
        $('form#' + $this.val()).submit();
      }
    });
    
    eSpace.ajaxifyForms($('form.L_mass'), {
      beforeSerialize: serializeIdsIntoForm
    });

    $('.L_mass_export_pdf').submit(function(){
      return serializeIdsIntoForm($(this));
    });

    $('.L_export_csv_link').click(function(){
      var $link = $(this);
      var $linkForm = $('.L_export_form.L_' + $link.attr('data-pos'));
      var $otherForm = $('.L_export_form').not('.L_' + $link.attr('data-pos'));
      hideExportForm($otherForm);
      $linkForm.is(':visible') ? hideExportForm($linkForm) : showExportForm($linkForm);
    });

    var showExportForm = function($form){
      $form.find('input').enable().filter('checkbox').attr('checked',true).end().end().show();
    };
    var hideExportForm = function($form){
      $form.find('input').disable().end().hide();
    };

    $('.L_export_form').submit(function(){
      var $form = $(this);
      if($form.find('input[name=fields[]]:checked').length > 0 && serializeIdsIntoForm($form)){
      } else {
        return false;
      }
    }).find('.L_cancel').click(function(){
      hideExportForm($(this).parents('form'));
    });
    
    $('#mass_interviews_top, #mass_interviews_bottom').submit(function(){
      var $form = $(this);
      var ids = OW7.Jobs.Candidates.checkedCandidateIds();
      if (ids.length > 0) {
        $form.find('input[name=ids[]]').remove();
        $.each(ids, function(){
          $form.append('<input type="hidden" name="ids[]" value="' + this + '"/>');
        });
        return true;
      }
      OW7.Flash.error("Select candidates first");
      return false;
    });
    
    eSpace.ajaxifyForms($('#applications tr form'));
    
    $('.pagination a, .L_sorter a').click(function(){
      $.getScript($(this).attr('href'));
      return false;
    });
  }
  
});

$(function(){
  OW7.Jobs.Candidates.initialize();
});
