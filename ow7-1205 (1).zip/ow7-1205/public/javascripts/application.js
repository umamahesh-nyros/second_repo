eSpace.require("OW7", {

  adjustEvenOdd: function($collection){
    $collection.removeClass('odd').filter(':even').addClass('odd');
  },
  
  Flash: function(){
    var flash = $.extend({
      _container_selector: ".L_flash_container",
      _container: null,
      _template_selector: "#flash_template",
      _template: null,
      template: function(){
        if (!flash._template) {
          flash._template = $.template($(flash._template_selector).val());
        }
        return flash._template;
      },
      container: function(){
        if (!flash._container) {
          flash._container = $(flash._container_selector);
        }
        return flash._container;
      },
      show: function(t, message, options){
        flash.container().html(flash.template().apply({
          flashType: t,
          message: message
        })).slideDown('fast', function(){
          $(this).find("a.L_close").click(flash.close).focus();
        });
        setTimeout('OW7.Flash.close();', 5000);
      },
      close: function(){
        flash.container().slideUp('fast', function(){
          $(this).html('');
        });
      },
      showFromCookies: function(){
        var fc = null;
        $.each(OW7.Constants.Flashes, function(){
          fc = $.cookies.get('flash_' + this);
          if (fc) {
            //NOTE is this the only escape needed?
            OW7.Flash[this](fc.replace(/\+/g, ' '));
            $.cookies.del('flash_' + this);
          }
        });
      }
    }, function(types){
      var methods = {};
      $.each(types, function(i, t){
        methods[t] = function(message, options){
          flash.show(t, message, options);
        }
      });
      return methods;
    }(OW7.Constants.Flashes));
    
    return flash;
  }(),
  
  DefaultDatepickerOptions: {
    showOn: 'both',
    buttonImage: '/images/calendar.gif',
    buttonImageOnly: true,
    buttonText: "Choose date",
    changeMonth: true,
    changeYear: true,
    dateFormat: OW7.Constants.DateFormats.full,
    yearMonthFormat: OW7.Constants.DateFormats.year_month,
    constrainInput: true,
    yearRange: '1900:2100'
  },
  
  Login: {
    commonsInitialized: false,
    initialize: function(link){
      var box = $('#' + link.attr('data-box'));
      link.click(function(e){
        box.toggle();
        link.toggleClass("menu-open");
        return false;
      });
      box.mouseup(function(){
        return false
      });
      if (!OW7.Login.commonsInitialized) {
        OW7.Login.commonsInitialized = true;
        $(document).mouseup(function(e){
          $('.L_login_link').removeClass("menu-open");
          $('.L_login_box').hide();
        });
      }
    }
  },
  
  Autocompleter: {
    //This depends on both jquery templates and jquery autocomplete
    template: $.template('<a href="javascript:void(0);" class="token">${name} <span class="close">&nbsp;</span><input type="hidden" name="${input_name}" value="${input_value}" /></a>'),
    initialize: function(container, name, url, options){
      container.append('<div class="tokenizer"><div class="tokenizer_input"><input type="text" /></div></div><div class="ac-note" style="display:none;"></div>');
      var acInput = container.find('.tokenizer_input input');
      var note = container.find('.ac-note');
      var noteMessage = options && options.noteMessage || "Type a name";
      var clearInput = function(shouldFocus){
        acInput.show().val('');
        if (shouldFocus) {
          acInput.focus();
        }
      };
      var updateInputVisibility = function(shouldFocus){
        if (options && options.acLimit && container.find('.token').length >= options.acLimit) {
          acInput.hide();
        }
        else {
          clearInput(shouldFocus);
        }
      };
      var addToken = function(data, addOptions){
        var os = $.extend({
          shouldFocus: true
        }, addOptions);
        if (container.find('.token input[value=' + data.value + ']').length == 0) {
          container.find('.tokenizer_input').before(OW7.Autocompleter.template.apply({
            name: data.name,
            input_name: name,
            input_value: data.value
          }));
          container.find('.token:last input').change();
          container.find('.token:last .close').click(function(){
            $(this).next('input').disable().change();
            $(this).parent('.token').remove();
            updateInputVisibility(os.shouldFocus);
            options && options.removeCallback && options.removeCallback(data, acInterface);
          });
          options && options.addCallback && options.addCallback(data, acInterface);
        }
      };
      //THIS IS BAD, WE SHOULD INSTEAD REFACTOR Autocompleter into an object
      //I'm trying to expose behavior to outsiders without disrupting or
      //major refactoring
      var acInterface = {
        tokensValues: function(){
          return $.map(container.find('.token input:hidden'), function(x){
            return $(x).val();
          });
        },
        clearTokens: function(shouldFocus){
          container.find('.token').remove();
          updateInputVisibility(shouldFocus);
        },
        addToken: function(data){
          addToken(data);
          updateInputVisibility(true);
        },
        acInput: acInput
      };
      acInput.autocomplete(url, $.extend({
        dataType: 'json',
        minChars: 1,
        max: 10,
        scrollHeight: 300,
        inputContainer: container,
        parse: function(data){
          var rows = [];
          for (var i = 0; i < data.length; i++) {
            rows[i] = {};
            rows[i].data = data[i];
            rows[i].value = data[i].name;
            rows[i].name = data[i].name;
            rows[i].result = data[i].name;
          }
          return rows;
        },
        formatItem: function(data, i, n){
          return data.display_name || data.name;
        },
        extraParams: $.extend(options && options.extraParams || {}, {
          "values": function(){
            return $.map(container.find('.token input'), function(x){
              return x.value;
            });
          }
        })
      }, options));
      
      if (options && options.errors) {
        container.find(".tokenizer").toggleClass('invalid', true);
      }
      
      if (options && options.noresult) {
        acInput.noresult(options.noresult);
      }
      if (options && options.result) {
        acInput.result(options.result);
      }
      if (options && options.beforeRequest) {
        acInput.beforeRequest(options.beforeRequest);
      }
      
      if (options && options.initialTokens) {
        $.each(options.initialTokens, function(){
          addToken(this, {
            shouldFocus: false
          });
        });
        updateInputVisibility(false);
      }
      
      acInput.result(function(e, data){
        if (data.value == "__noresult__") {
          acInput.trigger("noresult");
          clearInput(false);
        }
        else {
          addToken(data);
          updateInputVisibility(true);
        }
      }).beforeRequest(function(){
        note.html("").hide();
      }).focus(function(){
        if (acInput.is(':enabled')) {
          note.html(noteMessage).show();
        }
      }).blur(function(){
        note.html("").hide();
      });
      container.find('.tokenizer').click(function(){
        acInput.filter(':visible').focus();
      });
      return acInterface;
    }
  },
  
  GPASlider: {
    initialize: function(container, options){
      var labelValue = function(value){
        return value;
      };
      if (options && options.labelValue) {
        labelValue = options.labelValue;
      }
      var initialValue = options && options.initialValue || 2;
      var setValue = function(value){
        container.find('.L_input').val(value);
        container.find('.L_label').text(labelValue(value));
      }
      container.find(".L_slider").slider({
        orientation: "vertical",
        value: initialValue,
        min: 1.5,
        max: 4.0,
        step: options && options.step || 0.5,
        slide: function(event, ui){
          setValue(ui.value);
          container.find('.L_input').change();
        }
      });
      setValue(initialValue);
    }
  },
  
  Employers: {
    CandidatesLevels: {
      initialize: function(container, options){
        var EduFilter = function(container){
          this.updateFilters = function(){
            var filter = container.find('input[type=radio]:checked');
            container.find('.L_edu_filter').find('input, select').disable().toggleClass('disabled', true);
            container.find('.L_block').find('.L_edu_filter').toggleClass('light', true);
            if (filter.length > 0) {
              var selected = container.find('.L_edu_filter.' + filter.attr('data-filter'));
              selected.find('input, select').enable().toggleClass('disabled', false);
              selected.parents('.L_block').find('.L_edu_filter').toggleClass('light', false);
            }
          };
          container.find("input[type=radio]").change(this.updateFilters);
          this.updateFilters();
        };
        var eduFilters = {};
        $.each($('.L_levels input[type=radio]'), function(){
          var level = $(this).attr('data-level');
          eduFilters[level] = new EduFilter(container.find('.L_level_' + level + ' .L_edu_filters'));
        });
        
        var more = container.find('.L_level_more');
        var pointer = container.find('.L_pointer');
        var infosContainer = container.find('.L_levels_indicator');
        var infos = infosContainer.find('.L_info');
        var hideLevels = function(){
          container.find('.L_level').hide().find('input, select').disable();
        };
        var showLevelIndicator = function(level){
          var selector = '.L_level_' + level;
          infos.not(selector).hide();
          infos.filter(selector).show();
          pointer.show();
          infosContainer.show();
        };
        var showLevelMore = function(level){
          showLevelIndicator(level);
          container.find('.L_level_' + level).show().find('input, select').enable();
          eduFilters[level].updateFilters();
        };
        var updateLevels = function(){
          hideLevels();
          var levelRadio = container.find(".L_levels input[type=radio]:checked");
          if (levelRadio.length > 0) {
            var currentLevel = levelRadio.attr('data-level');
            showLevelIndicator(currentLevel);
            more.show();
            if (more.hasClass('expanded')) {
              showLevelMore(currentLevel)
            }
          }
        }
        container.find(".L_levels input[type=radio]").change(updateLevels);
        more.click(function(){
          var levelRadio = container.find(".L_levels input[type=radio]:checked");
          if (levelRadio.length > 0) {
            //levelRadio.change();
            hideLevels();
            if (more.hasClass('collapsed')) {
              showLevelMore(levelRadio.attr('data-level'));
            }
            more.toggleClass("collapsed").toggleClass("expanded");
          }
        });
        if (options) {
          if (options.moreClickCallback) {
            more.click(options.moreClickCallback);
          }
        }
        updateLevels();
      }
    },
    
    SegregationSlider: {
      initialize: function(container){
        container.find('select').selectToUISlider({
          labelSrc: 'data-label',
          tooltipSrc: 'data-tooltip'
        });
        //a fix to the margins
        container.find('li span:first-child').css('margin-left', "-32px");
      }
    },
    
    DegreeCategorySelects: {
      initialize: function(container, oldItems){
        var suffix = 1;
        var allChildOptions = container.find('select.L_sub option').clone();
        var removeHandler = function(){
          if (container.find('.L_category').length > 1) {
            $(this).parents('.L_category').remove();
            container.find('.L_category:first select:first').change();
          }
        };
        
        var setSelected = function(container, item){
          if (item.parentId) {
            container.find('select.L_parent').val(item.parentId).change();
            if (item.childId) {
              container.find('select.L_sub').val(item.childId);
            }
          }
        }
        
        var addHandler = function(add, item){
          suffix++;
          var clone = add.parents('.L_category').clone();
          clone.find('select').each(function(){
            $(this).attr('id', $(this).attr('id') + suffix);
          });
          clone.find('select.L_sub').html(allChildOptions.clone());
          clone.find('.L_add').hide();
          clone.find('.L_remove').show().click(removeHandler);
          // attach change handler
          if (OW7.Employers.DegreeCategorySelects.attachChangeHandler) {
            OW7.Employers.DegreeCategorySelects.attachChangeHandler(clone);
          }
          container.append(clone);
          eSpace.cascadeLists(clone.find('select.L_parent').attr('id'), clone.find('select.L_sub').attr('id'));
          if (item) {
            setSelected(clone, item);
          }
        };
        eSpace.cascadeLists(container.find('select.L_parent').attr('id'), container.find('select.L_sub').attr('id'));
        container.find('.L_add').click(function(){
          addHandler($(this));
        });
        
        if (oldItems) {
          var first = oldItems.shift();
          setSelected(container, first);
          $.each(oldItems, function(){
            addHandler(container.find('.L_add:first'), this);
          });
        }
      }
    }
  },
  
  Comments: {
    options: {
      confirm_delete: OW7.Constants.ConfirmDeleteComment
    },
    initialize: function(container, options){
      $.extend(this.options, options);
      var that = this;
      eSpace.ajaxifyForms(container.find('form.L_delete_comment'), {
        beforeSubmit: function(arr, form, options){
          return confirm(that.options.confirm_delete);
        }
      });
      
      var addForm = container.find('form:has(textarea:visible)');
      eSpace.ajaxifyForms(addForm, {
        beforeSubmit: function(){
          if ($.trim(addForm.find('textarea:visible').val()) == '') {
            addForm.clearForm();
            return false;
          }
        }
      });
    }
  }
});

$(function(){
  $('.L_loading').ajaxStart(function(){
    $(this).show();
  }).ajaxStop(function(){
    $(this).hide();
    $('.tip').tipsy({
      gravity: 's'
    });
    OW7.Flash.showFromCookies();
  });
  //OW7.Login.initialize($('#employer_login'));
  OW7.Login.initialize($('#candidate_login'));
  $('.tip').tipsy({
    gravity: 's'
  });
  OW7.Flash.showFromCookies();
});
