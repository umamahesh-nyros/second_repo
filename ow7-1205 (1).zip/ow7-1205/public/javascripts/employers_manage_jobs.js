eSpace.require('OW7.Employers.Jobs.Manage', {

  updateRowColors: function() {
    var rows = $('#L_manage_jobs').find('tr:has(td)');
    eSpace.alternateStyle(rows, 'odd');
  },
  
  initialize: function(options) {
    var options = options || {};
    var confirm_delete = options.confirm_delete || "Are you sure you want to delete this job?";
    eSpace.ajaxifyForms($('form.L_vacancy_form'), {
      beforeSubmit: function(arr, form, options) {
        return confirm(confirm_delete);
      }
    });

    eSpace.hoverFunctions();  
  }
  
});


