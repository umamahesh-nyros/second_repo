eSpace.require("OW7.Events.Index", {

  allowMonthYear: false,
  
  initialize: function(){
    var $form = $("#filters_form");
    var $date = $form.find('#filter_date');
    var $month = $form.find('#filter_month');
    var $year = $form.find('#filter_year');
    
    eSpace.ajaxifyForms($form);
    
    $('#datepicker').datepicker($.extend(OW7.DefaultDatepickerOptions, {
      maxDate: '+5y',
      minDate: '-5y',
      dateFormat: 'yy-mm-dd',
      onSelect: function(dateText, inst){
        $month.disable();
        $year.disable();
        $date.enable().val(dateText);
        $form.submit();
      },
      onChangeMonthYear: function(year, month, inst){
        //skip the first request coz it happens when
        //the component is built
        if (OW7.Events.Index.allowMonthYear) {
          $date.disable();
          $month.enable().val(month);
          $year.enable().val(year);
          $form.submit();
        }
        else {
          OW7.Events.Index.allowMonthYear = true;
        }
      }
    }));
    $form.find("#filter_type_id").change(function(){
      $form.submit();
    });
    $('.pagination a').live('click', function(){
      $.getScript($(this).attr('href'));
      return false;
    });
  }
  
});

$(function(){
  OW7.Events.Index.initialize();
});
