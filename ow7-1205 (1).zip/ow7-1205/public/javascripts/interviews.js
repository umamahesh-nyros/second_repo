eSpace.require("OW7.Interviews.Form", {
  initializeSlot: function($slot){
    $slot.find('.L_date').datepicker($.extend(OW7.DefaultDatepickerOptions, {
      minDate: '+0d'
    }));
    $slot.find('.L_remove').click(function(){
      var checkbox = $slot.find('.L_delete');
      if (checkbox.length > 0) {
        checkbox.attr('checked', true);
        $slot.hide();
      }
      else {
        $slot.remove();
      }
    });
  },
  
  initialize: function(details){
    $form = $('.L_interview_edit .L_form');
    $form.find('.L_booked_toggle').click(function(){
      $(this).html($form.find('.L_booked_details').toggle().is(':visible') ? 'Hide' : 'Show');
    });
    var cityAutocompleter = OW7.Autocompleter.initialize($form.find('.L_city_id'), 'interviews_interview[city_id]', '/autocomplete/cities', {
      acLimit: 1,
      noteMessage: "Type the name of the city",
      initialTokens: details.city
    });
    $form.find('#interviews_interview_start_time_date').datepicker($.extend(OW7.DefaultDatepickerOptions, {
      minDate: '+0d'
    }));
    $form.find('#interviews_interview_confirmation_deadline').datepicker($.extend(OW7.DefaultDatepickerOptions, {
      minDate: '+1d'
    }));
    $form.find('.L_slot').each(function(){
      OW7.Interviews.Form.initializeSlot($(this));
    });
    var slotsContainer = $form.find('.L_slots');
    var slotTemplate = $.template($('#slot_template').val());
    var e = slotsContainer.find('.L_slot:last .L_date');
    var slotNumber = e.length > 0 ? (parseInt(e.attr('id').match(/interviews_interview_slots_attributes_(\d+)/)[1]) + 1) : 0;
    $form.find('.L_add_slot').click(function(){
      slotsContainer.append(slotTemplate.apply({
        num: slotNumber
      }));
      OW7.Interviews.Form.initializeSlot($form.find('.L_slot:last'));
      if ($form.find('.L_slot:visible').length > 1) {
        $form.find('.L_slot:last .L_label').html('&nbsp;');
      }
      slotNumber += 1;
    });
  }
});
eSpace.require("OW7.Interviews.Preview", {
  initialize: function($showContainer, $editContainer){
    $showContainer.find('.L_edit').click(function(){
      $showContainer.hide();
      $editContainer.show();
      return false;
    }).end().find('.L_save').submit(function(){
      $editContainer.find('.L_form').find('input[name=preview]').remove().end().submit();
      return false;
    });
  }
});
eSpace.require("OW7.Interviews.Show", {
  initialize: function(){
  }
});

eSpace.require("OW7.Interviews.Invite", {
  initialize: function(){
    $('.L_form').submit(function(){
      if ($('.L_form').find(':radio:checked').length > 0) {
        location.href = $('.L_form').find(':radio:checked').val();
      }
      else {
        OW7.Flash.error('Please select an interview first');
      }
      return false;
    });
  }
});

eSpace.require("OW7.CandidateInterviews.Show", {
  initialize: function(){
    $('.L_form').submit(function(){
      if ($('.L_form').find(':radio:checked:enabled').length > 0) {
        return true;
      }
      return false;
    });
  }
});
