eSpace.require('OW7.Employers.Registration', {

  Autocompleter: {
    //This depends on both jquery templates and jquery autocomplete
    template: $.template('<a href="javascript:void(0);" class="token">${name} <span class="close">&nbsp;</span><input type="hidden" name="${input_name}" value="${input_value}" /></a>'),
    
    initialize: function(container, name, url, options){
      var options = options || {}
      
      var temp = container.find(".L_template");
      temp = (temp.length > 0) ? $.template(temp.val()) : null
      var template = options.template || temp || this.template
      
      var process
      if (options.process && (typeof options.process === 'function')) {
        process = options.process
      }
      else {
        process = function(container, data){
          return {
            name: data.name,
            input_name: name,
            input_value: data.value
          }
        }
      }
      
      var cleanup = options.cleanup ||
      (function(close, item){
        close.next('input').disable().change();
        item.remove();
      })
      
      var note = container.find('.ac-note');
      var noteMessage = options && options.noteMessage || "Type a name";
      
      if (container.find(".tokenizer").length == 0) {
        container.append('<div class="tokenizer"><div class="tokenizer_input"><input type="text" /></div></div>');
      }
      
      var acInput = container.find('.tokenizer_input input');
      var updateInputVisibility = function(){
        if (options && options.acLimit && container.find('.token:visible').length >= options.acLimit) {
          acInput.hide();
        }
        else {
          acInput.show().val('');
        }
      };
      container.find('.token .close').live('click', function(){
        cleanup($(this), $(this).parent('.token'));
        updateInputVisibility();
        acInput.focus();
        options && options.removeCallback && options.removeCallback(container, $(this));
        return false
      });
      acInput.autocomplete(url, $.extend({
        dataType: 'json',
        minChars: 1,
        max: 10,
        scrollHeight: 300,
        inputContainer: container,
        parse: function(data){
          var rows = [];
          for (var i = 0; i < data.length; i++) {
            rows[i] = {};
            rows[i].data = data[i];
            rows[i].value = data[i].name;
            rows[i].name = data[i].name;
            rows[i].result = data[i].name;
          }
          return rows;
        },
        formatItem: function(data, i, n){
          return data.display_name || data.name;
        },
        extraParams: {
          "values": function(){
            return $.map(container.find('.token input'), function(x){
              return x.value;
            });
          }
        }
      }, options));
      
      //TODO: re-show hidden fields if present
      // prevent duplicate entries
      var addItem = function(data){
        container.find('.tokenizer_input').before(template.apply(process(container, data)));
        updateInputVisibility();
        container.find('.token:last input').change();
        options && options.addCallback && options.addCallback(container, data);
      }
      
      acInput.result(function(e, data){
        addItem(data);
        acInput.focus();
      }).beforeRequest(function(){
        note.html("").hide();
      }).focus(function(){
        note.html(noteMessage).show();
      }).blur(function(){
        note.html("").hide();
      });
      ;
      
      container.find('.tokenizer').click(function(){
        acInput.focus();
      });
      
      if (options.oldItems) {
        $.each(options.oldItems, function(){
          addItem(this)
        })
      }
      
      updateInputVisibility();
    }
  },
  
  initialize: function(options){
    options = options || {}
    
    var filter_name = function(filter){
      var t = options.filter_name || "${name}"
      return $.template(t).apply({
        name: filter
      })
    }
    
    var form = $("form.L_post_new_job")
    OW7.Employers.CandidatesLevels.initialize(form);
    form.find(".L_levels input[type=radio]:selected").change();
    
    var female = form.find("input.L_gender_ids[value=" + OW7.Constants.Gender.female + "]");
    
    var femaleToggleSegregation = function(){
      if (female.is(':checked')) {
        form.find(".L_segregation").show().find('select').enable();
      }
      else {
        form.find(".L_segregation").hide().find('select').disable();
      }
    };
    
    female.change(femaleToggleSegregation);
    femaleToggleSegregation();
    
    OW7.GPASlider.initialize(form.find('.L_gpa'), {
      labelValue: function(value){
        return value < 4.0 ? value + " and above" : value
      },
      initialValue: options.filters.gpa_range_ids
    });
    eSpace.toggleLink($("#L_toggle_more_details"), $("div#L_more_details"), null, {
      collapsed: "collapsed",
      expanded: "expanded"
    });
    
    var hasRedirection = form.find("input#has_redirection");
    var redirectionUrl = form.find('input#redirection_url');
//    hasRedirection.change(function(){
//      if (hasRedirection.is(':checked')) {
//        redirectionUrl.show();
//      }
//      else {
//        redirectionUrl.hide().val("");
//      }
//    });
    
    var calculateNum = function(container){
      var num;
      
      var extractIndex = function(e){
        return parseInt(e.attr('id').match(/L_item_(\d+)/)[1], 10);
      };
      
      var elements = container.find(".token");
      
      if (elements.length === 0) {
        num = 0;
      }
      else 
        if (elements.length == 1) {
          num = extractIndex(elements) + 1;
        }
        else {
          var first = $(elements[0]);
          var last = $(elements[elements.length - 1]);
          num = Math.max(extractIndex(first), extractIndex(last)) + 1;
        }
      
      return num
    }
    
    var process = function(container, data){
      return {
        name: data.name,
        id: data.value,
        num: calculateNum(container)
      }
    }
    
    var cleanup = function(close, item){
      var del = item.find('input.L_delete_checkbox');
      if (del.length > 0) {
        del.attr('checked', true);
        item.hide();
      }
      else {
        close.next('input').disable().change();
        item.remove();
      }
    }
    
    OW7.Employers.DegreeCategorySelects.initialize(form.find('.L_level_A .L_degree_category'), options.filters.a.degrees_category_ids);
    OW7.Employers.DegreeCategorySelects.initialize(form.find('.L_level_B .L_degree_category'), options.filters.b.degrees_category_ids);
    
    this.Autocompleter.initialize(form.find(".L_job_cities"), "", '/autocomplete/cities?', {
      acLimit: 3,
      noteMessage: "Type a city name",
      process: process,
      cleanup: cleanup
    });
    
    var phone_code = form.find('.L_code');
    if (form.find(".L_employer_city").length > 0) {
      this.Autocompleter.initialize(form.find(".L_employer_city"), "employer[city_id]", '/autocomplete/cities', {
        acLimit: 1,
        noteMessage: "Type a city name",
        addCallback: function(container, data){
          if (data.dialing_codes && data.dialing_codes.length > 0) {
            phone_code.val(data.dialing_codes[0]);
          }
        },
        removeCallback: function(container, close) {
          phone_code.val("");
        }
      });
    }
    
    if (form.find(".L_job_employer_city").length > 0) {
      this.Autocompleter.initialize(form.find(".L_job_employer_city"), "employer[jobs_attributes][0][employer_city_id]", '/autocomplete/cities', {
        acLimit: 1,
        noteMessage: "Type a city name"
      });
    }
    
    this.Autocompleter.initialize(form.find('.L_level_A .L_edu_filter.L_names'), filter_name("degrees_institution_ids"), '/autocomplete/institutions?type_id=1', {
      acLimit: 3,
      oldItems: options.filters.degrees_institution_ids,
      noteMessage: "Type a university name"
    });
    this.Autocompleter.initialize(form.find('.L_level_B .L_edu_filter.L_names'), filter_name("degrees_institution_ids"), '/autocomplete/institutions?type_id=0', {
      acLimit: 3,
      noteMessage: "Type an institution name"
    });
    
  }
  
});


