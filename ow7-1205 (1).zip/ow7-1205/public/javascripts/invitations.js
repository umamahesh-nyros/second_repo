eSpace.require("OW7.Invitations", {

  index: {
    update: function() {
      $.getScript($('#refresh').attr('href'));
    },
    
    success: function(newList) {
      $('#invitations_list').html(newList);
      OW7.Invitations.destroy.initForms();
    },
    
    initialize: function () {
      $('.pagination a, .L_sorter a').live('click', function (){
        $.getScript($(this).attr('href'));
        return false;
      });

      eSpace.hoverFunctions();
    }
  },
  
  create: {
    refresh: function(form) {
      var form = $(form).show();
      $('#new_invitation').replaceWith(form);
      eSpace.ajaxifyForms(form);    
    },
  
    success: function(message, form) {
      this.refresh(form);
      OW7.Flash.notice(message);
      OW7.Invitations.index.update();
    },
    
    error: function(form) {
      this.refresh(form);
    },
    
    initialize: function () {
      var create = this;
      var newForm = $('#new_invitation').remove().hide();
      var container = $('#new_form_container');
      
      var button = $('#create_invitation');

      button.click(function (){
        create.showForm();
        return false;     
      });
      
      create.showForm = function () {
        var form = newForm.clone();
        container.append(eSpace.ajaxifyForms(form));
        button.hide();
        form.slideDown('fast');
      };

      create.hideForm = function () {
        $('#new_invitation').slideUp('fast', function() {
          button.show();
          $(this).remove();
        });
      };
            
      $('#cancel_new').live('click', function (){
        create.hideForm();
        return false;
      });
    }
  },
  
  destroy: {
    success: function(message) {
      OW7.Flash.notice(message);
      OW7.Invitations.index.update();
    },
    
    error: function(message) {
      OW7.Flash.error(message);      
    },
    
    initialize: function(confirm_delete) {
      this.initForms = function() {
        eSpace.ajaxifyForms($('#invitations_list form'), {
          beforeSubmit: function () {
            return confirm(confirm_delete  || "Are you sure");
          }
        });
      };
      this.initForms();
    }
    
  },
  
  initialize: function (options){
    options = options || {};
    this.index.initialize();
    this.destroy.initialize(options.confirm_delete);
    this.create.initialize();
  }
  
});

