eSpace.require("OW7.Events.Form", {

  initialize: function(details){
    var $form = $('form.L_form');
    $.each(["start", "end"], function(){
      var name = this;
      $form.find('#event_' + name + '_date').datepicker($.extend(OW7.DefaultDatepickerOptions, {
        maxDate: '+5y',
        minDate: '+1d',
        onSelect: function(dateText, inst){
          if (window.console && window.console.log)
            window.console.log(name);
          $form.find('#event_' + name + '_time_1i').val(inst.currentYear);
          $form.find('#event_' + name + '_time_2i').val(inst.currentMonth + 1);
          $form.find('#event_' + name + '_time_3i').val(inst.currentDay);
        }
      }));
    });
    var cityAutocomplete = OW7.Autocompleter.initialize($form.find('.L_city'), 'event[city_id]', '/autocomplete/cities', {
      acLimit: 1,
      noteMessage: "Type the name of a city",
      initialTokens: details.city
    });
    $.each([['.L_add_street_info', '.L_street_info'], ['.L_add_more_info', '.L_more_info']], function(){
      var link = $form.find(this[0]);
      var section = $form.find(this[1]);
      link.click(function(){
        if (section.is(':visible')) {
          section.hide().find('input, textarea').disable();
        }
        else {
          section.show().find('input, textarea').enable();
        }
      });
    });
  }
  
});
