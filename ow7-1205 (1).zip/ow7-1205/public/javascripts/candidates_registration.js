eSpace.require("OW7.Candidates.Registration.Step1", {

  attachDegreesChangeHandler: function(degree){
    var step = this;
    degree.find('.L_level select').bind('change', function(){
      step.initializeDegreeDetails($(this).parents('.L_degree'), $(this.options[this.selectedIndex]).attr('data-level'));
      step.adjustAddRemoveVisibility();
    });
  },
  
  addDegree: function(){
    var step = this;
    step.degrees.find('.L_degree:last').after(step.degree_template, {});
    step.attachDegreesChangeHandler(step.degrees.find('.L_degree:last'));
  },
  
  adjustAddRemoveVisibility: function(){
    var step = this;
    step.degrees.find('.L_remove:visible:not(.L_remove:not:first)').show();
    var degreeCount = step.degrees.find('.L_degree:visible').length;
    var detailsCount = step.degrees.find('.L_details:visible').length;
    if ((degreeCount == detailsCount) && degreeCount > 0) {
      step.degrees.find('.L_add').show();
    }
    else {
      step.degrees.find('.L_add').hide();
    }
  },
  
  initializeDegreeDetails: function($degree, level, details){
    var step = this;
    $degree.find('.L_details').remove();
    if (level && level.match(/(a|b)/)) {
      if (!details) {
        details = {
          level_id: $degree.find('.L_level select').val()
        };
      }
      //adjust dateFormat
      if (details.date) {
        details.date = details.date.match(OW7.Constants.DateRegexes.year_month)[0];
      }
      details.num = step.num++;
      $degree.find('.L_level').after(step[level + "_degree_template"], details);
      
      //Institution missing
      var $newInstitutionForm = $('form#new_institution');
      var $institutionMissing = $degree.find('.L_institution_missing');
      var $institutionPresent = $degree.find('.L_institution_present');
      
      var institutionMissingCountryAutocompleter = OW7.Autocompleter.initialize($institutionMissing.find('.L_institution_country_id'), 'institution[country_id]', '/autocomplete/countries', {
        acLimit: 1,
        noteMessage: "Type the name of the country"
      });
      
      var showMissingInstitutionSection = function(){
        institutionMissingCountryAutocompleter.clearTokens(false);
        $institutionMissing.show();
      };
      $institutionMissing.find('.L_add').click(function(){
        $.each(["name", "country_id", "type_id"], function(){
          var selector = 'input[name=institution[' + this + ']]';
          var $element = $institutionMissing.find(selector);
          var value = $element.length > 0 ? $element.val() : "";
          $newInstitutionForm.find(selector).val(value);
        });
        $newInstitutionForm.ajaxSubmit({
          success: function(data){
            institutionAutocomplete.addToken(data, {
              shouldFocus: true
            });
            $institutionMissing.hide();
            $institutionPresent.show();
          },
          dataType: 'json'
        });
      });
      $institutionMissing.find('.L_cancel').click(function(){
        $institutionMissing.hide();
        $institutionPresent.show();
      });
      //initialize level stuff
      if (level == "a") {
        OW7.GPASlider.initialize($degree.find('.L_gpa'), {
          step: 0.1,
          initialValue: details.gpa || 2
        });
        //Dependent on Institution::Types
        var institutionAutocomplete = OW7.Autocompleter.initialize($degree.find('.L_institution'), 'candidate[degrees_attributes][' + details.num + '][institution_id]', '/autocomplete/institutions?type_id=1&oa=1', {
          acLimit: 1,
          noteMessage: "Type the name of your university",
          initialTokens: (details.institution ? [details.institution] : []),
          errors: details.errors && details.errors.institution,
          noresult: function(){
            $institutionPresent.hide();
            showMissingInstitutionSection();
          },
          result: function(){
            $institutionMissing.hide();
          }
        });
        institutionAutocomplete.acInput.beforeRequest(function(){
          $institutionMissing.find('input[name=institution[name]]').val(institutionAutocomplete.acInput.val());
        });
        OW7.Employers.DegreeCategorySelects.initialize($degree.find('.L_degree_category'), [{
          parentId: details.category_id,
          childId: details.sub_category_id
        }]);
      }
      else 
        if (level == "b") {
          var institutionAutocomplete = OW7.Autocompleter.initialize($degree.find('.L_institution'), 'candidate[degrees_attributes][' + details.num + '][institution_id]', '/autocomplete/institutions?type_id=0&oa=1', {
            acLimit: 1,
            noteMessage: "Type the name of your institution",
            initialTokens: (details.institution ? [details.institution] : []),
            errors: details.errors && details.errors.institution,
            noresult: function(){
              $institutionPresent.hide();
              showMissingInstitutionSection();
            },
            result: function(){
              $institutionMissing.hide();
            }
          });
          institutionAutocomplete.acInput.beforeRequest(function(){
            $institutionMissing.find('input[name=institution[name]]').val(institutionAutocomplete.acInput.val());
          });
          if (details.category_id) {
            $degree.find('.L_degree_category .L_parent').val(details.category_id);
          }
        }
      var graduation_date = $degree.find('.L_graduation_date');
      graduation_date.datepicker($.extend(OW7.DefaultDatepickerOptions, {
        maxDate: '+5y',
        minDate: '-100y',
        dateFormat: OW7.DefaultDatepickerOptions.yearMonthFormat
      }));
      
      if (details.errors && details.errors.graduation_date) {
        graduation_date.toggleClass('invalid', true);
      }
      
      if (details.method_of_study_id) {
        $degree.find('.L_method_of_study_id').val(details.method_of_study_id);
      }
    }
  },
  
  initialize: function(initialData){
    var step = this;
    step.form = $('form.L_registration');
    var $form = step.form;
    
    var nationalityCallback = function(data, ac){
      var values = ac.tokensValues();
      var isMale = $form.find('#candidate_gender_id_' + OW7.Constants.Gender.male + ':checked').length > 0;
      var isSaudi = $.inArray(OW7.Constants.SaudiArabia.id.toString(), values) >= 0;
      if (values.length == 0 || isSaudi) {
        $form.find('.L_non_saudi, .L_non_saudi_male').hide().find('input').disable();
      }
      if (values.length > 0 && !isSaudi) {
        $form.find('.L_non_saudi').show().find('input').enable();
        if (isMale) {
          $form.find('.L_non_saudi_male').show().find('input').enable();
        }
        else {
          $form.find('.L_non_saudi_male').hide().find('input').disable();
        }
      }
    };
    var nationalityAutocomplete = OW7.Autocompleter.initialize($form.find('.L_nationality'), 'candidate[country_ids][]', '/autocomplete/countries', {
      acLimit: 2,
      noteMessage: "Type the name of your country",
      initialTokens: initialData.nationality,
      addCallback: nationalityCallback,
      removeCallback: nationalityCallback,
      errors: initialData.errors && initialData.errors.nationality
    });
    $form.find('input[name=candidate[gender_id]]').change(function(){
      nationalityCallback(null, nationalityAutocomplete);
    });
    nationalityCallback(null, nationalityAutocomplete);
    
    $form.find('input#candidate_date_of_birth').datepicker($.extend(OW7.DefaultDatepickerOptions, {
      maxDate: '-18y',
      minDate: '-100y'
    }));
    
    //degrees
    step.degree_template = $.template($('#degree_container_template').val());
    step.a_degree_template = $.template($('#a_degree_template').val());
    step.b_degree_template = $.template($('#b_degree_template').val());
    step.degrees = $('.L_degrees');
    $degrees = step.degrees;
    
    step.attachDegreesChangeHandler($degrees);
    
    step.num = step.degrees.find('.L_degree').length + 1;
    
    if (initialData && initialData.education && initialData.education.length > 0) {
      $degrees.find('.L_degree select').val(initialData.education[0].level_id);
      step.initializeDegreeDetails($degrees.find('.L_degree'), initialData.education[0].level_class, initialData.education[0]);
      $.each(initialData.education.slice(1), function(){
        step.addDegree();
        $degrees.find('.L_degree:last select').val(this.level_id);
        step.initializeDegreeDetails($degrees.find('.L_degree:last'), this.level_class, this);
      });
    }
    
    $degrees.find('.L_degree .L_remove').live('click', function(){
      if ($degrees.find('.L_degree').length > 1) {
        var div = $(this).parents('.L_degree');
        var idInput = div.find('input.L_degree_id');
        var del = div.find('input.L_delete_checkbox');
        
        if (idInput.length > 0 && idInput.val() !== "" && del.length > 0) {
          del.attr('checked', true);
          div.hide();
        }
        else {
          div.remove();
        }
        step.adjustAddRemoveVisibility();
      }
    });
    $degrees.find('.L_add').click(function(){
      step.addDegree();
      step.adjustAddRemoveVisibility();
    });
    step.adjustAddRemoveVisibility();
    
  }
});

eSpace.require("OW7.Candidates.Registration.Step2", {

   Autocompleter: {
    //This depends on both jquery templates and jquery autocomplete
    template: $.template('<a href="javascript:void(0);" class="token">${name} <span class="close">&nbsp;</span><input type="hidden" name="${input_name}" value="${input_value}" /></a>'),

    initialize: function(container, name, url, options){
      var options = options || {}

      var temp = container.find(".L_template");
      temp = (temp.length > 0) ? $.template(temp.val()) : null
      var template = options.template || temp || this.template

      var process
      if (options.process && (typeof options.process === 'function')) {
        process = options.process
      }
      else {
        process = function(container, data){
          return {
            name: data.name,
            input_name: name,
            input_value: data.value
          }
        }
      }

      var cleanup = options.cleanup ||
      (function(close, item){
        close.next('input').disable().change();
        item.remove();
      })

      var note = container.find('.ac-note');
      var noteMessage = options && options.noteMessage || "Type a name";

      if (container.find(".tokenizer").length == 0) {
        container.append('<div class="tokenizer"><div class="tokenizer_input"><input type="text" /></div></div>');
      }

      var acInput = container.find('.tokenizer_input input');
      var updateInputVisibility = function(){
        if (options && options.acLimit && container.find('.token:visible').length >= options.acLimit) {
          acInput.hide();
        }
        else {
          acInput.show().val('');
        }
      };
      container.find('.token .close').live('click', function(){
        cleanup($(this), $(this).parent('.token'));
        updateInputVisibility();
        acInput.focus();
        options && options.removeCallback && options.removeCallback(container, $(this));
        return false
      });
      acInput.autocomplete(url, $.extend({
        dataType: 'json',
        minChars: 1,
        max: 10,
        scrollHeight: 300,
        inputContainer: container,
        parse: function(data){
          var rows = [];
          for (var i = 0; i < data.length; i++) {
            rows[i] = {};
            rows[i].data = data[i];
            rows[i].value = data[i].name;
            rows[i].name = data[i].name;
            rows[i].result = data[i].name;
          }
          return rows;
        },
        formatItem: function(data, i, n){
          return data.display_name || data.name;
        },
        extraParams: {
          "values": function(){
            return $.map(container.find('.token input'), function(x){
              return x.value;
            });
          }
        }
      }, options));

      //TODO: re-show hidden fields if present
      // prevent duplicate entries
      var addItem = function(data){
        container.find('.tokenizer_input').before(template.apply(process(container, data)));
        updateInputVisibility();
        container.find('.token:last input').change();
        options && options.addCallback && options.addCallback(container, data);
      }

      acInput.result(function(e, data){
        addItem(data);
        acInput.focus();
      }).beforeRequest(function(){
        note.html("").hide();
      }).focus(function(){
        note.html(noteMessage).show();
      }).blur(function(){
        note.html("").hide();
      });
      ;

      container.find('.tokenizer').click(function(){
        acInput.focus();
      });

      if (options.oldItems) {
        $.each(options.oldItems, function(){
          addItem(this)
        })
      }

      updateInputVisibility();
    }
  },

  initialize: function(initialData){
    var step = this;
    step.form = $('form.L_registration');
    var $form = step.form;
    if ($form.find('.L_segregation').length > 0) {
      OW7.Employers.SegregationSlider.initialize($form.find('.L_segregation'));
  }

       var process = function(container, data){
      return {
        name: data.name,
        id: data.value,
        num: calculateNum(container)
      }
    }

    var cleanup = function(close, item){
      var del = item.find('input.L_delete_checkbox');
      if (del.length > 0) {
        del.attr('checked', true);
        item.hide();
      }
      else {
        close.next('input').disable().change();
        item.remove();
      }
    }

      var calculateNum = function(container){
      var num;

      var extractIndex = function(e){
        return parseInt(e.attr('id').match(/L_item_(\d+)/)[1], 10);
      };

      var elements = container.find(".token");

      if (elements.length === 0) {
        num = 0;
      }
      else
        if (elements.length == 1) {
          num = extractIndex(elements) + 1;
        }
        else {
          var first = $(elements[0]);
          var last = $(elements[elements.length - 1]);
          num = Math.max(extractIndex(first), extractIndex(last)) + 1;
        }

      return num
    }

      this.Autocompleter.initialize(step.form.find(".L_job_cities"), "", '/autocomplete/cities?', {
      acLimit: 3,
      noteMessage: "Type a city name",
      process: process,
      cleanup: cleanup
    });

    var other = step.form.find("input.L_city_ids[value=-5]");

    var otherToggleCity = function(){
      if (other.is(':checked')) {
        step.form.find(".city-tokenizer").show().find('select').enable();
      }
      else {
        step.form.find(".city-tokenizer").hide().find('select').disable();
      }
    };

    other.change(otherToggleCity);
    otherToggleCity();
  }
  
});

eSpace.require("OW7.Candidates.Registration.Step3", {

  initialize: function(initialData){
    var step = this;
    step.form = $('form.L_registration');
    var $form = step.form;
    $('input#candidate_job_start_date').datepicker($.extend(OW7.DefaultDatepickerOptions, {
      maxDate: '+5y',
      minDate: '+1d',
      dateFormat: OW7.DefaultDatepickerOptions.yearMonthFormat
    }));
    if (initialData.job_start_date) {
      $('input#candidate_job_start_date').val(initialData.job_start_date);
    }
    var shouldClear = !(initialData.residenceCity.length > 0);
    var residenceCityAutoComplete = OW7.Autocompleter.initialize($form.find('.L_residence_city'), 'candidate[residence_city_id]', '/autocomplete/cities', {
      acLimit: 1,
      noteMessage: "Type a name of a city",
      extraParams: {
        country_id: function(){
          return $('.L_residence_country .token input').val();
        }
      },
      initialTokens: initialData.residenceCity
    });
    var residenceCountryAutoComplete = OW7.Autocompleter.initialize($form.find('.L_residence_country'), 'candidate[residence_country_id]', '/autocomplete/countries', {
      acLimit: 1,
      noteMessage: "Type a name of a country",
      addCallback: function(data){
        if (shouldClear) {
          residenceCityAutoComplete.clearTokens(false);
        }
        else {
          shouldClear = true;
        }
        
        if (data.value != OW7.Constants.SaudiArabia.id) {
          $form.find('.L_saudi_residence_question').show().find('input').enable();
          $form.find(".L_start_date_label").html(initialData.job_start_outside_ksa);
        }
        else {
          $form.find(".L_start_date_label").html(initialData.job_start_in_ksa);
        }
        if (data.dialing_codes && data.dialing_codes.length > 0) {
          $form.find('.L_residence_code').val(data.dialing_codes[0]);
        }
      },
      removeCallback: function(data){
        residenceCityAutoComplete.clearTokens(false);
        $form.find('.L_residence_code').val('');
        $form.find('.L_saudi_residence_question').hide().find('input').disable();
        $form.find('.L_saudi_residence').hide().find('input').disable();
        $form.find(".L_start_date_label").html(initialData.job_start_in_ksa);
      },
      initialTokens: initialData.residenceCountry,
      errors: initialData.errors && initialData.errors.residenceCountry
    });
    var saudiCityAutocomplete = OW7.Autocompleter.initialize($form.find('.L_saudi_city'), 'candidate[saudi_city_id]', '/autocomplete/cities', {
      acLimit: 1,
      noteMessage: "Type the name of a saudi city",
      extraParams: {
        country_id: OW7.Constants.SaudiArabia.id
      },
      initialTokens: initialData.saudiCity,
      errors: initialData.errors && initialData.errors.saudiCity
    });
    
    $form.find('.L_saudi_residence_question input:radio').change(function(){
      if ($(this).val() == "true") {
        $form.find('.L_saudi_residence').show().find('input').not('.L_disabled').enable();
        saudiCityAutocomplete.clearTokens(false);
      }
      else {
        $form.find('.L_saudi_residence').hide().find('input').disable();
      }
    });
    
    if ($form.find('.L_saudi_residence_question').is(':visible')) {
      $form.find('L_saudi_residence_question, .L_saudi_residence').find('input').not('.L_disabled').enable();
    }
    else {
      $form.find('L_saudi_residence_question, .L_saudi_residence').find('input').disable();
    }
  }
  
});
