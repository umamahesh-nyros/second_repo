eSpace.require("OW7.Admins", {

  index: {
    update: function() {
      $.getScript($('#refresh').attr('href'));
    },
    
    success: function(newList) {
      $('#admins_list').html(newList);
      OW7.Admins.destroy.initForms();
      OW7.Admins.update.initForms();
    },
    
    initialize: function() {
      eSpace.hoverFunctions();
    }
  },
  
  create: {
    refresh: function(form) {
      var form = $(form).show();
      $('#new_admin').replaceWith(form);
      eSpace.ajaxifyForms(form);
    },
  
    success: function(form) {
      this.refresh(form);
      OW7.Admins.index.update();
    },
    
    error: function(form) {
      this.refresh(form);
    },
    
    initialize: function () {
      var create = this;
      var newForm = $('#new_admin').remove().hide();
      var container = $('#new_form_container');
      
      var button = $('#create_admin');

      button.click(function (){
        create.showForm();
        return false;     
      });
      
      create.showForm = function () {
        var form = newForm.clone();
        container.append(eSpace.ajaxifyForms(form));
        button.hide();
        form.slideDown('fast');
      };

      create.hideForm = function () {
        $('#new_admin').slideUp('fast', function() {
          button.show();
          $(this).remove();
        });
      };
            
      $('#cancel_new').live('click', function (){
        create.hideForm();
        return false;
      });
    }
  },

  update: {
    refresh: function(form, id) {
      var form = $(form).removeClass('L_tmp').addClass('L_update').show();
      $(id).replaceWith(form);
      eSpace.ajaxifyForms(form);
    },

    success: function() {
      OW7.Admins.index.update();
    },
    
    error: function(form, id) {
      if (form && id) {
        this.refresh(form, id);
      }
    },
    
    initialize: function() {
      var update = this;
      this.initForms = function() {
        eSpace.ajaxifyForms($('#admins_list .L_update'));
      };
      
      var showEdit = function(edit) {
        var form = edit.find('.L_tmp').hide();
        var newForm = form.clone().removeClass('L_tmp').addClass('L_update').show();
        form.after(eSpace.ajaxifyForms(newForm));
        edit.show();
      };
      
      var hideEdit = function(edit) {
        edit.find('.L_update').remove();
        edit.hide();
      };
      
      $('.L_show .L_edit_button').live('click', function() {
        var show = $(this).parents('.L_show');
        show.hide();
        showEdit(show.next('.L_edit'));
      });
      
      $('.L_edit .L_cancel_edit').live('click', function() {
        var edit = $(this).parents('.L_edit');
        hideEdit(edit);
        edit.prev('.L_show').show();        
      })
      
      this.initForms();
    }
  },
  
  destroy: {
    success: function() {
      OW7.Admins.index.update();
    },
    
    initialize: function(confirm_delete) {
      this.initForms = function() {
        eSpace.ajaxifyForms($('#admins_list form.L_delete'), {
          beforeSubmit: function () {
            return confirm(confirm_delete  || "Are you sure");
          }
        });
      };
      this.initForms();
    }
    
  },
  
  initialize: function (options){
    options = options || {};
    this.index.initialize();
    this.update.initialize();
    this.destroy.initialize(options.confirm_delete);
    this.create.initialize();
  }
});

