eSpace.require("OW7.Enquiries", {

  create: {
    refresh: function(form) {
      var form = $(form);
      $('#enquiry').replaceWith(form);
      eSpace.ajaxifyForms(form);    
    },
  
    success: function() {
      this.hideForm();
    },
    
    error: function(form) {
      this.refresh(form);
    },
    
    initialize: function () {
      var create = this;
      var newForm = $('#enquiry').remove();
      var container = $('#enquiry_form_container').hide();
      
      var link = $('#toggle_enquiry');

      link.click(function (){
        if (container.is(':visible')) {
          create.hideForm();
        } else {
          create.showForm();
        }
        
        return false;     
      });
      
      create.showForm = function () {
        var form = newForm.clone();
        container.append(eSpace.ajaxifyForms(form));
        container.show();
        location.href = "#bottom"
      };

      create.hideForm = function () {
        container.hide();
        $('#enquiry').remove();
      };
            
    }
  },
    
  initialize: function (){
    this.create.initialize();
  }
  
});

