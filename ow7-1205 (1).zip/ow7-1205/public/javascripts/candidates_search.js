eSpace.require("OW7.Candidates.Search", {
  
  checkedIds: function(){
    return $.map($('.L_candidate input:checkbox:checked'), function(input, i){
      return $(input).val();
    });
  },
  initializeCandidate: function($candidate){
    $candidate.find('input:checkbox').change(function(){
      if (!$(this).is(':checked')) {
        $('input#mass_select').attr('checked', false);
      }
    });
    eSpace.ajaxifyForms($candidate.find('form'));
  },
  initializeResults: function(){
    $('input#mass_select').change(function(){
      $('.L_candidate input:checkbox').attr('checked', $(this).is(":checked"));
    });
    var $massSelects = $('#mass_select_top, #mass_select_bottom');
    $massSelects.change(function(){
      $this = $(this);
      $massSelects.val($this.val());
      if ($this.val().length > 0) {
        $('form#' + $this.val()).submit();
      }
    });
    var serializeIds = function($form, options){
      var ids = OW7.Candidates.Search.checkedIds();
      $form.find('input[name=ids[]]').remove();
      if (ids.length > 0) {
        $.each(ids, function(){
          $form.append('<input type="hidden" name="ids[]" value="' + this + '"/>');
        });
        return true;
      }
      return false;
    }
    eSpace.ajaxifyForms($('form.L_mass'), {
      beforeSerialize: serializeIds
    });
    
    $('.L_mass_export_pdf').submit(function(){
      return serializeIds($(this));
    });
    //export form
    var showExportForm = function($form){
      $form.find('input').enable().filter('checkbox').attr('checked',true).end().end().show();
    };
    var hideExportForm = function($form){
      $form.find('input').disable().end().hide();
    };
    $('.L_export_csv_link').click(function(){
      var $link = $(this);
      var $linkForm = $('.L_export_form.L_' + $link.attr('data-pos'));
      var $otherForm = $('.L_export_form').not('.L_' + $link.attr('data-pos'));
      hideExportForm($otherForm);
      $linkForm.is(':visible') ? hideExportForm($linkForm) : showExportForm($linkForm);
    });
    $('.L_export_form').submit(function(){
      var $form = $(this);
      if($form.find('input[name=fields[]]:checked').length > 0 && serializeIds($form)){
      } else {
        return false;
      }
    }).find('.L_cancel').click(function(){
      hideExportForm($(this).parents('form'));
    });
    
    //initialize rows
    $('.L_candidate').each(function(){
      OW7.Candidates.Search.initializeCandidate($(this));
    });
  },
  initialize: function(){
    var form = $('form#candidates_search');
    eSpace.ajaxifyForms(form);
    OW7.Employers.CandidatesLevels.initialize(form, {
      moreClickCallback: function(){
        form.submit();
      }
    });
    form.find(".L_levels input[type=radio]:selected").change();
    
    
    var femaleToggleSegregation = function(){
      var female = form.find("#gender_id_" + OW7.Constants.Gender.female);
      if (female.is(':checked')) {
        form.find(".L_segregation").show().find('select').enable();
      }
      else {
        form.find(".L_segregation").hide().find('select').disable();
      }
    };
    form.find("#gender_id_" + OW7.Constants.Gender.female).change(femaleToggleSegregation);
    femaleToggleSegregation();
    
    // add an optional function to attach change handler to newly added selects
    // to be removed if jQuery live works for change event in IE  
    OW7.Employers.DegreeCategorySelects.attachChangeHandler = function(added){
      added.find('input[name^=q], select[name^=q]').bind('change', function(){
        form.submit();
      });      
    };
    
    OW7.Employers.DegreeCategorySelects.initialize(form.find('.L_level_A .L_degree_category'));
    OW7.Employers.DegreeCategorySelects.initialize(form.find('.L_level_B .L_degree_category'));
    
    OW7.GPASlider.initialize(form.find('.L_gpa'), {
      labelValue: function(value){
        return value < 4.0 ? value + " and above" : value
      }
    });
    //Dependent on Institution::Types
    OW7.Autocompleter.initialize(form.find('.L_level_A .L_edu_filter.L_names'), 'q[degrees_institution_ids][]', '/autocomplete/institutions?type_id=1', {
      acLimit: 3,
      noteMessage: "Type the name of a university"
    });
    OW7.Autocompleter.initialize(form.find('.L_level_B .L_edu_filter.L_names'), 'q[degrees_institution_ids][]', '/autocomplete/institutions?type_id=0', {
      acLimit: 3,
      noteMessage: "Type the name of an institution"
    });
    OW7.Autocompleter.initialize(form.find('.L_residence_city'), 'q[residence_city_id][]', '/autocomplete/cities', {
      acLimit: 1,
      noteMessage: "Type the name of a city"
    });
    
    $('.pagination a, .L_sorter a').live('click', function(){
      $.getScript($(this).attr('href'));
      return false;
    });
    
    form.find('input[name^=q], select[name^=q]').bind('change', function(){
      form.submit();
    });
  }
});

$(function(){
  OW7.Candidates.Search.initialize();
});
