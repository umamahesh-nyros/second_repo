eSpace.require('OW7.Employers.Search', {

  checkedIds: function(){
    return $.map($('.L_employer input:checkbox:checked'), function(input, i){
      return $(input).val();
    });
  },
  
  initializeEmployer: function($employer, $employerForms){
    $employer.find('input:checkbox').change(function(){
      if (!$(this).is(':checked')) {
        $('input#mass_select').attr('checked', false);
      }
    });


    var $form_containers = $employerForms.find(".L_container");
    var $block_container = $form_containers.filter('.L_block');
    var $paid_container = $form_containers.filter('.L_paid');
    var $expiry_date_input = $paid_container.find('input.L_paid_till');

    $expiry_date_input.datepicker($.extend(OW7.DefaultDatepickerOptions, {
      maxDate: '+5y',
      minDate: '+0d'
    }));

    $employerForms.find('form.L_block .L_cancel, form.L_paid .L_cancel').click(function(){
      $expiry_date_input.val("").toggleClass('invalid', false);
      $employerForms.hide();
      $form_containers.hide();
    });
    
    $employer.find('form.L_block_show').submit(function(){
      $block_container.show();
      $employerForms.show();
      return false;
    });

    $employer.find('form.L_paid_show').submit(function(){
      $paid_container.show();
      $employerForms.show();
      return false;
    });

    eSpace.ajaxifyForms($employer.find('form.L_unblock'));
    eSpace.ajaxifyForms($employerForms.find('form.L_block'));
    eSpace.ajaxifyForms($employerForms.find('form.L_paid'));
    eSpace.ajaxifyForms($employer.find('form.L_non_paid'));
    
    var $employer_concise = $employer.find('td:not(.L_details)');
    var $employer_details = $employer.find('.L_details');
    $employer.find(".L_name").click(function(){
      $employer_concise.hide();
      $employerForms.hide();
      $employer_details.show();
    });
    
    $employer_details.click(function(){
      $employer_details.hide();
      $employer_concise.show();
    }).find('a').click(function(event){
      //so that it wont minimize the details
      event.stopPropagation();
    });
  },
  
  initializeResults: function(){
    $results = $('#results');
    $results.find('input#mass_select').change(function(){
      $results.find('.L_employer input:checkbox').attr('checked', $(this).is(":checked"));
    });
    
    var $massSelects = $('#mass_select_top, #mass_select_bottom');
    $massSelects.change(function(){
      $this = $(this);
      $massSelects.val($this.val());
      if ($this.val().length > 0) {
        $results.find('form#' + $this.val()).submit();
      }
    });
    
    eSpace.ajaxifyForms($results.find('form.L_mass'), {
      beforeSerialize: function($form, options){
        var ids = OW7.Employers.Search.checkedIds();
        if (ids.length > 0) {
          $form.find('input[name=ids[]]').remove();
          $.each(ids, function(){
            $form.append('<input type="hidden" name="ids[]" value="' + this + '"/>');
          });
          return true;
        }
        return false;
      }
    });
    
    $results.find('.L_employer').each(function(){
      OW7.Employers.Search.initializeEmployer($(this), $(this).next('.L_employer_forms'));
    });
    
    $('.pagination a, .L_sorter a').click(function(){
      $.getScript($(this).attr('href'));
      return false;
    });
  },
  
  initialize: function(options){
    $form = $('form#employers_search_form');
    OW7.Autocompleter.initialize($form.find(".L_city"), 'q[city_id][]', '/autocomplete/cities', {
      acLimit: 3,
      noteMessage: "Type the name of a city"
    });
    eSpace.ajaxifyForms($form);
    $form.find('input').change(function(){
      $form.submit();
    });
    OW7.Employers.Search.initializeResults();
  }
  
});

$(function(){
  OW7.Employers.Search.initialize();
});
