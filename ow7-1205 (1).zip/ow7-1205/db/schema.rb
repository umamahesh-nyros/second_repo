# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of Active Record to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20101001000010) do

  create_table "admins", :force => true do |t|
    t.string   "email"
    t.string   "crypted_password"
    t.string   "password_salt"
    t.string   "persistence_token"
    t.string   "single_access_token",                    :null => false
    t.string   "perishable_token"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "super_admin",         :default => false
    t.string   "name"
  end

  create_table "applications", :force => true do |t|
    t.integer "candidate_id",                    :null => false
    t.integer "vacancy_id",                      :null => false
    t.boolean "screening"
    t.integer "job_id",                          :null => false
    t.integer "status_id",    :default => 0,     :null => false
    t.boolean "short_listed", :default => false
    t.boolean "rejected",     :default => false
  end

  add_index "applications", ["candidate_id"], :name => "index_vacancies_candidates_on_candidate_id"
  add_index "applications", ["status_id"], :name => "index_applications_on_status_id"
  add_index "applications", ["vacancy_id"], :name => "index_vacancies_candidates_on_vacancy_id"

  create_table "arabic_candidates", :force => true do |t|
    t.string   "name"
    t.string   "email"
    t.string   "cv_file_name"
    t.string   "cv_content_type"
    t.integer  "cv_file_size"
    t.datetime "cv_updated_at"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "articles", :force => true do |t|
    t.string   "creator_type",       :limit => 15, :null => false
    t.integer  "creator_id",                       :null => false
    t.string   "title",                            :null => false
    t.text     "body",                             :null => false
    t.integer  "status_id",                        :null => false
    t.string   "image_file_name"
    t.string   "image_content_type"
    t.integer  "image_file_size"
    t.datetime "image_updated_at"
    t.datetime "created_at"
    t.datetime "published_at"
  end

  add_index "articles", ["creator_type", "creator_id", "status_id"], :name => "index_articles_on_creator_type_and_creator_id_and_status_id"
  add_index "articles", ["status_id", "published_at"], :name => "index_articles_on_status_id_and_published_at"

  create_table "candidates", :force => true do |t|
    t.string   "email"
    t.string   "crypted_password"
    t.string   "password_salt"
    t.string   "persistence_token"
    t.string   "single_access_token",                 :null => false
    t.string   "perishable_token"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "first_name",                          :null => false
    t.string   "last_name",                           :null => false
    t.string   "cv_file_name"
    t.string   "cv_content_type"
    t.integer  "cv_file_size"
    t.datetime "cv_updated_at"
    t.integer  "gender_id",                           :null => false
    t.date     "date_of_birth"
    t.integer  "marital_status_id",                   :null => false
    t.integer  "iqama_id"
    t.boolean  "saudi_mother"
    t.boolean  "saudi_spouse"
    t.integer  "job_mixing_id"
    t.date     "job_start_date"
    t.integer  "residence_city_id"
    t.string   "residence_phone"
    t.integer  "saudi_city_id"
    t.string   "saudi_phone"
    t.boolean  "entry_level"
    t.integer  "language_id",          :default => 0, :null => false
    t.integer  "status_id",                           :null => false
    t.integer  "residence_country_id"
    t.string   "avatar_file_name"
    t.string   "avatar_content_type"
    t.integer  "avatar_file_size"
    t.datetime "avatar_updated_at"
    t.datetime "last_updated",                        :null => false
    t.datetime "current_login_at"
    t.datetime "last_login_at"
  end

  create_table "candidates_countries", :force => true do |t|
    t.integer "candidate_id", :null => false
    t.integer "country_id",   :null => false
  end

  add_index "candidates_countries", ["candidate_id"], :name => "index_candidates_countries_on_candidate_id"
  add_index "candidates_countries", ["country_id"], :name => "index_candidates_countries_on_country_id"

  create_table "candidates_job_cities", :force => true do |t|
    t.integer "candidate_id", :null => false
    t.integer "city_id",      :null => false
  end

  add_index "candidates_job_cities", ["candidate_id"], :name => "index_candidates_job_cities_on_candidate_id"
  add_index "candidates_job_cities", ["city_id"], :name => "index_candidates_job_cities_on_city_id"

  create_table "candidates_job_types", :force => true do |t|
    t.integer "candidate_id", :null => false
    t.integer "job_type_id",  :null => false
  end

  add_index "candidates_job_types", ["candidate_id"], :name => "index_candidates_job_types_on_candidate_id"
  add_index "candidates_job_types", ["job_type_id"], :name => "index_candidates_job_types_on_job_type_id"

  create_table "candidates_sections", :id => false, :force => true do |t|
    t.integer "candidate_id"
    t.integer "section_id"
  end

  create_table "categories", :force => true do |t|
    t.string  "name",                     :null => false
    t.integer "parent_id"
    t.integer "level_id",  :default => 0, :null => false
  end

  add_index "categories", ["level_id"], :name => "index_categories_on_level_id"
  add_index "categories", ["parent_id"], :name => "index_categories_on_parent_id"

  create_table "cities", :force => true do |t|
    t.string  "name",                               :null => false
    t.integer "country_id",                         :null => false
    t.boolean "job",             :default => false, :null => false
    t.string  "arabic_name"
    t.text    "alternate_names"
    t.integer "position"
  end

  add_index "cities", ["country_id"], :name => "index_cities_on_country_id"
  add_index "cities", ["job"], :name => "index_cities_on_job"

  create_table "comments", :force => true do |t|
    t.string   "title",            :limit => 50, :default => ""
    t.string   "comment",                        :default => ""
    t.datetime "created_at",                                     :null => false
    t.integer  "commentable_id",                 :default => 0,  :null => false
    t.string   "commentable_type", :limit => 15, :default => "", :null => false
    t.integer  "commenter_id",                   :default => 0,  :null => false
    t.string   "commenter_type",   :limit => 15, :default => "", :null => false
    t.integer  "status_id",                      :default => 0,  :null => false
  end

  add_index "comments", ["commentable_id", "commentable_type"], :name => "fk_comments_commentable"
  add_index "comments", ["commenter_id", "commenter_type"], :name => "fk_comments_commenter"
  add_index "comments", ["status_id"], :name => "index_comments_on_status_id"

  create_table "countries", :force => true do |t|
    t.string  "iso"
    t.string  "name"
    t.string  "printable_name"
    t.string  "iso3"
    t.integer "numcode"
    t.integer "dialing_code_1"
    t.integer "dialing_code_2"
    t.integer "dialing_code_3"
    t.integer "degree_language_id"
  end

  create_table "degrees", :force => true do |t|
    t.integer "candidate_id",       :null => false
    t.date    "date"
    t.integer "level_id",           :null => false
    t.integer "category_id"
    t.integer "sub_category_id"
    t.string  "title"
    t.integer "institution_id"
    t.integer "method_of_study_id"
    t.float   "gpa"
  end

  add_index "degrees", ["candidate_id"], :name => "index_degrees_on_candidate_id"
  add_index "degrees", ["institution_id"], :name => "index_degrees_on_institution_id"
  add_index "degrees", ["level_id"], :name => "index_degrees_on_level_id"
  add_index "degrees", ["sub_category_id"], :name => "index_degrees_on_sub_category_id"

  create_table "emails", :force => true do |t|
    t.string   "from"
    t.string   "to"
    t.integer  "last_send_attempt", :default => 0
    t.text     "mail"
    t.datetime "created_on"
  end

  create_table "employers", :force => true do |t|
    t.string   "email"
    t.string   "crypted_password"
    t.string   "password_salt"
    t.string   "persistence_token"
    t.string   "single_access_token",                    :null => false
    t.string   "perishable_token"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "name",                                   :null => false
    t.string   "website",                                :null => false
    t.string   "logo_file_name"
    t.string   "logo_content_type"
    t.integer  "logo_file_size"
    t.datetime "logo_updated_at"
    t.integer  "city_id",                                :null => false
    t.string   "person_name",                            :null => false
    t.string   "phone",                                  :null => false
    t.boolean  "contacts_hidden",     :default => false, :null => false
    t.text     "more_info"
    t.integer  "status_id",           :default => 0,     :null => false
    t.string   "block_reason"
    t.boolean  "ngo",                 :default => false, :null => false
    t.boolean  "paid",                :default => false, :null => false
    t.date     "paid_expiry_date"
  end

  add_index "employers", ["city_id"], :name => "index_employers_on_city_id"

  create_table "enquiries", :force => true do |t|
    t.string   "name",       :null => false
    t.string   "email",      :null => false
    t.integer  "type_id",    :null => false
    t.string   "subject"
    t.text     "message"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "events", :force => true do |t|
    t.string   "creator_type",       :limit => 15,                :null => false
    t.integer  "creator_id",                                      :null => false
    t.string   "title",                                           :null => false
    t.text     "description",                                     :null => false
    t.text     "more_info"
    t.string   "location"
    t.string   "street"
    t.integer  "city_id"
    t.integer  "type_id",                                         :null => false
    t.integer  "status_id",                                       :null => false
    t.string   "image_file_name"
    t.string   "image_content_type"
    t.integer  "image_file_size"
    t.datetime "image_updated_at"
    t.datetime "start_time",                                      :null => false
    t.datetime "end_time",                                        :null => false
    t.datetime "created_at"
    t.datetime "published_at"
    t.integer  "employer_gender",                  :default => 3, :null => false
    t.integer  "candidate_gender",                 :default => 3, :null => false
  end

  create_table "institutions", :force => true do |t|
    t.string  "name",                             :null => false
    t.integer "type_id",       :default => 0,     :null => false
    t.integer "country_id",                       :null => false
    t.integer "ranking_id",    :default => 3,     :null => false
    t.boolean "ivy_league",    :default => false, :null => false
    t.integer "global_rank"
    t.integer "language_id"
    t.integer "adder_type_id"
  end

  add_index "institutions", ["country_id"], :name => "index_institutions_on_country_id"
  add_index "institutions", ["ranking_id"], :name => "index_institutions_on_ranking_id"
  add_index "institutions", ["type_id"], :name => "index_institutions_on_type_id"

  create_table "interviews", :force => true do |t|
    t.integer "employer_id",           :null => false
    t.integer "vacancy_id",            :null => false
    t.integer "city_id"
    t.text    "location"
    t.date    "confirmation_deadline"
    t.string  "contact_person"
    t.string  "contact_phone"
    t.string  "contact_email"
    t.integer "duration",              :null => false
  end

  create_table "interviews_connections", :force => true do |t|
    t.integer  "interview_id",                :null => false
    t.integer  "candidate_id",                :null => false
    t.integer  "status_id",    :default => 0, :null => false
    t.integer  "slot_id"
    t.datetime "time"
  end

  add_index "interviews_connections", ["candidate_id", "status_id"], :name => "index_interviews_connections_on_candidate_id_and_status_id"
  add_index "interviews_connections", ["interview_id", "status_id"], :name => "index_interviews_connections_on_interview_id_and_status_id"
  add_index "interviews_connections", ["slot_id", "status_id"], :name => "index_interviews_connections_on_slot_id_and_status_id"

  create_table "interviews_slots", :force => true do |t|
    t.integer  "interview_id"
    t.integer  "status_id",    :default => 0, :null => false
    t.datetime "time"
  end

  add_index "interviews_slots", ["interview_id"], :name => "index_interviews_slots_on_interview_id"

  create_table "invitations", :force => true do |t|
    t.string   "email",        :null => false
    t.string   "code",         :null => false
    t.integer  "type_id",      :null => false
    t.string   "invited_type"
    t.integer  "invited_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "admin_id"
    t.string   "first_name"
    t.string   "last_name"
  end

  add_index "invitations", ["admin_id"], :name => "index_invitations_on_admin_id"
  add_index "invitations", ["invited_id", "invited_type"], :name => "index_invitations_on_invited_id_and_invited_type"
  add_index "invitations", ["type_id"], :name => "index_invitations_on_type_id"

  create_table "jobs", :force => true do |t|
    t.string   "title",                                         :null => false
    t.integer  "employer_id",                                   :null => false
    t.integer  "type_id",                                       :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.text     "description"
    t.integer  "weekend_id"
    t.text     "filters_hash"
    t.string   "employer_name"
    t.integer  "employer_city_id"
    t.string   "employer_logo_file_name"
    t.string   "employer_logo_content_type"
    t.integer  "employer_logo_file_size"
    t.datetime "employer_logo_updated_at"
    t.string   "employer_website"
    t.string   "application_url"
    t.boolean  "offline",                    :default => false, :null => false
  end

  create_table "jobs_sections", :id => false, :force => true do |t|
    t.integer "job_id"
    t.integer "section_id"
  end

  create_table "jobs_types", :force => true do |t|
    t.string  "name",                      :null => false
    t.integer "identifier", :default => 0, :null => false
  end

  create_table "languages", :force => true do |t|
    t.string "name", :null => false
  end

  create_table "rates", :force => true do |t|
    t.integer "score"
  end

  create_table "ratings", :force => true do |t|
    t.integer  "user_id"
    t.integer  "rate_id"
    t.integer  "rateable_id"
    t.string   "rateable_type", :limit => 32
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "ratings", ["rate_id"], :name => "index_ratings_on_rate_id"
  add_index "ratings", ["rateable_id", "rateable_type"], :name => "index_ratings_on_rateable_id_and_rateable_type"

  create_table "sections", :force => true do |t|
    t.string "name", :null => false
  end

  create_table "text_messages", :force => true do |t|
    t.text     "to",         :null => false
    t.string   "body"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "vacancies", :force => true do |t|
    t.integer  "job_id",                            :null => false
    t.integer  "city_id",                           :null => false
    t.boolean  "removed",        :default => false
    t.text     "removal_reason"
    t.boolean  "hot",            :default => false
    t.integer  "reports",        :default => 0
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "views",          :default => 0,     :null => false
  end

  add_index "vacancies", ["city_id"], :name => "index_jobs_cities_on_city_id"
  add_index "vacancies", ["job_id"], :name => "index_jobs_cities_on_job_id"

end
