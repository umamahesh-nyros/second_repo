class RenameVacanciesCandidatesToApplications < ActiveRecord::Migration
  def self.up
    rename_table :vacancies_candidates, :applications
  end

  def self.down
    rename_table :applications, :vacancies_candidates
  end
end
