class AddMoreInfoToEmployers < ActiveRecord::Migration
  def self.up
    add_column :employers, :more_info, :text
  end

  def self.down
    remove_column :employers, :more_info
  end
end
