class ChangeInterviewsSlotsTimeToDatetime < ActiveRecord::Migration
  def self.up
    remove_column :interviews_slots, :time
    add_column :interviews_slots, :time, :datetime
    
  end

  def self.down
    remove_column :interviews_slots, :time
    add_column :interviews_slots, :time, :time
  end
end
