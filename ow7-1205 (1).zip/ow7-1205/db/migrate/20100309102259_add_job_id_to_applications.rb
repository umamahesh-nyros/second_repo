class AddJobIdToApplications < ActiveRecord::Migration
  def self.up
    add_column :applications, :job_id, :integer, :null => false
  end

  def self.down
    remove_column :applications, :job_id
  end
end
