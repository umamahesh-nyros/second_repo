class AddPaidToEmployers < ActiveRecord::Migration
  def self.up
    add_column :employers, :paid, :boolean, :null => false, :default => false
    add_column :employers, :paid_expiry_date, :date
  end
  
  def self.down
    remove_column :employers, :paid
    remove_column :employers, :paid_expiry_date
  end
end
