class RemoveReturnDateFromCandidates < ActiveRecord::Migration
  def self.up
    remove_column :candidates, :return_date
  end

  def self.down
    add_column :candidates, :return_date, :date
  end
end
