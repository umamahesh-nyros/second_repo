class CreateInterviewsSlots < ActiveRecord::Migration
  def self.up
    create_table :interviews_slots do |t|
      t.integer :interview_id
      t.time :time, :null => false
      t.integer :status_id, :null => false, :default => 0
    end
    
    add_index :interviews_slots, :interview_id
  end

  def self.down
    drop_table :interviews_slots
  end
end
