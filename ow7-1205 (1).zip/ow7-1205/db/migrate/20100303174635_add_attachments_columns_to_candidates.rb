class AddAttachmentsColumnsToCandidates < ActiveRecord::Migration
  def self.up
    [:avatar].each do |i|
      add_column :candidates, "#{i}_file_name", :string
      add_column :candidates, "#{i}_content_type", :string
      add_column :candidates, "#{i}_file_size", :integer
      add_column :candidates, "#{i}_updated_at", :datetime
    end
  end
  
  def self.down
    [:avatar].each do |i|
      remove_column :candidates, "#{i}_file_name"
      remove_column :candidates, "#{i}_content_type"
      remove_column :candidates, "#{i}_file_size"
      remove_column :candidates, "#{i}_updated_at"
    end    
  end
end
