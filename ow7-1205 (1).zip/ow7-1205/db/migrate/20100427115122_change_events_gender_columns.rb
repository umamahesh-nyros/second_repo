class ChangeEventsGenderColumns < ActiveRecord::Migration
  def self.up
    remove_column :events, :employer_gender_id
    remove_column :events, :candidate_gender_id
    add_column :events, :employer_gender, :integer, :null => false, :default => Event::Gender[:male].id | Event::Gender[:female].id
    add_column :events, :candidate_gender, :integer, :null => false, :default => Event::Gender[:male].id | Event::Gender[:female].id
  end

  def self.down
    remove_column :events, :employer_gender
    remove_column :events, :candidate_gender
    add_column :events, :employer_gender_id, :integer
    add_column :events, :candidate_gender_id, :integer
  end
end
