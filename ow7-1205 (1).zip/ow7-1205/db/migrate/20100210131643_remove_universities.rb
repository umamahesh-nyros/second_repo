class RemoveUniversities < ActiveRecord::Migration
  def self.up
    drop_table :universities
  end
  
  def self.down
    create_table :universities do |t|
      t.string :name, :null => false
      t.integer :country_id, :null => false
      t.boolean :ivy_league
      t.boolean :top_400
      t.boolean :english
    end
    add_index :universities, :country_id
  end
end
