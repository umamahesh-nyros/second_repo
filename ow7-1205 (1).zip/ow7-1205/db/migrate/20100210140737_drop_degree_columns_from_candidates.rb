class DropDegreeColumnsFromCandidates < ActiveRecord::Migration
  def self.up
    [
      :degree_date,
      :degree_university_id,
      :degree_level_id,
      :degree_specialty_id,
      :degree_gpa,
      :degree_method_of_study_id
    ].each {|c| remove_column :candidates, c}    
  end
  
  def self.down
    add_column :candidates, :degree_date, :date
    add_column :candidates, :degree_university_id, :integer
    add_column :candidates, :degree_level_id, :integer
    add_column :candidates, :degree_specialty_id, :integer
    add_column :candidates, :degree_gpa, :float
    add_column :candidates, :degree_method_of_study_id, :integer    
  end
end
