class CreateCandidatesCountries < ActiveRecord::Migration
  def self.up
    create_table :candidates_countries do |t|
      t.integer :candidate_id, :null => false
      t.integer :country_id, :null => false
    end
    
    add_index :candidates_countries, :candidate_id
    add_index :candidates_countries, :country_id
  end

  def self.down
    drop_table :candidates_countries
  end
end
