class AddImageToJobsTypes < ActiveRecord::Migration
  def self.up
    add_column :jobs_types, :image, :string
  end

  def self.down
    remove_column :jobs_types, :image
  end
end
