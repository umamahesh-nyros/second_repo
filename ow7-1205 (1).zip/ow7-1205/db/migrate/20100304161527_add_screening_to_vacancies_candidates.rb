class AddScreeningToVacanciesCandidates < ActiveRecord::Migration
  def self.up
    add_column :vacancies_candidates, :screening, :boolean
  end

  def self.down
    remove_column :vacancies_candidates, :screening
  end
end
