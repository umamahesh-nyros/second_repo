class ChangeCandidatesLoginInfoToAuthlogicDefaults < ActiveRecord::Migration
  def self.up
    remove_column :candidates, :last_login_time
    add_column :candidates, :current_login_at, :datetime
    add_column :candidates, :last_login_at, :datetime
    
    t = Time.now.utc
    Candidate.update_all(Candidate.send(:sanitize_sql_for_assignment, {:current_login_at => t, :last_login_at => t}),
                         {:current_login_at => nil})
  end

  def self.down
    add_column :candidates, :last_login_time, :datetime
    remove_column :candidates, :current_login_at
    remove_column :candidates, :last_login_at
  end
end
