class AddColumnsToJobs < ActiveRecord::Migration
  def self.up
    add_column :jobs, :description, :text
    add_column :jobs, :weekend, :integer
    add_column :jobs, :filters_hash, :text
  end

  def self.down
    remove_column :jobs, :description
    remove_column :jobs, :weekend
    remove_column :jobs, :filters_hash
  end
end
