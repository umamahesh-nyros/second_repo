class AddDialingCodesToCountries < ActiveRecord::Migration
  def self.up
    1.upto(3) do |i|
      add_column :countries, "dialing_code_#{i}", :integer
    end
  end

  def self.down
    1.upto(3) do |i|
      remove_column :countries, "dialing_code_#{i}"
    end
  end
end
