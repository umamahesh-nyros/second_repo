class AddOfflineToJobs < ActiveRecord::Migration
  def self.up
    add_column :jobs, :offline, :boolean
    Job.update_all "offline = false"
    change_column :jobs, :offline, :boolean, :null => false, :default => false
  end

  def self.down
    remove_column :jobs, :offline
  end
end
