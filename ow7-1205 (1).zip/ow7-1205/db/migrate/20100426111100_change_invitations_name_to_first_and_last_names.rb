class ChangeInvitationsNameToFirstAndLastNames < ActiveRecord::Migration
  def self.up
    add_column :invitations, :first_name, :string
    add_column :invitations, :last_name, :string
    remove_column :invitations, :name
  end

  def self.down
    add_column :invitations, :name, :string
    remove_column :invitations, :first_name
    remove_column :invitations, :last_name
  end
end
