class AddStatusIdToComments < ActiveRecord::Migration
  def self.up
    add_column :comments, :status_id, :integer, :null => false, :default => Comment::Status[:visible].id
    add_index :comments, :status_id
  end

  def self.down
    remove_column :comments, :status_id
  end
end
