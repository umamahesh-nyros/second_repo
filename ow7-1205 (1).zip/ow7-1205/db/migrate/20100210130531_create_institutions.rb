class CreateInstitutions < ActiveRecord::Migration
  def self.up
    create_table :institutions do |t|
      t.string :name, :null => false
      t.integer :type_id, :null => false, :default => 0 
      t.integer :country_id, :null => false
      t.boolean :ivy_league
      t.boolean :top_400
      t.boolean :english
    end
    add_index :institutions, :country_id
    add_index :institutions, :type_id
  end
  
  def self.down
    drop_table :institutions
  end
end
