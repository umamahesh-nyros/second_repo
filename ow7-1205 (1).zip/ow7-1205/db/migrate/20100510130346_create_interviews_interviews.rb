class CreateInterviewsInterviews < ActiveRecord::Migration
  def self.up
    create_table :interviews do |t|
      t.integer :employer_id, :null => false
      t.integer :vacancy_id, :null => false
      t.string :duration
      t.integer :city_id
      t.text :location
      t.date :confirmation_deadline
      t.string :contact_person
      t.integer :contact_phone
      t.string :contact_email
    end
  end

  def self.down
    drop_table :interviews
  end
end
