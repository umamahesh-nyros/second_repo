class ModifyInstitutionsLanguageColumns < ActiveRecord::Migration
  def self.up
    remove_column :institutions, :english
    remove_column :institutions, :arabic
    add_column :institutions, :language_id, :integer
  end

  def self.down
    add_column :institutions, :english, :boolean
    add_column :institutions, :arabic, :boolean
    remove_column :institutions, :language_id
  end
end
