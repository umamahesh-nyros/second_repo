class ChangeJobTypeCases < ActiveRecord::Migration
  def self.up
    execute("update jobs_types set name = 'Full-Time Job' where name = 'Full-time job'")
    execute("update jobs_types set name = 'Summer / Part-Time Job' where name = 'Summer/part-time job'")

  end

  def self.down
    execute("update jobs_types set name = 'Full-time job' where name = 'Full-Time Job'")
    execute("update jobs_types set name = 'Summer/part-time job' where name = 'Summer / Part-Time Job'")
  end
end
