class AddDegreeLanguageIdToCountries < ActiveRecord::Migration
  def self.up
    add_column :countries, :degree_language_id, :integer
  end

  def self.down
    remove_column :countries, :degree_language_id
  end
end
