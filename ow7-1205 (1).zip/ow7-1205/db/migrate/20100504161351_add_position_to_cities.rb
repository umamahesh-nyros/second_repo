class AddPositionToCities < ActiveRecord::Migration
  def self.up
    add_column :cities, :position, :integer
  end

  def self.down
    remove_column :cities, :position
  end
end
