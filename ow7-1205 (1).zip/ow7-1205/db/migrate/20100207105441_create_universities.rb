class CreateUniversities < ActiveRecord::Migration
  def self.up
    create_table :universities do |t|
      t.string :name, :null => false
      t.integer :country_id, :null => false
      t.boolean :ivy_league
      t.boolean :top_400
      t.boolean :english
    end
    add_index :universities, :country_id
  end

  def self.down
    drop_table :universities
  end
end
