class AddCompanyFieldsToJobs < ActiveRecord::Migration
  def self.up
    add_column :jobs, :employer_name, :string
    add_column :jobs, :employer_city_id, :integer
    add_column :jobs, :employer_logo_file_name, :string
    add_column :jobs, :employer_logo_content_type, :string
    add_column :jobs, :employer_logo_file_size, :integer
    add_column :jobs, :employer_logo_updated_at, :datetime
    add_column :jobs, :employer_website, :string
  end
  
  def self.down
    [:employer_name, :employer_city_id,
     :employer_logo_file_name,
     :employer_logo_content_type,
     :employer_logo_file_size,
     :employer_logo_updated_at,
     :employer_website].each do |attr|
      remove_column :jobs, attr
    end
  end
end
