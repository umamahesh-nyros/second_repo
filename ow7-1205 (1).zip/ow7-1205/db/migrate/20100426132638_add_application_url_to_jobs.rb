class AddApplicationUrlToJobs < ActiveRecord::Migration
  def self.up
    add_column :jobs, :application_url, :string
  end

  def self.down
    remove_column :jobs, :application_url
  end
end
