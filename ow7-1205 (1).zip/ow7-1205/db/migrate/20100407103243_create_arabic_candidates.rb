class CreateArabicCandidates < ActiveRecord::Migration
  def self.up
    create_table :arabic_candidates do |t|
      t.string :name
      t.string :email
      t.string :cv_file_name
      t.string :cv_content_type
      t.integer :cv_file_size
      t.datetime :cv_updated_at
      t.timestamps
    end
  end
  
  def self.down
    drop_table :arabic_candidates
  end
end
