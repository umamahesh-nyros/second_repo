class ModifyJobsTypesColumns < ActiveRecord::Migration
  def self.up
    add_column :jobs_types, :identifier, :integer, :null => false, :default => 0
    remove_column :jobs_types, :image
  end
  
  def self.down
    add_column :jobs_types, :image, :string
    remove_column :jobs_types, :identifier
  end
end
