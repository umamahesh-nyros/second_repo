class AddTimeToInterviewsConnection < ActiveRecord::Migration
  def self.up
    add_column :interviews_connections, :time, :datetime
  end

  def self.down
    remove_column :interviews_connections, :time
  end
end
