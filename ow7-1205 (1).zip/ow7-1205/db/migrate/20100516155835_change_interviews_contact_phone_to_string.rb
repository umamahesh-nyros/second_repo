class ChangeInterviewsContactPhoneToString < ActiveRecord::Migration
  def self.up
    change_column :interviews, :contact_phone, :string
  end

  def self.down
    change_column :interviews, :contact_phone, :integer
  end
end
