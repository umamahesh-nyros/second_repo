class AddCandidateSection < ActiveRecord::Migration
  def self.up
    create_table :candidates_sections, :id=>false, :force=>true do |t|
      t.integer :candidate_id
      t.integer :section_id
    end

  end

  def self.down
    drop_table :candidates_sections
  end
end
