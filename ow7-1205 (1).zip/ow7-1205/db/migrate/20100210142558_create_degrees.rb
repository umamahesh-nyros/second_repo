class CreateDegrees < ActiveRecord::Migration
  def self.up
    create_table :degrees do |t|
      t.integer :candidate_id, :null => false
      t.date :date
      t.integer :level_id, :null => false
      t.integer :category_id
      t.integer :sub_category_id
      t.string :title
      t.integer :institution_id
      t.integer :method_of_study_id      
      t.float :gpa
    end
    add_index :degrees, :candidate_id
    add_index :degrees, :sub_category_id
    add_index :degrees, :institution_id
    add_index :degrees, :level_id
  end

  def self.down
    drop_table :degrees
  end
end
