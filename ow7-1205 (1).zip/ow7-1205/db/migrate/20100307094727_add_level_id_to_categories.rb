class AddLevelIdToCategories < ActiveRecord::Migration
  def self.up
    add_column :categories, :level_id, :integer, :null => false, :default => Category::Levels[:a] 
    add_index :categories, :level_id
  end

  def self.down
    remove_column :categories, :level_id
  end
end
