class RenameWeekendToWeekendId < ActiveRecord::Migration
  def self.up
    rename_column :jobs, :weekend, :weekend_id
  end

  def self.down
    rename_column :jobs, :weekend_id, :weekend
  end
end
