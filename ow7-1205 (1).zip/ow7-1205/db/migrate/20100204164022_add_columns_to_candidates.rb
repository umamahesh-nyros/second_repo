class AddColumnsToCandidates < ActiveRecord::Migration
  def self.up
    add_column :candidates, :first_name, :string, :null => false
    add_column :candidates, :last_name, :string, :null => false
    add_column :candidates, :degree_date, :date
    add_column :candidates, :degree_university_id, :integer
    add_column :candidates, :degree_level_id, :integer
    add_column :candidates, :degree_specialty_id, :integer
    add_column :candidates, :degree_gpa, :float
    add_column :candidates, :degree_method_of_study_id, :integer
    add_column :candidates, :cv_file_name, :string
    add_column :candidates, :cv_content_type, :string
    add_column :candidates, :cv_file_size, :integer
    add_column :candidates, :cv_updated_at, :datetime
    add_column :candidates, :gender_id, :integer, :null => false
    add_column :candidates, :date_of_birth, :date
    add_column :candidates, :marital_status_id, :integer, :null => false
    add_column :candidates, :iqama_id, :integer
    add_column :candidates, :saudi_mother, :boolean
    add_column :candidates, :saudi_spouse, :boolean
    add_column :candidates, :job_mixing_id, :integer
    add_column :candidates, :job_start_date, :date
    add_column :candidates, :residence_city_id, :integer
    add_column :candidates, :residence_phone, :string
    add_column :candidates, :saudi_city_id, :integer
    add_column :candidates, :saudi_phone, :string
    add_column :candidates, :return_date, :date
    add_column :candidates, :entry_level, :boolean
  end

  def self.down
    [
      :first_name,
      :last_name,
      :degree_date,
      :degree_university_id,
      :degree_level_id,
      :degree_specialty_id,
      :degree_gpa,
      :degree_method_of_study_id,
      :cv_file_name,
      :cv_content_type,
      :cv_file_size,
      :cv_updated_at,
      :gender_id,
      :date_of_birth,
      :marital_status_id,
      :iqama_id,
      :saudi_mother,
      :saudi_spouse,
      :job_mixing_id,
      :job_start_date,
      :residence_city_id,
      :residence_phone,
      :saudi_city_id,
      :saudi_phone,
      :return_date,
      :entry_level
    ].each {|c| remove_column :candidates, c}
  end
end
