class AddNewMajorForEngineering < ActiveRecord::Migration
  def self.up

    if (Category.find_by_sql("select * from categories where name = 'Control & Intrumentation Systems'").count == 0)
      id = 0
      Category.find_by_sql("select id from categories where name = 'Engineering'").each do |t|
        id = t.id
      end
      c = Category.new(:name => 'Control & Intrumentation Systems', :parent_id => id, :level_id => 0)
      c.save!
    end
  end

  def self.down

  end
end
