class ChangeDurationInInterviews < ActiveRecord::Migration
  def self.up
    remove_column :interviews, :duration
    add_column :interviews, :duration, :integer, :null => false
  end

  def self.down
    remove_column :interviews, :duration
    add_column :interviews, :duration, :string, :null => true
  end
end
