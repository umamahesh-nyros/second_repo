class AddNgoToEmployers < ActiveRecord::Migration
  def self.up
    add_column :employers, :ngo, :boolean, :null => false, :default => false
  end

  def self.down
    remove_column :employers, :ngo
  end
end
