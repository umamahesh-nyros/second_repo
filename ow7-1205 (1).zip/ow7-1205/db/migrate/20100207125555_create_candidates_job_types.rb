class CreateCandidatesJobTypes < ActiveRecord::Migration
  def self.up
    create_table :candidates_job_types do |t|
      t.integer :candidate_id, :null => false
      t.integer :job_type_id, :null => false
    end
    add_index :candidates_job_types, :candidate_id
    add_index :candidates_job_types, :job_type_id
  end

  def self.down
    drop_table :candidates_job_types
  end
end
