class AddColumnsToInstitutions < ActiveRecord::Migration
  def self.up
    add_column :institutions, :ivy_league, :boolean, :null => false, :default => false
    add_column :institutions, :arabic, :boolean, :null => false, :default => false
    add_column :institutions, :global_rank, :integer
  end

  def self.down
    remove_column :institutions, :ivy_league
    remove_column :institutions, :arabic
    remove_column :institutions, :global_rank
  end
end
