class AddMoreEmployerAttributes < ActiveRecord::Migration
  def self.up
    add_column :employers, :name, :string, :null => false
    add_column :employers, :website, :string, :null => false
    add_column :employers, :logo_file_name, :string
    add_column :employers, :logo_content_type, :string
    add_column :employers, :logo_file_size, :integer
    add_column :employers, :logo_updated_at, :datetime
    add_column :employers, :city_id, :integer, :null => false
    add_column :employers, :person_name, :string, :null => false
    add_column :employers, :phone, :string, :null => false
    add_column :employers, :contacts_hidden, :boolean, :null => false, :default => false
    
    add_index :employers, :city_id
  end
  
  def self.down
    remove_index :employers, :city_id
    [:name, :website, :city_id, :person_name,
     :logo_file_name, :logo_content_type,
     :logo_file_size, :logo_updated_at,
     :phone, :contacts_hidden
    ].each {|c| remove_column :emplyers, c}
  end
end
