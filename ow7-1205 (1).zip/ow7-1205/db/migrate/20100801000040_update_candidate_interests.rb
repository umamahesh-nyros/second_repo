class UpdateCandidateInterests < ActiveRecord::Migration
  def self.up
    # by default set candidate job type interests to all
    Candidate.find_by_sql("select id from candidates order by id").each do |c|
      Section.find_by_sql("select id from sections order by id").each do |s|
        execute("insert into candidates_sections values(#{c.id},#{s.id})")
      end
    end
    # set interests on entry level job by default
    # for those candidates who don't have this value in db
    execute("update candidates set entry_level = true where entry_level is null")
  end

  def self.down

  end
end
