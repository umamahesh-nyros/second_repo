class CreateInvitations < ActiveRecord::Migration
  def self.up
    create_table :invitations do |t|
      t.string :email, :null => false
      t.string :code, :null => false
      t.integer :type_id, :null => false
      t.string :invited_type
      t.integer :invited_id
      t.timestamps
    end
    
    add_index :invitations, :type_id
    add_index :invitations, [:invited_id, :invited_type] 
  end

  def self.down
    drop_table :invitations
  end
end
