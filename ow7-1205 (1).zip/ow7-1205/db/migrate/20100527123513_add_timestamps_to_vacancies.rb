class AddTimestampsToVacancies < ActiveRecord::Migration
  def self.up
    add_timestamps :vacancies
  end

  def self.down
    remove_timestamps :vacancies
  end
end
