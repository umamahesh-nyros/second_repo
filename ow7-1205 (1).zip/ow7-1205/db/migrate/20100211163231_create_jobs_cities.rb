class CreateJobsCities < ActiveRecord::Migration
  def self.up
    create_table :jobs_cities do |t|
      t.integer :job_id, :null => false
      t.integer :city_id, :null => false
    end
    add_index :jobs_cities, :job_id
    add_index :jobs_cities, :city_id
  end

  def self.down
    drop_table :jobs_cities
  end
end
