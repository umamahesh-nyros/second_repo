class CreateInterviewsConnections < ActiveRecord::Migration
  def self.up
    create_table :interviews_connections do |t|
      t.integer :interview_id, :null => false
      t.integer :candidate_id, :null => false
      t.integer :status_id, :null => false, :default => 0
      t.integer :slot_id
    end
    
    add_index :interviews_connections, [:interview_id, :status_id]
    add_index :interviews_connections, [:candidate_id, :status_id]
    add_index :interviews_connections, [:slot_id, :status_id]
  end

  def self.down
    drop_table :interviews_connections
  end
end
