class AddLanguageIdToCandidates < ActiveRecord::Migration
  def self.up
    add_column :candidates, :language_id, :integer, :null => false, :default => Candidate::Languages[:en]
  end

  def self.down
    remove_column :candidates, :language_id
  end
end
