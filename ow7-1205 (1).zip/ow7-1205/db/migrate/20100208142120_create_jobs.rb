class CreateJobs < ActiveRecord::Migration
  def self.up
    create_table :jobs do |t|
      t.string :title, :null => false
      t.integer :employer_id, :null => false
      t.integer :type_id, :null => false
      t.timestamps
    end
  end

  def self.down
    drop_table :jobs
  end
end
