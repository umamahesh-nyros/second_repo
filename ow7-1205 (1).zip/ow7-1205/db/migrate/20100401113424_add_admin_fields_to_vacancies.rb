class AddAdminFieldsToVacancies < ActiveRecord::Migration
  def self.up
    add_column :vacancies, :removed, :boolean, :default => false
    add_column :vacancies, :removal_reason, :text
    add_column :vacancies, :hot, :boolean, :default => false
  end

  def self.down
    remove_column :vacancies, :removed
    remove_column :vacancies, :removal_reason
    remove_column :vacancies, :hot
  end
end
