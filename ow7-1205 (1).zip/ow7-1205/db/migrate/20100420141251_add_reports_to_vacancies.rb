class AddReportsToVacancies < ActiveRecord::Migration
  def self.up
    add_column :vacancies, :reports, :integer, :default => 0
  end

  def self.down
    remove_column :vacancies, :reports
  end
end
