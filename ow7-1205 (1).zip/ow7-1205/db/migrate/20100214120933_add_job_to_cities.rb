class AddJobToCities < ActiveRecord::Migration
  def self.up
    add_column :cities, :job, :boolean, :null => false, :default => false
    add_index :cities, :job
  end

  def self.down
    remove_column :cities, :job
  end
end
