class AddResidenceCountryIdToCandidates < ActiveRecord::Migration
  def self.up
    add_column :candidates, :residence_country_id, :integer
  end

  def self.down
    remove_column :candidates, :residence_country_id
  end
end
