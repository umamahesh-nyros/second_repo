class RenameSpecialtiesToCategories < ActiveRecord::Migration
  def self.up
    rename_table :specialties, :categories
  end

  def self.down
    rename_table :categories, :specialties
  end
end
