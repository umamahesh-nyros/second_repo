class UpdateInstitutionsToHaveRankings < ActiveRecord::Migration
  def self.up
    add_column :institutions, :ranking_id, :integer, :null => false, :default => Institution::Rankings[:other].id
    add_index :institutions, :ranking_id
    
    remove_column :institutions, :ivy_league
    remove_column :institutions, :top_400
  end
  
  def self.down
    add_column :institutions, :ivy_league, :boolean
    add_column :institutions, :top_400, :boolean
    
    remove_column :institutions, :ranking_id
  end
end
