class AddLastUpdatedToCandidates < ActiveRecord::Migration
  def self.up
    add_column :candidates, :last_updated, :datetime
    Candidate.update_all "last_updated = updated_at"
    change_column :candidates, :last_updated, :datetime, :null => false
  end

  def self.down
    remove_column :candidates, :last_updated
  end
end
