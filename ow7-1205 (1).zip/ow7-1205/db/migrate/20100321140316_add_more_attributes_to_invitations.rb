class AddMoreAttributesToInvitations < ActiveRecord::Migration
  def self.up
    add_column :invitations, :name, :string
    add_column :invitations, :admin_id, :integer
    
    add_index :invitations, :admin_id
  end

  def self.down
    remove_column :invitations, :name
    remove_column :invitations, :admin_id
  end
end
