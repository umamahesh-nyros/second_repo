class RemoveEmailActivatedFromCandidates < ActiveRecord::Migration
  def self.up
    remove_column :candidates, :email_activated
  end
  
  def self.down
    add_column :candidates, :candidates, :boolean, :null => false, :default => false
  end
end
