class CreateCandidates < ActiveRecord::Migration
  def self.up
    create_table :candidates do |t|
      t.string :email
      t.string :crypted_password
      t.string :password_salt
      t.string :persistence_token
      t.string :single_access_token, :null => false
      t.string :perishable_token
      t.boolean :email_activated, :null => false, :default => false

      t.timestamps
    end
  end

  def self.down
    drop_table :candidates
  end
end
