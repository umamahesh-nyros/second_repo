class AddStatusIdToEmployers < ActiveRecord::Migration
  def self.up
    add_column :employers, :status_id, :integer, :null => false, :default => Employer::Status[:active].id
    add_column :employers, :block_reason, :string
  end
  
  def self.down
    remove_column :employers, :status_id
    remove_column :employers, :block_reason
  end
end
