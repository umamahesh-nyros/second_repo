class AddVacanciesCandidatesTable < ActiveRecord::Migration
  def self.up
    create_table :vacancies_candidates do |t|
      t.integer :candidate_id, :null => false
      t.integer :vacancy_id, :null => false
    end
    add_index :vacancies_candidates, :candidate_id
    add_index :vacancies_candidates, :vacancy_id
  end

  def self.down
    drop_table :vacancies_candidates
  end
end
