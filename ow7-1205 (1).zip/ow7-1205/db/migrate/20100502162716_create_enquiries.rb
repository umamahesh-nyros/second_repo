class CreateEnquiries < ActiveRecord::Migration
  def self.up
    create_table :enquiries do |t|
      t.string      :name, :null => false
      t.string      :email, :null => false
      t.integer     :type_id, :null => false
      t.string      :subject
      t.text        :message
      t.timestamps
    end
  end

  def self.down
    drop_table :enquiries
  end
end
