class CreateEvents < ActiveRecord::Migration
  def self.up
    create_table :events do |t|
      t.string :creator_type, :limit => 15, :null => false
      t.integer :creator_id, :null => false
      
      t.string :title, :null => false
      t.text :description, :null => false
      t.text :more_info
      
      t.string :location
      t.string :street
      t.integer :city_id
      
      t.integer :type_id, :null => false
      t.integer :employer_gender_id
      t.integer :candidate_gender_id
      
      t.integer :status_id, :null => false
      
      t.string :image_file_name
      t.string :image_content_type
      t.integer :image_file_size
      t.datetime :image_updated_at
      
      t.datetime :start_time, :null => false
      t.datetime :end_time, :null => false
      
      t.datetime :created_at
      t.datetime :published_at
    end
  end
  
  def self.down
    drop_table :events
  end
end
