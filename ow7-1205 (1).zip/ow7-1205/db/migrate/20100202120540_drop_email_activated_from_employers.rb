class DropEmailActivatedFromEmployers < ActiveRecord::Migration
  def self.up
    remove_column :employers, :email_activated
  end
  
  def self.down
    add_column :employers,:email_activated, :boolean, :null => false, :default => false
  end
end
