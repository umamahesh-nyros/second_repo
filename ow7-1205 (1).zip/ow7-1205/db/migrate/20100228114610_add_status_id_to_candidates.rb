class AddStatusIdToCandidates < ActiveRecord::Migration
  def self.up
    add_column :candidates, :status_id, :integer, :null => false
  end

  def self.down
    remove_column :candidates, :status_id
  end
end
