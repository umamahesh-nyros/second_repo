class AddEmployerFiltersToApplications < ActiveRecord::Migration
  def self.up
    add_column :applications, :short_listed, :boolean, :default => false
    add_column :applications, :rejected, :boolean, :default => false
  end

  def self.down
    remove_column :applications, :short_listed
    remove_column :applications, :rejected
  end
end
