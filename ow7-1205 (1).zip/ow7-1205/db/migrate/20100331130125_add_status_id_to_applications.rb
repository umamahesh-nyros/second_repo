class AddStatusIdToApplications < ActiveRecord::Migration
  def self.up
    add_column :applications, :status_id, :integer, :null => false, :default => Vacancies::Application::Status[:visible].id
    add_index :applications, :status_id
  end

  def self.down
    remove_column :applications, :status_id
  end
end
