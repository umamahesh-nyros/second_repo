class AddJobSections < ActiveRecord::Migration
  def self.up
    create_table :sections, :force=>true do |t|
      t.string :name, :null => false
    end

    create_table :jobs_sections, :id=>false, :force=>true do |t|
      t.integer :job_id
      t.integer :section_id
    end

    if Section.count == 0
      print 'Job Sections...'
      [{:name => "Accounting"},
       {:name => "Administrative / Secretarial"},
       {:name => "Banking"},
       {:name => "Engineering"},
       {:name => "Finance"},
       {:name => "Graduate Program"},
       {:name => "Human Resources"},
       {:name => "Information Technology"},
       {:name => "Marketing"},
       {:name => "Sales / Customer Service"},
       {:name => "Supply Chain"}
      ].each do |sec_data|
        l = Section.find_or_create_by_name sec_data[:name]
        l.save!
      end
      puts 'Done'
    end
  end

  def self.down
    drop_table :sections
    drop_table :jobs_sections
  end
end
