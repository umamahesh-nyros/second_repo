class RenameJobsCitiesToVacancies < ActiveRecord::Migration
  def self.up
    rename_table :jobs_cities, :vacancies
  end

  def self.down
    rename_table :vacancies, :jobs_cities
  end
end
