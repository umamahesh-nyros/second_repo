class CreateArticles < ActiveRecord::Migration
  def self.up
    create_table :articles do |t|
      t.string :creator_type, :limit => 15, :null => false
      t.integer :creator_id, :null => false
      t.string :title, :null => false
      t.text :body, :null => false
      t.integer :status_id, :null => false
      t.string :image_file_name
      t.string :image_content_type
      t.integer :image_file_size
      t.datetime :image_updated_at
      t.datetime :created_at
      t.datetime :published_at
    end
    
    add_index :articles, [:creator_type, :creator_id, :status_id]
    add_index :articles, [:status_id, :published_at] 
  end
  
  def self.down
    drop_table :articles
  end
end
