class SMSSender
  class << self
    attr_accessor_with_default :sms_requests, []
    attr_accessor_with_default :attempts, 3
  end
  
  def self.send_message(mobile_number, message)
    mobile_number = mobile_number.gsub(/^(00|\+)/, '')
    begin
      if AppConfig.sms_test_mode
        self.sms_requests << [mobile_number, message]
        log_sent(mobile_number, message)
        true
      else
        @service||= Net::SMS::BulkSMS::Service.new(AppConfig.sms_username, AppConfig.sms_password, Net::SMS::BulkSMS::INTER)
        response = nil
        attempts.times do
          begin
            response = @service.send_message(Net::SMS::BulkSMS::Message.new(message, mobile_number))
            break if response.successful?
          rescue Exception => e
            log_exception(e)
          end
        end
        if response
          response.successful? ? log_sent(mobile_number, message) : log_not_sent(mobile_number, message, response)
          response.successful?
        else
          false
        end
      end
    rescue Exception => e
      log_exception(e)
      false
    end
  end
  
  def self.log_sent(mobile_number, message)
    Rails.logger.info ">>>>>>>>>>>>SMS sent to #{mobile_number}"
  end
  
  def self.log_not_sent(mobile_number, message, response)
    Rails.logger.info ">>>>>>>>>>>>SMS not sent to #{mobile_number} (Code: #{response.code} - Description: #{response.description})"
  end
  
  def self.log_exception(e)
    Rails.logger.info ">>>>>>>>>>>>SMS exception #{e.inspect}"
    Rails.logger.info e.backtrace
  end
end