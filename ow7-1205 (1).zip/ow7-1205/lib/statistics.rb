module Statistics
  Countries = ["SA", "US", "CA", "GB", "AU", "AE", "EG", "JO", "MY"]
  SaudiStatusKeys = [:saudi, :half_saudi, :non_saudi_in_ksa, :non_saudi]
  GenderKeys = [:male, :female]

  def self.recently_added
    db_recently_added
  end

  def self.candidate_availability
    solr_candidate_availability
  end
  
  def self.candidate_country_of_residence
    solr_candidate_country(:residence_country_id)
  end

  def self.candidate_country_of_education
    solr_candidate_country(:countries_of_education_ids)
  end
  
  def self.candidate_saudi_gender_country_of_education
    solr_candidate_saudi_gender_country(:countries_of_education_ids)
  end
  
  def self.candidate_city_of_residence
    db_candidate_city_of_residence
  end

  def self.candidate_saudi_city_of_residence
    db_candidate_city_of_residence(true)
  end
  
  def self.candidate_most_popular_cities
    db_candidate_most_popular_cities
  end
  
  def self.job_city_by_month
    db_job_city_by_month
  end
  
  
  # implementations
  
  def self.db_job_city_by_month
    result = ActiveSupport::OrderedHash.new
    cities = ActiveSupport::OrderedHash.new
    
    City.job.ascend_by_position.each {|c| cities[c.name] = c.id }
    
    year = Date.today.beginning_of_year
    
    months = []
    
    12.times do|i|
      m = year + i.months
      months << {:name => m.strftime("%B"),:range => m.midnight..(m + 1.months).midnight}
    end
    
    months.each do |month|
      result[month[:name]] ||= []
      cities.values.each do |city_id|
        result[month[:name]] << Vacancy.count(:conditions => {:created_at => month[:range], :city_id => city_id})
      end
    end

    {:rows => result, :headers => cities.keys}
  
  end
  
  def self.db_candidate_most_popular_cities
     rows = Candidates::JobCity.all(:select => 'count(*) as count, cities.name', :joins => :city, :group => "city_id, cities.name", :order => 'count desc', :limit => 5)
     { :rows => rows, :headers => ['City', 'Count'] }
  end
  
  def self.db_candidate_city_of_residence(saudi = false)
    params = {
        :select => 'count(*) as count, cities.name',
        :group => "residence_city_id, cities.name",
        :joins => :residence_city,
        :order => 'count desc',
        :limit => 10    
    }.merge(saudi ? {:conditions => {:residence_country_id => Country.saudi_arabia.id}} : {})
    
    { :rows => Candidate.all(params), :headers => ['City', 'Count'] }
  end
  
  def self.solr_candidate_saudi_gender_country(field)
    result = ActiveSupport::OrderedHash.new
    ids = []
    countries = Countries.collect {|iso| c = Country.find_by_iso(iso); ids << c.id ;{c.printable_name => c.id}}
    countries << {"Others" => ids}
    
    countries.each do |hash|
        name = hash.keys.first
        id = hash.values.first
        
        result[name] = []
        Candidate::Gender.values_at(*GenderKeys).each do |gender_id|
          saudi_status_id = Candidate::SaudiStatus[:saudi]
          
          result[name] << Candidate.solr_search_ids do
            all_of do
              with(:saudi_status_id, saudi_status_id)
              name == "Others" ? without(field, id) : with(field, id)
              with(:gender_id, gender_id)
            end
            paginate :per_page => Candidate.count
          end.length
          
        end
        
        result[name] << result[name].sum  
    end    

    total = []
    result.values.each do |counts|
      counts.each_with_index {|c, i| total[i] ||= 0; total[i] += c }
    end
    
    result[:total] = total
    

    {:rows => result, :headers => GenderKeys + [:total]}
  end

  def self.solr_candidate_country(field)
    result = ActiveSupport::OrderedHash.new
    ids = []
    countries = Countries.collect {|iso| c = Country.find_by_iso(iso); ids << c.id ;{c.printable_name => c.id}}
    countries << {"Others" => ids}
    
    countries.each do |hash|
        name = hash.keys.first
        id = hash.values.first
        
        result[name] = []
        Candidate::SaudiStatus.values_at(*SaudiStatusKeys).each do |saudi_status_id|
          result[name] << Candidate.solr_search_ids do
            all_of do
              with(:saudi_status_id, saudi_status_id)
              name == "Others" ? without(field, id) : with(field, id)
            end
            paginate :per_page => Candidate.count
          end.length
          
        end
        
        result[name] << result[name].sum  
    end    

    total = []
    result.values.each do |counts|
      counts.each_with_index {|c, i| total[i] ||= 0; total[i] += c }
    end
    
    result[:total] = total
    

    {:rows => result, :headers => SaudiStatusKeys + [:total]}
  end

  def self.solr_candidate_availability
    result = ActiveSupport::OrderedHash.new
    availabilities = [
      {:full_time_graduate => Jobs::Type.array_of(:full_time, :graduate_program).collect(&:id)},
      {:internship => Jobs::Type.array_of(:internship).collect(&:id)},
      {:summer_part_time => Jobs::Type.array_of(:summer_job).collect(&:id)},
    ]
    
    saudi_status_keys = [:saudi, :half_saudi, :non_saudi_in_ksa, :non_saudi]
    
    availabilities.each do |availability|
      availability.each do |name, ids|
        result[name] = []
        Candidate::SaudiStatus.values_at(*saudi_status_keys).each do |saudi_status_id|
          result[name] << Candidate.solr_search_ids do
            all_of do
              with(:saudi_status_id, saudi_status_id)
              with(:job_type_ids, ids) if ids
            end
            paginate :per_page => Candidate.count
          end.length
          
        end
        
        result[name] << result[name].sum  
      end
    end    

    total = []
    result.values.each do |counts|
      counts.each_with_index {|c, i| total[i] ||= 0; total[i] += c }
    end
    
    result[:total] = total
    

    {:rows => result, :headers => saudi_status_keys + [:total]}
  end



  
  def self.db_recently_added
    now = Time.now
    today = Date.today.midnight
    yesterday = Date.yesterday.midnight
    beginning_of_week = today.beginning_of_week.midnight
    beginning_of_last_week = beginning_of_week.midnight - 1.week
    beginning_of_month = today.beginning_of_month.midnight
    beginning_of_last_month = beginning_of_month.midnight - 1.month
    
    result = ActiveSupport::OrderedHash.new
    
    [
      [:today, today..now],
      [:yesterday, yesterday..today],
      [:this_week, beginning_of_week..now],
      [:last_week, beginning_of_last_week..beginning_of_week],
      [:this_month, beginning_of_month..now],
      [:last_month, beginning_of_last_month..beginning_of_month]
    ].each do |name, range|
      result[name] = []

      [Employer, Candidate, Vacancy].each do |klass|
        result[name] << klass.count(:conditions => {:created_at => range})
      end
      
    end
    
    result
  end  
      
end

