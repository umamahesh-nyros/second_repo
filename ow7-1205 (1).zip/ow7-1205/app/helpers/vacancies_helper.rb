module VacanciesHelper
end
