module Candidates::HomeHelper
end
