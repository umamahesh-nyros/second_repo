module JavascriptsHelper
  def javascript_files
    @javascript_files||=[]
  end
  
  def javascript_initializations
    @javascript_initializations||=[]
  end
  
  def javascript_include_files(*args)
    javascript_files << javascript_include_tag(*args)
  end
  
  def javascript_include_initializations(&block)
    javascript_initializations << capture(&block)
  end
  
  def javascript_template_files
    javascript_files.join("\n")
  end
  
  def javascript_template_initializations
    javascript_initializations.join("\n")
  end
  
  def javascript_template_initializations?
    javascript_initializations.length > 0
  end
  
  def javascripts(*args, &block)
    javascript_include_files(*args)
    javascript_include_initializations(&block) if block_given?
  end  
end
