module JobsHelper

  def checkbox_with_label attr_name, name, id, suffix = nil, checked = false
    checkbox_id = "#{attr_name}_#{id}#{suffix}"
    check_box_tag("q[#{attr_name}][]", id, checked, :id => checkbox_id) +
      content_tag(:label, name, :for => checkbox_id )
  end

  def job_cities
    ids_sha = []
    City.all(:conditions => ["name in (?)",
        ['Khobar','Dhahran','Dammam','Qatif','Jubail']]).each do |c|
      ids_sha << c.id
    end
    ids_oksa = []
    country_id = Country.find_by_name("SAUDI ARABIA").id
    City.find_by_sql("select distinct c.id from cities c inner join vacancies v on v.city_id = c.id
        where c.country_id != #{country_id}").each do |c|
      ids_oksa << c.id
    end
    if ids_oksa.size == 0
      ids_oksa << -1
    end
    @job_cities = [
      ['Riyadh', -1, City.find_by_name("Riyadh").id ],
      ['Jeddah', -2, City.find_by_name("Jeddah").id ],
      ['Shargeyya', -3, ids_sha.join(",") ],
      ['Outside KSA', -4, ids_oksa.join(",")],
      ['Other', -5, '-5']
    ].each {|x| yield(x[0], x[1], x[2]) }
  end

  def admin_filters
    [[:all, "All"],
      [:published, "Published"],
      [:removed, "Removed"],
      [:reported, "Reported"],
      [:hot, "Hot Jobs"]].each {|x| yield(x[0], x[1])}
  end
end
