# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper
  JobTypeIcons = {
    Jobs::Type::Identifiers[:full_time] => "full-time",
    Jobs::Type::Identifiers[:graduate_program] => "graduate",
    Jobs::Type::Identifiers[:internship] => "internship",
    Jobs::Type::Identifiers[:summer_job] => "part-time"
  }

  def header_tab_active?(tab)
    rules = {
      :manage_jobs => [{:controller => "employers", :actions => ["show"]}],
      :search_cvs => [{:controller => "candidates", :actions => ["index"]}],
      :post_new_job => [{:controller => "jobs", :actions => ["new"]}],
      :search_jobs => [{:controller => "jobs"}],
      :post_cv => [{:controller => "candidates", :actions => ["new"]}],
      :interviews => [:controller => "candidates/interviews"],
      :events => [{:controller => "events"}],
      :news => [{:controller => "articles"}],
      :admin_home => [{:controller => "admins/home", :actions => ["show", "job_reprots", "candidate_reports"]}],
      :admin_invitations => [{:controller => "invitations"}],
      :admin_admins => [{:controller => "admins", :actions => ["index"]}],
      :admin_employers => [{:controller => "employers"}],
      :admin_jobs => [{:controller => "jobs"}],
      :admin_news => [{:controller => "articles"}],
      :admin_events => [{:controller => "events"}],
      :admin_candidates => [{:controller => "candidates"}],
      :admin_uni => [{:controller => "institutions"}],
      :settings => [
        {:controller => "employers", :actions => ["edit"]},
        {:controller => "candidates", :actions => ["edit"]},
        {:controller => "admins", :actions => ["edit"]}
      ]      
    }

    tab_rules = rules.detect {|k,v| k == tab}
    tab_rules[1].detect {|x| x[:controller] == @controller.controller_path && (x[:actions].nil? || x[:actions].include?(action_name))} if tab_rules
    
  end
  
  # TODO: provide instance variable arrays for both sources and blocks
  def javascripts(*sources)
    content_for(:javascripts) do
      javascript_include_tag(*sources) + (block_given? ? javascript_tag(yield) : '')
    end
  end
  
  def job_type_icon_full_grad
    image_tag "/images/icons/32/full-graduate.png"
  end
  
  def job_type_icon(type)
    raise "no icon for supplied job type" unless JobTypeIcons[type.identifier]
    image_tag "/images/icons/32/#{JobTypeIcons[type.identifier]}.png"
  end
  
  def job_filters(job)
    filters = {
      :degrees_institution_ids => (Institution.find :all, :conditions => {:id => job.filters[:degrees_institution_ids]}).collect do |i|
        {:name => i.name, :value => i.id}
      end,
      :gpa_range_ids => job.filter(:gpa_range_ids).first
    }

    [:a, :b].each do |level|
      filters[level] = {}
      ids = []

      job.filter(:degrees_category_ids).each do |id|
        c = Category.find_by_id id
        ids << {:parentId => c.parent_id, :childId => c.id} if c && c.send("level_#{level}?")
      end
      filters[level][:degrees_category_ids] = ids unless ids.empty?
    end
    
    filters
  end
  
  def text_to_html(text)
    auto_link( text.gsub(/\n|\r\n/, "<br />"), :all, :target => '_blank' ) unless !text
  end
  
  def optional_value(value)
    value.present? ? yield(value) : "Not specified"
  end
  
  def segregation_groups
   @segregation_groups =
        [['<br />Strict<br />Segregated', Candidate::MixingLevels[:strict_segregation],"Can only work in a fully segregated and isolated female section or department. Cannot work where there is mixing or dealing with males, except by email or phone, just like bank female branches"],
        ['<br />Semi<br />Segregated', Candidate::MixingLevels[:semi_segregated],"Can work with males in a professional environment.  Can work where females are seated in a separate isolated work area or room with females only"],
        ['<br />Unsegregated<br />Conservative', Candidate::MixingLevels[:unsegregated_conservative], "Can work with males in a professional environment. Can work where females work areas are not isolated and they can be working in the same area or office with males"],
        ['<br />Unsegregated<br />Relaxed', Candidate::MixingLevels[:unsegregated_unconservative], "Can work with males in a professional environment. Can work where females work areas are not isolated and they can be working in the same area or office with males. Can work in an environment that is relaxed in terms of mixing. Just like in hospitals or companies outside Saudi"]].each {|x| yield(x[0], x[1], x[2]) }
  end

  def segregation_slider(name, id, default_value = nil, style_class="slider")
    # javascript: application.js OW7.Employers.SegregationSlider
    options_details = [
      ["Strict Segregated", {"value" => Candidate::MixingLevels[:strict_segregation], "data-label" => "Strict<br />Segregated", "data-tooltip" => "Can only work in a fully segregated and isolated female section or department. Cannot work where there is mixing or dealing with males, except by email or phone, just like bank female branches"}],
      ["Semi Segregated", {"value" => Candidate::MixingLevels[:semi_segregated], "data-label" => "Semi<br />Segregated", "data-tooltip" => "Can work with males in a professional environment.  Can work where females are seated in a separate isolated work area or room with females only"}],
      ["Unsegregated Conservative", {"value" => Candidate::MixingLevels[:unsegregated_conservative], "data-label" => "Unsegregated<br />Conservative", "data-tooltip" => "Can work with males in a professional environment. Can work where females work areas are not isolated and they can be working in the same area or office with males"}],
      ["Unsegregated Relaxed", {"value" => Candidate::MixingLevels[:unsegregated_unconservative], "data-label" => "Unsegregated<br />Relaxed", "data-tooltip" => "Can work with males in a professional environment. Can work where females work areas are not isolated and they can be working in the same area or office with males. Can work in an environment that is relaxed in terms of mixing. Just like in hospitals or companies outside Saudi"}]
    ].each do |od|
      od[1]["selected"] = "selected" if od[1]["value"] == default_value
    end
    content_tag(:select, :name => name, :id => id, :class => style_class) do
      options_details.collect {|od| content_tag(:option,od[0],od[1])}.join
    end
  end
  
  def gpa_slider(name, title=nil)
    content_tag :div, :class => "GPA-slider" do
      (title ? content_tag(:label, title) : "") + 
      content_tag(:div, "", :class => "L_slider") +
      content_tag(:p) do
        tag(:input, :type => "hidden", :class=>"L_input", :name => name) + 
        content_tag(:label, "", :class => "L_label")
      end
    end
  end
  
  def country_flag_image_tag(country)
    image_tag "/images/flags/#{country.iso.downcase}.gif", :title => country.printable_name
  end
  
  # level is "a" or "b"
  def options_for_sub_categories_select(with_parentless_all, with_per_parent_all, level = nil)
    x = !with_parentless_all ? "" : content_tag(:option, "All Sub-categories", :value => "", :parent => nil) 
    x << (level ? Category.send("level_#{level}").type_parent : Category.type_parent).collect do |c|
      content_tag(:option, "All", :value => c.id, :parent => c.id)
    end.join("") if with_per_parent_all
    x << Category.sorted(false, level).collect do |c|
      content_tag(:option, c.name, :value => c.id, :parent => c.parent_id)
    end.join("")
    x
  end
  
  def universities_groups
   (@universities_groups||=Institution::GroupsInfo.find_all {|x| x[0].to_s =~ /_unis$/}).each {|x| yield(x[1][:name], x[1][:id], x[1][:tooltip])}
  end
  
  def institutions_groups
   (@institutions_groups||=Institution::GroupsInfo.find_all {|x| x[0].to_s =~ /_ins$/}).each {|x| yield(x[1][:name], x[1][:id], x[1][:tooltip])}
  end
  
  def no_flash_messages?
    [:notice, :error, :warning].all? {|k| flash[k].blank? }
  end
  
  def marital_status
    Candidate::MaritalStatus.each_pair {|k,v| yield(k.to_s.camelize, v) }
  end
  
  def gender
    Candidate::Gender.each_pair {|k,v| yield(k.to_s.camelize, v) }
  end

  def levels_info
    [['A', 'Job seekers with Bachelors degree and above, who are fluent English speakers.'],
     ['B', 'Job seekers with Diplomas and below, who are fluent English speakers.'],
     ['C', 'Job seekers with any degree who are Arabic speakers.']].each {|x| yield(x[0], x[1]) }
  end
  
  def degrees_categories(level = "a")
    Category.sorted(true, level).each {|c| yield(c.name, c.id) }
  end
  
  def level_a_degrees
    [["Phd", Degree::Levels[:phd]],
    ["Masters/MBA", Degree::Levels[:masters]],
    ["Bachelors", Degree::Levels[:bachelors]]].each {|x| yield(x[0], x[1]) }
  end
  
  def level_b_degrees
    [["Diploma", Degree::Levels[:diploma]],
    ["Some University", Degree::Levels[:some_university]],
    ["High School", Degree::Levels[:high_school]],
    ["Below High School", Degree::Levels[:below_high_school]]].each {|x| yield(x[0], x[1]) }
  end
  
  def options_for_methods_of_study
    Degree::MethodOfStudyC.ascend_by_position.collect do |m|
      content_tag(:option, m.name, :value => m.id)
    end.join("")
  end
  
  def saudi_status
    [["Saudis", Candidate::SaudiStatus[:saudi]],
    ["Half-Saudis", Candidate::SaudiStatus[:half_saudi]],
    ["Non-Saudis in KSA", Candidate::SaudiStatus[:non_saudi_in_ksa]]].each {|x| yield(x[0], x[1]) }
  end  

  def odd_class?(i)
    (i+1).odd?
  end

  def saudi_phone_code
    @saudi_phone_code ||= Country.saudi_arabia.dialing_codes.first
  end
  
  def formatted_date(date, type = :long)
    case type
      when :short
        date.strftime("%B %d, %Y")
      when :long
        date.strftime("%A, %b %d, %Y")
    end  
  end
  
  def formatted_month_year(time)
    time.strftime("%B %Y")
  end

  def formatted_time(time, type = :long)
    case type
      when :short
        time.strftime("%I:%M%p %A, %B %d")
      when :long
        time.strftime("%A, %B %d, %Y %I:%M%p")
    end  
  end

  def formatted_city_country(city, country)
    city ? "#{city.name}, #{country.printable_name}" : country.printable_name
  end
  
  def formatted_phone(phone, country=nil)
    #TODO do something with the countrycode
    #and handle that no country is sent
    "+#{phone}"
  end
  
  def required_span
    content_tag(:span, "*", :class => "form-req")
  end
  
  def image_full_path(image, file_system)
    file_system ? "#{Rails.root}/public#{image}" : image
  end
  
  def pdf_stylesheet_link_tag style
    stylesheet_link_tag "#{Rails.root}/public/stylesheets/#{style}"
  end
  
  def institution_ranking_class(institution)
    if institution
      institution.ivy_league ? Institution::IvyLeague.style_class : institution.ranking.style_class 
    end
  end
  
  def institution_ranking_title(institution)
    if institution
      institution.ivy_league ? Institution::IvyLeague.name : institution.ranking.name 
    end
  end
end
