module EnquiriesHelper

  def type_options
    [["Please Select", ""]] + Enquiry::TypeC.ascend_by_position.collect {|t| [t.name, t.id]}
  end

end
