module EmployersHelper

  def filter_name key
    "employer[jobs_attributes][0][filters][#{key}][]"
  end
  
  def category_name(name, key)
    "employer[jobs_attributes][0][filters][#{name}][][#{key}]"
  end 

  def filter_id key
    "employer_jobs_attributes_0_filters_#{key}"
  end
  
  def weekend_options
    Job::Weekends.ascend_by_position.collect {|w| [w.name, w.id]}
  end

  def degrees_countries(job)
    select_tag(filter_name(:degrees_country_ids), options_for_select([["All Countries", nil]] + Country.all.collect {|c| [c.printable_name, c.id]}, :selected => job.filter(:degrees_country_ids)), :class => 'wide')
  end

end
