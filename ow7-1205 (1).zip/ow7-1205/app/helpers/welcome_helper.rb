module WelcomeHelper

  def checkbox_with_label attr_name, name, id, suffix = nil, checked = false
    checkbox_id = "#{attr_name}_#{id}#{suffix}"
    check_box_tag("q[#{attr_name}][]", id, checked, :id => checkbox_id) +
    content_tag(:label, name, :for => checkbox_id )
  end

  def job_cities
  @job_cities = [
    ['Riyadh', '-1' ],
    ['Jeddah', '-2'],
    ['Shargeyya', '-3'],
    ['Outside KSA', '-4'],
    ['Other', '-5']
    ].each {|x| yield(x[0], x[1]) }
  end

end
