module Admins::HomeHelper
  MappingHash = {
    :full_time_graduate => "Full time job / graduate program",
    :internship => "Internship",
    :summer_part_time => "Summer / part-time job",
    :saudi => "Saudis",
    :half_saudi => "Half-Saudis",
    :non_saudi_in_ksa => "Non-Saudis in KSA",
    :non_saudi => "Others",
    :total => "Total"
  }
  
  def table_map(key)
    MappingHash[key] || key.to_s.humanize
  end
end
