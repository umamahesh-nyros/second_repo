module SeoHelper
  # If @page_title is an already set string, it will be returned directly
  # If it's an array, this indicates that site title should be joined
  # If it's not there, a default title will be returned
  
  def application_title
    "OilWell7.com"
  end
  
  def page_title
    unless @page_title.is_a?(String)
      @page_title = @page_title.blank? ? [application_title] : @page_title + [application_title]
      @page_title = @page_title.join(" - ")
    end
    @page_title
  end

  def page_title=(value)
    @page_title = value
  end
  
  def page_title_tag
    content_tag(:title, page_title)
  end
  
  def meta_keywords
    @meta_keywords ||= []
  end
  
  def meta_keywords=(value)
    meta_keywords << Array(value)
  end
  
  def meta_keywords_tag
    tag("meta", {:name => "keywords", :content => meta_keywords.join(",")}) if meta_keywords.length > 0
  end
  
  def meta_description
    @meta_description
  end
  
  def meta_description=(value)
    @meta_description = value
  end
  
  def meta_description_tag
    tag("meta", {:name => "description", :content => meta_description}) unless meta_description.blank?
  end
end
