module CommentsHelper

  def klass_name(commentable)
    commentable.class.to_s.underscore.gsub('/', '_')
  end
  
  def comment_id(comment)
    "#{klass_name(comment.commentable)}_comment_#{comment.id}"
  end
  
  def comments_count_id(commentable)
    "#{klass_name(commentable)}_comments_count"
  end
  
  def comments_count(commentable)
    pluralize(commentable.comments.status_visible.count, 'Comment')
  end

  def comment_form_id(commentable)
    "#{klass_name(commentable)}_comment_form"
  end

  def comments_container_id(commentable)
	  "#{klass_name(commentable)}_#{commentable.id.to_s}_comments"
  end

  def comments_list_id(commentable)
    "#{klass_name(commentable)}_#{commentable.id.to_s}_comments_list"
  end
  
  def no_current_user
    go_to = {:go_to => request.request_uri + "#comments"}
    yield(new_candidate_path(go_to), candidates_login_path(go_to))
  end

  def comments_path(commentable)
    send(klass_name(commentable) + '_comments_path', commentable.id)
  end

  def comment_path(comment)
    send(klass_name(comment.commentable) + '_comment_path', comment.commentable, comment)
  end

  def commenter_img_src(commenter)
    case commenter
      when Candidate
        commenter.avatar.url(:small)
      when Employer
        commenter.logo.url(:small)
      when Admin
        "/images/defaults/admin/small-admin.png"
    end
  end

  def store_commentable_path
    session[:after_login] ||= {}
    session[:after_login][:go_to] = request.request_uri
  end
  
end
