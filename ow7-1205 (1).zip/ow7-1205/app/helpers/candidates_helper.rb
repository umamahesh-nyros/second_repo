module CandidatesHelper
  def registration_steps_titles
    ["Personal details", "What you're looking for", "Your contacts"]
  end
  
  def registration_step_title(step)
    registration_steps_titles[step-1]
  end
  
  def iqama
    yield("Yes, and its transferrable", Candidate::IqamaTypes[:transferrable])
    yield("Yes, but its not transferrable", Candidate::IqamaTypes[:untransferrable])
    yield("No", Candidate::IqamaTypes[:none])
  end
  
  def job_start_date_question(status)
    if status == :in_ksa
      "When can you start working in Saudi Arabia?"
    elsif status == :outside_ksa
      "Approximately, when do you expect to be back/available in Saudi Arabia?"
    else
      raise ArgumentError, "unsupported status"
    end
  end
  
  def checkbox_with_label attr_name, name, id, suffix = nil, checked = false, options = {}
    checkbox_id = "#{attr_name}_#{id}#{suffix}"
    content_tag :p, :class => options[:p_class] do
      check_box_tag("q[#{attr_name}][]", id, checked, :id => checkbox_id) +
      content_tag(:label, name, :for => checkbox_id, :class => options.nested_try_get(:label_tooltip).blank? ? nil : 'tip',
                                "original-title" => options.nested_try_get(:label_tooltip))
    end
  end
  
def job_cities
    ids_sha = []
    City.all(:conditions => ["name in (?)",
        ['Khobar','Dhahran','Dammam','Qatif','Jubail']]).each do |c|
      ids_sha << c.id
    end
    ids_oksa = []
    country_id = Country.find_by_name("SAUDI ARABIA").id
    City.find_by_sql("select distinct c.id from cities c
        where c.country_id != #{country_id}").each do |c|
      ids_oksa << c.id
    end
    @job_cities = [
      ['Riyadh', -1,City.find_by_name("Riyadh").id],
      ['Jeddah', -2, City.find_by_name("Jeddah").id],
      ['Shargeyya', -3,ids_sha.join(",")],
      #['Outside KSA', -4, ids_oksa.join(",")],
      ['Other', -5, '-5']
    ].each {|x| yield(x[0],x[1],x[2]) }
  end
  
  def countries
    select_tag("q[degrees_country_ids][]", options_for_select([["All Countries", nil]] + Country.ascend_by_printable_name.all.collect {|c| [c.printable_name, c.id]}), :class => "wide")
  end
  
  def candidate_statuses
    Candidate::StatusC.filter_and_ascend_by_position.each {|c| yield(c.name, c.id)}
  end
end
