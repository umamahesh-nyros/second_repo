module Vacancies::SlotsHelper
end
