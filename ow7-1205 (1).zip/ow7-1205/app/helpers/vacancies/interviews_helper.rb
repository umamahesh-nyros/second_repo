module Vacancies::InterviewsHelper
  
  def options_for_hours
    @options_for_hours ||= (1..12).collect {|i| i.to_s.rjust(2, "0")}
  end
  
  def options_for_minutes
    @options_for_minutes ||= (0..59).collect {|i| i.to_s.rjust(2, "0")}
  end
  
  def options_for_ampm
    @options_for_ampm ||= ["AM","PM"]
  end
end
