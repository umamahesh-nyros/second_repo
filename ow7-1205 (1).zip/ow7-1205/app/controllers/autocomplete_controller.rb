class AutocompleteController < ApplicationController
  skip_before_filter :candidate_should_complete_registration
  
  def institutions
    @search = Institution.solr_search do
      with(:name).starting_with(params[:q].downcase) if params[:q]
      with(:type_id, params[:type_id]) if params[:type_id]
      without(:instance_id).any_of(params[:values]) if params[:values] && params[:values].length > 0
      paginate :page => 1, :per_page => params[:limit] || 20
    end
    results = @search.results.collect {|i| i.autocomplete_hash}
    results = [{:name => "No results found. Why don't you add yours?", :value => "__noresult__"}] if results.length == 0 && params[:oa]
    render :json => results
  end
  
  def countries
    @search = Country.solr_search do
      with(:name).starting_with(params[:q].downcase) if params[:q]
      without(:instance_id).any_of(params[:values]) if params[:values] && params[:values].length > 0
      paginate :page => 1, :per_page => params[:limit] || 20
    end
    render :json => @search.results.collect {|i| i.autocomplete_hash}
  end
  
  def cities
    params[:country_id] = Country.saudi_arabia.id if params[:saudi]
    @search = City.solr_search(:include => [:country]) do
      with(:names).starting_with(params[:q].downcase) if params[:q]
      with(:country_id, params[:country_id]) if params[:country_id]
      with(:job, true) if params[:job]
      without(:instance_id).any_of(params[:values]) if params[:values] && params[:values].length > 0
      paginate :page => 1, :per_page => params[:limit] || 20
    end
    render :json => @search.results.collect {|c| c.autocomplete_hash}
  end
end
