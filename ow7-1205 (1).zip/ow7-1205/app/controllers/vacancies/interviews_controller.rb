class Vacancies::InterviewsController < Vacancies::BasicController
  before_filter :find_interview, :only => [:edit, :update, :show]
  before_filter :filter_ids, :only => [:new, :edit]
  
  def index
    find_vacancy
  end
  
  def invite
    find_vacancy
    if @vacancy.interviews.length == 0
      redirect_to new_vacancy_interview_path(@vacancy, :ids => params[:ids])
    end
  end
  
  def new
    find_vacancy
    @interview = @vacancy.interviews.build(params[:interviews_interview])
    @interview.fake_slots = true
  end
  
  def create
    find_vacancy
    @interview = @vacancy.interviews.build(params[:interviews_interview])
    @interview.fake_slots = true
    if params[:preview]
      @interview.valid? #this is a correct line :)
      respond_to do |format|
        format.html {render :template => '/vacancies/interviews/new'}
      end
    elsif @interview.save
      respond_to do |format|
        format.html {redirect_to vacancy_interview_path(@interview.vacancy, @interview)}
      end
    else
      respond_to do |format|
        format.html {render :template => '/vacancies/interviews/new'}
      end
    end
  end
  
  def edit
    @interview.fake_slots = false
  end
  
  def update
    @interview.fake_slots = false
    @interview.attributes = params[:interviews_interview]
    if params[:preview]
      @interview.valid? #this is a correct line :)
      respond_to do |format|
        format.html {render :template => '/vacancies/interviews/edit'}
      end
    elsif @interview.save
      respond_to do |format|
        format.html {redirect_to vacancy_interview_path(@interview.vacancy, @interview)}
      end
    else
      respond_to do |format|
        format.html {render :template => '/vacancies/interviews/edit'}
      end
    end
  end
  
  def show
    respond_to do |format|
      format.html
      format.pdf do
        render :pdf => "interview",
               :template => "/vacancies/interviews/show.pdf.erb"
      end
    end
    
  end
  
  #########
  protected
  #########
  
  def find_interview
    find_vacancy
    @interview = @vacancy.interviews.find(params[:id])
  end
  
  def filter_ids
    filter_for_paying_only_ids(Candidate) if params[:ids]
  end
end
