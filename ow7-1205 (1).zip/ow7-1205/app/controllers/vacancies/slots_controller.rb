class Vacancies::SlotsController < Vacancies::BasicController
  
  def destroy
    find_vacancy
    slot = @vacancy.slots.find(params[:id])
    slot.destroy
    respond_to do |format|
      format.html {redirect_to vacancy_interview_path(@vacancy, slot.interview)}
    end
  end
  
end
