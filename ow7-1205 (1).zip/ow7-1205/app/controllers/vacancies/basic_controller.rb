class Vacancies::BasicController < ApplicationController
  before_filter :require_employer
  
  #########
  protected
  #########
  
  def find_vacancy
    @vacancy = current_employer.vacancies.find(params[:vacancy_id])
    if @vacancy.status_hidden?
      flash[:error] = I18n.t("flash.interview_vacancy_hidden")
      redirect_back_or(employer_path(current_employer))
    end
  end
end
