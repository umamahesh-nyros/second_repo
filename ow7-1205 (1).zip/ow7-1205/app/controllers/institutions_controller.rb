class InstitutionsController < ApplicationController
  PER_PAGE = 10
  before_filter :require_admin!, :except => [:create]
  before_filter :find_institution, :only => [:update, :destroy]
  
  def index
    @institutions = Institution.filter_search(params[:q]||{}, params[:page]||1, PER_PAGE).results
    respond_to do |format|
      format.html
      format.js
    end
  end
  
  def update
    if @institution.update_attributes(params[:institution])
      @institution.solr_reindex_candidates
      respond_to do |format|
        format.js
      end
    else
      respond_to do |format|
        format.js do
          ajax_flash(:error, @institution.errors.full_messages.first)
          render :status => HTTP_STATUS[:failure]
        end
      end
    end
  end
  
  def merge
    begin
      Institution.merge!(params[:id], params[:ids])
      @success = true
      respond_to do |format|
        format.js do
          ajax_flash(:notice, I18n.t('flash.institutions.merge_success'))
        end
      end
    rescue
      @success = false
      respond_to do |format|
        format.js do
          ajax_flash(:error, I18n.t('flash.institutions.merge_failed'))
          render :status => HTTP_STATUS[:failure]
        end
      end
    end
  end
  
  def create
    @institution = Institution.new(params[:institution])
    @institution.adder_type_id = current_user.is_a?(Admin) ? Institution::AdderTypes[:system].id : Institution::AdderTypes[:other].id
    
    if @institution.save
      if current_user.is_a?(Admin)
        respond_to do |format|
          format.js
        end
      else
        respond_to do |format|
          format.json { render :json => @institution.autocomplete_hash }
        end
      end
    else
      respond_to do |format|
        format.js do
          ajax_flash(:error, @institution.errors.full_messages.first)
          render :status => HTTP_STATUS[:failure]
        end
        format.json do
          ajax_flash(:error, @institution.errors.full_messages.first)
          render :status => HTTP_STATUS[:failure]
        end
      end
    end
  end
  
  def destroy
    if @institution.safe_destroy
      respond_to do |format|
        format.js
      end
    else
      respond_to do |format|
        format.js {ajax_flash(:error, @institution.errors.full_messages.first)}
        render :status => HTTP_STATUS[:failure]
      end
    end
  end
  
  #########
  protected
  #########
  
  def find_institution
    @institution = Institution.find params[:id]
  end
end
