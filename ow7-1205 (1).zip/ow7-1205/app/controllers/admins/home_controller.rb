class Admins::HomeController < ApplicationController
  before_filter :require_admin
  
  def show
    @recently_added = Statistics.recently_added
  end
  
  def job_reports
    @city_by_month = Statistics.job_city_by_month
  end

  def candidate_reports
    @availability = Statistics.candidate_availability
    @country_of_residence = Statistics.candidate_country_of_residence
    @country_of_education = Statistics.candidate_country_of_education
    @gender_country_of_education = Statistics.candidate_saudi_gender_country_of_education
    @city_of_residence = Statistics.candidate_city_of_residence
    @saudi_city_of_residence = Statistics.candidate_saudi_city_of_residence
    @most_popular_cities = Statistics.candidate_most_popular_cities
  end
  
end
