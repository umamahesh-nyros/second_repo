class Admins::PasswordResetsController < ApplicationController
  before_filter :require_no_admin
  before_filter :load_admin_using_perishable_token, :only => [:edit, :update]
  skip_after_filter :write_flash_messages_to_cookies, :only => [:edit, :update, :index, :create]
  
  def new
  end
  
  def create
    @admin = Admin.find_by_email(params[:email])
    if @admin
      @admin.deliver_password_reset_instructions!
      flash[:notice] = t('flash.password_resets.create.notice')
      redirect_to admins_login_path
    else
      flash[:error] = t('flash.password_resets.create.no_user')
      redirect_to admins_password_resets_path
    end
  end
  
  def edit
  end
  
  def update
    @admin.password = params[:admin][:password]
    @admin.password_confirmation = params[:admin][:password_confirmation]
    if params[:admin][:password].present? && @admin.save
      flash[:notice] = t('flash.password_resets.update.notice')
      AdminSession.create(@admin)
      redirect_to root_path
    else
      error = @admin.errors.full_messages.first if !@admin.valid?
      flash[:error] = error || t('flash.password_resets.update.blank_password')
      redirect_to :action => :edit, :id => params[:id]
    end	
  end
  
  #######
  private
  #######
  
  def load_admin_using_perishable_token
    @admin = Admin.find_using_perishable_token(params[:id], 0)
    unless @admin
      flash[:error] = t('flash.password_resets.no_user_with_token')
      redirect_to admins_password_resets_path
    end
  end
end
