class Admins::SessionsController < ApplicationController
  before_filter :require_no_user, :only => [:new, :create]
  before_filter :require_admin, :only => :destroy
  skip_after_filter :write_flash_messages_to_cookies, :only => [:new, :create]
  
  def new
    @admin_session = AdminSession.new
  end
  
  def create
    @admin_session = AdminSession.new(params[:admin_session])
    if @admin_session.save
      clear_non_admin_sessions
      redirect_back_or_default admins_home_path
    else
      render :action => :new
    end
  end
  
  def destroy
    current_admin_session.destroy
    redirect_back_or_default admins_login_url
  end
end
