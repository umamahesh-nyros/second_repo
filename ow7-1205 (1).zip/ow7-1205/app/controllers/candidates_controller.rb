class CandidatesController < ApplicationController
  @PER_PAGE = 10
  ExportFields = Constants.new(:name => {:name => "Name", :position => 1, :value => Proc.new {|c| c.name}},
                               :age => {:name => "Age", :position => 2, :value => Proc.new {|c| c.age}},
                               :nationality => {:name => "Nationality", :position => 3, :value => Proc.new {|c| c.countries.collect {|x| x.printable_name}.join("/")}},
                               :gender => {:name => "Gender", :position => 4, :value => Proc.new {|c| c.gender.name}},
                               :level => {:name => "Level", :position => 5, :value => Proc.new {|c| c.try(:highest_degree).try(:level_name)}},
                               :subject => {:name => "Subject", :position => 6, :value => Proc.new {|c| c.try(:highest_degree).try(:full_category_name)}},
                               :university => {:name => "University", :position => 7, :value => Proc.new {|c| c.try(:highest_degree).try(:institution).try(:name)}},
                               :mobile_number => {:name => "Mobile number", :position => 8, :value => Proc.new {|c| c.preferred_phone}},
                               :gpa => {:name => "Email", :position => 9, :value => Proc.new {|c| c.email}})
  before_filter :require_no_candidate, :only => [:new, :create]
  before_filter :require_candidate, :only => [:edit, :update, :register, :complete_registration]
  before_filter :find_candidate, :only => [:show, :edit, :update, :destroy, :block, :unblock, :reject, :unreject, :request_unblock]
  before_filter :ensure_candidate_is_current_candidate, :only => [:edit, :update, :destroy, :request_unblock]
  skip_before_filter :candidate_should_complete_registration, :only => [:register, :complete_registration]
  before_filter :ensure_incomplete_registration, :only => [:register, :complete_registration]
  before_filter :ensure_viewable_by_current_user, :only => [:show]
  before_filter :check_for_paying_only_access, :only => [:show]
  before_filter :process_index_params, :only => [:index]
  before_filter :require_admin_or_employer!, :only => [:index, :mass_export]
  before_filter :filter_ids, :only => [:mass_export]
  before_filter :require_admin!, :only => [:block, :unblock, :reject, :unreject,
                                           :mass_block, :mass_unblock, :mass_reject, :mass_unreject]
  
  def index
    respond_to do |format|
      format.html #just renders the initial page....the search is performed only via ajax
      format.js do
        params[:q] = {}.with_indifferent_access unless params[:q]
        params[:q][:order] = "current_login_at" if params[:q][:order].blank?
        params[:q][:perpage] = '10' if params[:q][:perpage].blank?
        @PER_PAGE = params[:q][:perpage].to_i unless params[:q][:perpage].nil?
        @search = nil
        class_ids = params[:q][:degree_language_class_id]
        # TODO deal with other option
        unless (params[:q][:job_city_ids].nil?)
          params[:q][:job_city_ids] = params[:q][:job_city_ids] - ["-5"]
        end
        class_c_search = !class_ids.blank? && class_ids.first.to_i == Candidate::DegreeLanguageClasses[:ar]
        unless class_c_search
          @duration = Time.now
          @search = Candidate.filter_search(params[:q], current_user, params[:page] || 1, @PER_PAGE)
          @duration = (Time.now - @duration).round(3)  
        end
      end
    end
  end
  
  def mass_export
    # export only the maximum number of a candidates in a search results page
    @candidates = Candidate.for_user(current_user).find(params[:ids],
                    :include =>[{:degrees => [:category, :sub_category, :institution], :residence_city => :country}, :countries])
    respond_to do |format|
      format.csv
      format.pdf do
        render :pdf => "cvs",
               :template => "/candidates/mass_export.pdf.erb"
      end
    end
  end

    def mass_export_application
    candidate_ids = []
    unless params[:ids].nil?
      params[:ids].each do |aid|
        a = Vacancies::Application.find_by_id(aid)
        candidate_ids << a.candidate_id
      end
    end
    @candidates = Candidate.for_user(current_user).find(candidate_ids,
                    :include =>[{:degrees => [:category, :sub_category, :institution], :residence_city => :country}, :countries])
    respond_to do |format|
      format.csv do
        render :template => "/candidates/mass_export.csv.erb"
      end
      format.pdf do
        render :pdf => "cvs",
               :template => "/candidates/mass_export_application.pdf.erb"
      end
    end
  end
  
  def new
    go_to = params[:go_to]
    
    if go_to
      session[:after_login] ||= {}
      session[:after_login][:go_to] = go_to
    end
    
    @candidate = Candidate.new
    prepare_variables
    prepare_ac_errors      
  end
  
  def register
    @candidate = Candidate.find current_candidate.id
  end
  
  def complete_registration
    process_params
    
    @candidate = Candidate.find current_candidate.id
    @candidate.set_last_updated
    if @candidate.update_attributes(params[:candidate])
      if @candidate.incomplete_registration?
        redirect_to register_candidates_path
      else
        candidate_after_login
        redirect_to @go_to ? @go_to : candidates_home_path
      end
      
    else
      prepare_variables
      prepare_ac_errors      
      render :action => :register
    end
  end
  
  def create
    process_params
    @candidate = Candidate.new(params[:candidate])
    # Since they are protected against mass assignment
    [:email, :password].each {|k| @candidate.send("#{k}=", params[:candidate][k]) if params[:candidate] && params[:candidate][k]}
    @candidate.set_last_updated
    if @candidate.save
      CandidateSession.create(@candidate)
      redirect_back_or_default register_candidates_path
    else
      prepare_variables
      prepare_ac_errors
      render :template => "candidates/new"
    end
  end
  
  def show
    respond_to do |format|
      format.html
      format.pdf do
        render :pdf => @candidate.name.parameterize,
               :template => "/candidates/show.pdf.erb"
      end
    end
  end
  
  def edit
    prepare_variables
  end
  
  def update
    process_params
    clear_empty_collections
    [:email, :password].each {|k| @candidate.send("#{k}=", params[:candidate][k]) if params[:candidate] && params[:candidate][k]}
    @candidate.set_last_updated
    if @candidate.update_attributes(params[:candidate])
      flash[:notice] = t('flash.users.update.notice')
      redirect_to candidates_home_path
    else
      prepare_variables
      prepare_ac_errors
      render :template => "candidates/edit"
    end
  end
  
  def destroy
    @candidate.destroy
    flash[:notice] = t('flash.users.destroy.notice')
    redirect_to(root_url)
  end
  
  [:block, :unblock, :reject, :unreject].each do |m|
    define_method(m) do
      @candidate.send("#{m}!")
      respond_to do |format|
        format.js { render :template => "/candidates/indvidual_action.rjs" }
      end
    end
    
    define_method("mass_#{m}") do
      @candidates = Candidate.send("mass_#{m}!", params[:ids])
      respond_to do |format|
        format.js { render :template => "/candidates/mass_action.rjs" }
      end
    end
  end
  
  def request_unblock
    @candidate.request_unblock!
    respond_to do |format|
      format.html { redirect_back_or edit_candidate_path(@candidate) }
    end
  end
  
  #######
  private
  #######
  
  def prepare_variables
    @nationality ||= @candidate.countries.collect {|c| c.autocomplete_hash}.to_json
    @education = @candidate.degrees.collect {|d| d.attributes.reject {|k,v| v.blank? }.merge(
        :level_class => d.level_class, :institution => d.institution.try(:autocomplete_hash), 
        :errors => {:institution => d.institution.blank?, :graduation_date => d.errors.on(:date).present?}
      )}.to_json
    
    @residence_country = @candidate.residence_country.autocomplete_hash.merge(
      :dialing_codes => [@candidate.residence_phone_code]
    ).to_json if @candidate.residence_country
    @residence_city = @candidate.residence_city.autocomplete_hash.to_json if @candidate.residence_city
    @saudi_city = @candidate.saudi_city.autocomplete_hash.to_json if @candidate.saudi_city
  end
  
  def prepare_ac_errors
    @ac_errors = {}
    @ac_errors[:nationality] = true if @candidate.errors.on(:nationality)
    @ac_errors[:residenceCountry] = true if @candidate.errors.on(:residence_country_id)
    @ac_errors[:saudiCity] = true if @candidate.errors.on(:saudi_city_id)
    @ac_errors = @ac_errors.to_json
  end
  # TODO: find a better solution (Refactor and merge both Autocompleters)
  def clear_empty_collections
    country_ids = params[:candidate][:country_ids]
    country_ids = country_ids && country_ids.reject {|id| id.blank?}
    
    if country_ids && country_ids.blank?
      @candidate.candidates_countries.each {|c| c.mark_for_destruction }
      params[:candidate].delete(:country_ids)
      @nationality = [].to_json
    end
    
  end
  
  def find_candidate
    @candidate = Candidate.find params[:id]
  end
  
  def ensure_candidate_is_current_candidate
    unless @candidate.id == current_candidate.id
      flash[:error] = t('flash.users.user_is_not_current_candidate')
      redirect_back_or(root_path)
    end
  end
  
  def ensure_incomplete_registration
    raise ActiveRecord::RecordNotFound,t('flash.registration_completed') unless current_candidate.incomplete_registration?
  end
  
  def process_index_params
    if params[:q]
      [:job_type_ids, :marital_status_id].each do |attr|
        params[:q][attr] = params[:q][attr].is_a?(Array) && params[:q][attr].collect {|x| x.split(",")}.flatten  
      end
      
    end
  end
  
  def process_params
    if params[:candidate]
      params[:candidate][:job_type_ids] = params[:candidate][:job_type_ids].collect {|x| x.is_a?(String) ? x.split(",") : x}.flatten if params[:candidate][:job_type_ids]
      params[:candidate][:job_city_ids] = params[:candidate][:job_city_ids].collect {|x| x.is_a?(String) ? x.split(",") : x}.flatten if params[:candidate][:job_city_ids]
      if not params[:candidate][:job_city_ids].nil? and params[:candidate][:job_city_ids].include? "-5"
        params[:candidate][:job_city_ids] = params[:candidate][:job_city_ids] - ["-5"]
      end
      fix_date = Proc.new {|v, attr| v[attr] = "#{v[attr]}-01" if v[attr] =~ DateFormats.find_by_sym_id(:year_month).regex && !(v[attr] =~ DateFormats.find_by_sym_id(:full).regex)}
      fix_date.call(params[:candidate], :job_start_date)
      if params[:candidate][:degrees_attributes]
        case params[:candidate][:degrees_attributes]
          when Hash #case of view
          params[:candidate][:degrees_attributes].each_pair {|k, v| fix_date.call(v, :date)}
          when Array #case of tests
          params[:candidate][:degrees_attributes].each {|v| fix_date.call(v, :date)}
        else
          raise ArgumentError, "Unsupported type"
        end
      end
    end
  end
  
  def ensure_viewable_by_current_user
    raise(ActiveRecord::RecordNotFound, "Not allowed") unless @candidate.viewable_by?(current_user)
  end
  
  def check_for_paying_only_access
    if not current_candidate and (@candidate.for_paying_only? and not access_for_paying_only?)
      params[:format] = "html"
      render :inaccessible
    end
  end
  
  def filter_ids
    filter_for_paying_only_ids(Candidate)
  end
end
