class Candidates::HomeController < ApplicationController
  PER_PAGE = 5
  before_filter :require_candidate
  
  def show
    @vacancies_for_you = Vacancy.for_candidate(current_candidate, :per_page => PER_PAGE)
    @applied_vacancies = current_candidate.visible_vacancies.all :include => :job
  end
end
