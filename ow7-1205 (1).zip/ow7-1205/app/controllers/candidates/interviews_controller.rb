class Candidates::InterviewsController < ApplicationController
  PER_PAGE = 10
  before_filter :require_candidate
  
  def index
    @connections = current_candidate.visible_connections.with_open_interview.paginate :page => params[:page], :per_page => PER_PAGE,
                                                                  :order => "time desc",
                                                                  :include => {:interview => [:city, :employer, {:vacancy => [:job, :city]}]}
    respond_to do |format|
      format.html
    end
  end
  
  def show
    @connection = current_candidate.visible_connections.find(params[:id])
  end
  
  def update
    @connection = current_candidate.visible_connections.with_open_interview.find(params[:id])
    @connection.assign_slot!(@connection.interview.slots.status_open.find(params[:slot_id]))
    respond_to do |format|
      format.html {redirect_to candidates_interview_path(@connection)}
    end
  end
  
end
