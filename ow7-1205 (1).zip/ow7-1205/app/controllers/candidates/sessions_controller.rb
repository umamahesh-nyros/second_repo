class Candidates::SessionsController < ApplicationController
  skip_before_filter :candidate_should_complete_registration
  before_filter :require_no_user, :only => [:new, :create]
  before_filter :require_candidate, :only => :destroy
  skip_after_filter :write_flash_messages_to_cookies, :only => [:new, :create]
  
  def new
    go_to = params[:go_to]

    if go_to
      session[:after_login] ||= {}
      session[:after_login][:go_to] = go_to
    end

    @candidate_session = CandidateSession.new
  end
  
  def create
    @candidate_session = CandidateSession.new(params[:candidate_session])
    if @candidate_session.save

      candidate_after_login
      
      if @candidate_session.candidate.blocked?
        redirect_to edit_candidate_path(@candidate_session.candidate)
      else
        @go_to ? redirect_to(@go_to) : redirect_back_or_default(candidates_home_path)
      end
      
    else
      render :action => :new
    end
  end
  
  def destroy
    current_candidate_session.destroy
    redirect_to candidates_login_url
  end
end
