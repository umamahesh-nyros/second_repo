class CommentsController < ApplicationController
  before_filter :require_user
  
  def create
    @commentable = (params[:commentable_type]).constantize.find(params[:commentable_id])
    @comment = @commentable.comments.build params[:comment]
    @comment.commenter = current_user
    # creating a new comment for the form to be cleared
    @comment = @commentable.comments.build if @comment.save
    
    latest_post = (latest_post_id = params[:latest_post_id]) ? @commentable.comments.status_visible.last(:conditions => ["id <= ?", latest_post_id]) : nil
    
    conditions = latest_post ? ["created_at > ?", latest_post.created_at] : {} 
    
    @new_comments = @commentable.comments.status_visible.all :conditions => conditions, :order => "created_at desc"
    
    @latest_post = @new_comments.first || latest_post
    
    respond_to do |format|
      format.html {redirect_back_or root_path}
      format.js
    end      
  end
  
  def destroy
    @comment = Comment.find_by_id(params[:id])
    if @comment && (current_admin || @comment.editable_by?(current_user)) && @comment.destroy
      @success = t("flash.comments.deleted")
      @commentable = @comment.commentable
    else
      @error = t("flash.comments.not_deleted")
    end
    respond_to do |format|
      format.html do
        flash[:notice] = @success if @success
        flash[:error] = @error if @error
        redirect_back_or root_path
      end
      format.js
    end
  end
  
end
