class EmployersController < ApplicationController
  before_filter :require_no_employer, :only => [:new, :create]
  before_filter :ensure_invited, :only => [:new, :create]
  before_filter :require_employer, :only => [:show, :edit, :update]
  before_filter :find_employer, :only => [:show, :edit, :update, :destroy, :block, :unblock, :request_unblock, :paying, :non_paying]
  before_filter :ensure_employer_is_current_employer, :only => [:show, :edit, :update, :destroy, :request_unblock]
  before_filter :require_admin!, :only => [:index, :block, :unblock, :mass_block, :mass_unblock, :paying, :non_paying]
  
  def index
    params[:q] = {} unless params[:q]
    params[:q][:sorter] = "created_at" if params[:q][:sorter].blank?
    @search = Employer.filter_search(params[:q], params[:page] || 1)
    respond_to do |format|
      format.html
      format.js
    end
  end
  
  def new
    @employer = Employer.new
    @job = @employer.jobs.build
    @employer.invitation = @invitation
  end
  
  def create
    # Should we validate at the model level that an employer has at least one job?
    # if he adds a job, can't he delete his jobs till he has 0 jobs?
    @employer = Employer.new(params[:employer])
    # Since they are protected against mass assignment
    params[:employer][:password_confirmation] = params[:employer][:password]
    [:email, :password, :password_confirmation].each {|k| @employer.send("#{k}=", params[:employer][k]) if params[:employer] && params[:employer][k]}
    @employer.invitation = @invitation
    if @employer.save
      @employer.paying_till("31.Dec.2010".to_date) # TODO: remove when paying customers are enabled 
      flash[:notice] = t('flash.users.create.notice')
      redirect_to employer_path(@employer)
    else
      @job = @employer.jobs.first || @employer.jobs.build
      render :template => "employers/new"
    end
  end
  
  def show
    @vacancies = @employer.vacancies
  end
  
  def edit
    
  end
  
  def update
    if params[:form] == 'info_form'
      @employer.change_password(params[:employer][:old_password], params[:employer][:password])
      @employer.email = params[:employer][:email]
    end
    
    if params[:form] == 'delete_logo' && params[:employer][:delete_logo]
      @employer.logo.clear
      if @employer.save!
        @success = t('flash.users.update.notice')
      end
      respond_to do |format|
        format.js
      end
    elsif @employer.update_attributes(params[:employer])
      @success = t('flash.users.update.notice')
      if params[:form] == 'upload_logo'
        respond_to do |format|
          format.js
        end
      else
        flash[:notice] = @success
        redirect_to employer_path(@employer)
      end
    else
      respond_to do |format|
        format.html { render :template => "employers/edit" }
        format.js
      end
    end
  end
  
  def destroy
    @employer.destroy
    flash[:notice] = t('flash.users.destroy.notice')
    redirect_to(root_path)
  end
  
  [:block, :unblock].each do |m|
    define_method(m) do
      @employer.block_reason = params.nested_try_get(:employer, :block_reason)
      @employer.block_reason = nil if @employer.block_reason.blank? 
      @employer.send("#{m}!")
      respond_to do |format|
        format.js { render :template => "/employers/indvidual_action.rjs" }
      end
    end
    
    define_method("mass_#{m}") do
      @employers = Employer.send("mass_#{m}!", params[:ids])
      respond_to do |format|
        format.js { render :template => "/employers/mass_action.rjs" }
      end
    end
  end
  
  def request_unblock
    @employer.request_unblock!
    respond_to do |format|
      format.html { redirect_back_or edit_employer_path(@employer) }
    end
  end
  
  def paying
    unless @employer.paying_till params.nested_try_get(:employer, :paid_expiry_date)
      ajax_flash(:error, @employer.errors.full_messages.first)
      @paying_error = true
    end
    
    respond_to do |format|
      format.js { render :indvidual_action }
    end
  end
  
  def non_paying
    unless @employer.non_paying
      ajax_flash(:error, @employer.errors.full_messages.first)
    end
    
    respond_to do |format|
      format.js { render :indvidual_action }
    end  
  end
  
  #######
  private
  #######
  
  def ensure_invited
    @invitation = Invitation.unused.type_employer_or_ngo.find_by_code params[:ic]
    unless @invitation
      flash[:error] = t('flash.ensure_invited')
      redirect_back_or(root_path)      
    end
  end
  
  def find_employer
    @employer = Employer.find params[:id]
  end
  
  def ensure_employer_is_current_employer
    unless @employer.id == current_employer.id
      flash[:error] = t('flash.users.user_is_not_current_employer')
      redirect_back_or(employer_path(current_employer))
    end
  end
  end
