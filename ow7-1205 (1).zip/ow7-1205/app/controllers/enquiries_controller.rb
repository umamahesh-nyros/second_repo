class EnquiriesController < ApplicationController

  def create
    @enquiry = Enquiry.new(params[:enquiry])

    if @enquiry.valid? && @enquiry.send_email
      @success = t('flash.enquiry_sent')  
      @enquiry = Enquiry.new
    else
      @error = t('flash.enquiry_not_sent')
    end

    respond_to do |format|
      format.html do
        flash.now[:notice] = @success if @success
        flash.now[:error] = @error if @error
        render :template => "/welcome/contact"
      end
      format.js { ajax_flash(:notice, @success) }
    end

  end

end
