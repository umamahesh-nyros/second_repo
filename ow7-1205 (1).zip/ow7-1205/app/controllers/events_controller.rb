class EventsController < ApplicationController
  PER_PAGE = 5
  MANAGE_PER_PAGE = 10
  Publish = "Publish"
  SaveDraft = "Save Draft"
  Next = "Next"
  
  before_filter :find_show_event, :only => [:show]
  before_filter :require_admin_or_employer!, :only => [:new, :create, :edit, :update,
                                                      :manage, :destroy, :draft, :publish,
                                                      :mass_destroy, :mass_publish, :mass_draft]
  before_filter :find_edit_event, :only => [:edit, :update, :destroy, :publish, :draft]
  
  def index
    @events = Event.status_published
    if !params[:date].blank?
      #TODO check that params[:date] is a valid date before the conversion  
      @events = @events.start_time_lte(params[:date].to_date+1.day).end_time_gte(params[:date].to_date)
    elsif !params[:month].blank? && !params[:year].blank?
      @events = @events.month_year(params[:month], params[:year])
    end
    @events = @events.type_id_equals(params[:type_id].to_i) unless params[:type_id].blank?
    @events = @events.descend_by_start_time.paginate :page => params[:page], :per_page => PER_PAGE
    
    respond_to do |format|
      format.html
      format.js
    end
  end
  
  def manage
    @events = Event.scope_for(current_user).descend_by_created_at.paginate :page => params[:page], :per_page => MANAGE_PER_PAGE
  end
  
  def show
    
  end
  
  def new
    @event = Event.new
    @event.step = 1
    @event.start_time = Time.now
    @event.end_time = @event.start_time
  end
  
  def create
    @event = current_user.events.build(processed_event_params)
    @event.step = @event.step.to_i
    if @event.step == 1
      @event.step = 2 if @event.valid?
      render :action => :new
    else
      @event.status_id = params[:commit] == SaveDraft ? Event::Status[:draft].id : Event::Status[:published].id
      if @event.save
        redirect_to event_path(@event)
      else
        render :action => :new
      end
    end
  end
  
  def edit
    
  end
  
  def update
    new_status_id = @event.status_id
    unless @event.status_blocked?
      new_status_id = params[:commit] == SaveDraft ? Event::Status[:draft].id : Event::Status[:published].id
    end
    if @event.update_attributes(processed_event_params.merge({:status_id => new_status_id}))
      redirect_to event_path(@event)
    else
      render :action => :edit
    end
  end
  
  def destroy
    @event.destroy
    
    respond_to do |format|
      format.html { redirect_to events_path}
      format.js
    end
  end
  
  def publish
    if @event.make_status_published
      respond_to do |format|
        format.html { redirect_to event_path(@event) }
        format.js
      end
    end
  end
  
  def draft
    if @event.make_status_draft
      respond_to do |format|
        format.html { redirect_to event_path(@event) }
        format.js
      end
    end    
  end
  
  def mass_destroy
    Event.mass_destroy_for(current_user, params[:ids]) if params[:ids]
    
    respond_to do |format|
      format.html { redirect_to manage_events_path}
    end
  end
  
  def mass_publish
    Event.mass_publish_for(current_user, params[:ids]) if params[:ids]
    
    respond_to do |format|
      format.html { redirect_to manage_events_path}
    end
  end
  
  def mass_draft
    Event.mass_draft_for(current_user, params[:ids]) if params[:ids]
    
    respond_to do |format|
      format.html { redirect_to manage_events_path}
    end
  end
  
  #########
  protected
  #########
  
  def processed_event_params
    ps = params[:event].clone
    ps.delete(:start_date)
    ps.delete(:end_date)
    ps
  end
  
  def find_show_event
    @event = Event.find(params[:id])
    raise ActiveRecord::RecordNotFound unless @event.viewable_by?(current_user)
  end
  
  def find_edit_event
    @event = Event.find(params[:id])
    raise ActiveRecord::RecordNotFound unless @event.editable_by?(current_user)
  end
end
