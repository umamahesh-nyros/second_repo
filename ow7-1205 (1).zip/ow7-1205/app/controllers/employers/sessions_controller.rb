class Employers::SessionsController < ApplicationController
  before_filter :require_no_user, :only => [:new, :create]
  before_filter :require_employer, :only => :destroy
  skip_after_filter :write_flash_messages_to_cookies, :only => [:new, :create]
  
  def new
    @employer_session = EmployerSession.new
  end
  
  def create
    @employer_session = EmployerSession.new(params[:employer_session])
    if @employer_session.save
      path = if @employer_session.employer.blocked?
        edit_employer_path(@employer_session.employer)
      else
        employer_path(@employer_session.employer)
      end
      redirect_back_or_default(path)
    else
      render :action => :new
    end
  end
  
  def destroy
    current_employer_session.destroy
    redirect_to employers_login_url
  end
end
