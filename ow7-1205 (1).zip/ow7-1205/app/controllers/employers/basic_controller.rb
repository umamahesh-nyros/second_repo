class Employers::BasicController < ApplicationController
  before_filter :require_employer
end
