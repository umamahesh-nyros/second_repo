class Employers::PasswordResetsController < ApplicationController
  before_filter :require_no_employer
  before_filter :load_employer_using_perishable_token, :only => [:edit, :update]
  skip_after_filter :write_flash_messages_to_cookies, :only => [:edit, :update, :index, :create]
  
  def new
  end
  
  def create
    @employer = Employer.find_by_email(params[:email])
    if @employer
      @employer.deliver_password_reset_instructions!
      flash[:notice] = t('flash.password_resets.create.notice')
    else
      flash[:error] = t('flash.password_resets.create.no_user')
    end
    redirect_to employers_password_resets_path
  end
  
  def edit
  end
  
  def update
    @employer.password = params[:employer][:password]
    @employer.password_confirmation = params[:employer][:password_confirmation]
    if !params[:employer][:password].blank? && @employer.save
      flash[:notice] = t('flash.password_resets.update.notice')
      EmployerSession.create(@employer)
      redirect_to root_path
    else
      flash[:error] = @employer.errors.length > 0 ? @employer.errors.full_messages.first : t('flash.password_resets.update.error')
      redirect_to :action => :edit, :id => params[:id]
    end	
  end
  
  #######
  private
  #######
  
  def load_employer_using_perishable_token
    @employer = Employer.find_using_perishable_token(params[:id], 0)
    unless @employer
      flash[:error] = t('flash.password_resets.no_user_with_token')
      redirect_to employers_password_resets_path
    end
  end
end
