class ApplicationsController < ApplicationController
  before_filter :require_employer
  before_filter :find_vacancy
  before_filter :find_application, :except => [:index, :mass_short_list, :mass_unshort_list, :mass_reject, :mass_unreject]
  before_filter :filter_ids, :only => [:mass_short_list, :mass_unshort_list, :mass_reject, :mass_unreject]
  before_filter :ensure_employer_is_owner

  helper CandidatesHelper
  
  def index
    respond_to do |format|
      format.html do
        q = params[:q]
        page = params[:page] || 1
        per_page = params[:per_page] || 10

        @filter = q && q[:filter]
        if @filter && [:short_listed, :rejected].include?(@filter.to_sym)
          @applications = @vacancy.visible_applications.passed_screening.send(@filter).paginate :page => page, :per_page => per_page
        elsif
          @filter == 'inbox'
          all = @vacancy.visible_applications.passed_screening
          short_listed = @vacancy.visible_applications.passed_screening.send('short_listed')
          rejected = @vacancy.visible_applications.passed_screening.send('rejected')
          inbox = all - short_listed - rejected
          @applications = inbox.paginate :page => page, :per_page => per_page
        else
          @applications = @vacancy.visible_applications.passed_screening.paginate :page => page, :per_page => per_page
        end
        puts @filter
        @applications
      end


      format.js do
        q = params[:q]
        page = params[:page] || 1
        per_page = params[:per_page] || 10

        @filter = q && q[:filter]
        if @filter && [:short_listed, :rejected].include?(@filter.to_sym)
          @applications = @vacancy.visible_applications.passed_screening.send(@filter).paginate :page => page, :per_page => per_page
        elsif
          @filter == 'inbox'
          all = @vacancy.visible_applications.passed_screening
          short_listed = @vacancy.visible_applications.passed_screening.send('short_listed')
          rejected = @vacancy.visible_applications.passed_screening.send('rejected')
          inbox = all - short_listed - rejected
          @applications = inbox.paginate :page => page, :per_page => per_page
        else
          @applications = @vacancy.visible_applications.passed_screening.paginate :page => page, :per_page => per_page
        end

        params[:q] = {}.with_indifferent_access unless params[:q]
        @search = nil
        class_ids = params[:q][:degree_language_class_id]
        # TODO deal with other option
        unless (params[:q][:job_city_ids].nil?)
          params[:q][:job_city_ids] = params[:q][:job_city_ids] - ["-5"]
        end
        class_c_search = !class_ids.blank? && class_ids.first.to_i == Candidate::DegreeLanguageClasses[:ar]
        unless class_c_search
          @search = Candidate.filter_search(params[:q], current_user)
        end
        # similar to a inner join on 2 search results
        unless @applications.nil?
             candidate_ids = []
             @search.results.each do |c|
               candidate_ids << c.id
             end
             if candidate_ids.length > 0
               temp_apps = @applications.clone
               @applications.each do |a|
                 unless (candidate_ids.include? a.candidate_id)
                   temp_apps.delete a
                 end
               end
               @applications = temp_apps
             elsif candidate_ids.length == 0
               @applications = nil
             end
        end
        puts @filter
        @applications
      end
    end

  end
  
  [:short_list, :unshort_list, :reject, :unreject].each do |m|
    define_method(m) do
      @application.send(m)
      respond_to do |format|
        format.js { render(:update) {|p| p << "OW7.Jobs.Candidates.update();" } }
      end
    end
    
    define_method("mass_#{m}") do
      Vacancies::Application.send("mass_#{m}", params[:ids])
      respond_to do |format|
        format.js { render(:update) {|p| p << "OW7.Jobs.Candidates.update();" } }
        end
      end
    end

  protected
  
  def find_vacancy
    @vacancy = Vacancy.find_by_id params[:vacancy_id]
    unless @vacancy
      @error = t('flash.jobs.vacancy.not_found')
      respond_to do |format|
        format.html do
          flash[:error] = @error
          redirect_back_or(root_path)
        end
        format.js do
          ajax_flash(:error, @error)
          render :nothing => true
        end
      end
    end
  end
  
  def find_application
    @application = @vacancy.visible_applications.find_by_id params[:id]
    @application = nil if @application.for_paying_only? and not access_for_paying_only?
    unless @application
      @error = t('flash.jobs.vacancy.candidate.not_found')
      respond_to do |format|
        format.html do
          flash[:error] = @error
          redirect_back_or(root_path)
        end
        format.js do
          ajax_flash(:error, @error)
          render :nothing => true
        end
      end
    end
  end
  
  def ensure_employer_is_owner
    unless @vacancy.employer.id == current_employer.id
      flash[:error] = t('flash.users.user_is_not_current_employer')
      redirect_back_or(employer_path(current_employer))
    end
  end
  
  def filter_ids
    filter_for_paying_only_ids(Vacancies::Application)
  end

end
