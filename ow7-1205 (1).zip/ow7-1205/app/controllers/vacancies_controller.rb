class VacanciesController < ApplicationController
  before_filter :ensure_candidate, :only => [:apply]
  before_filter :require_admin, :only => [:heat, :unheat, :remove, :unremove, :clear_reports,
                                           :mass_heat, :mass_unheat, :mass_remove, :mass_unremove, :mass_clear_reports]
  before_filter :require_employer, :only => [:new, :edit, :create, :update, :destroy]
  before_filter :require_user, :only => [:sms]
  before_filter :find_vacancy, :except => [:new, :create, :mass_heat, :mass_unheat, 
                                           :mass_remove, :mass_unremove, :mass_clear_reports]
  before_filter :ensure_employer_is_owner, :only => [:edit, :update, :destroy]
  
  def show
    @job = @vacancy.job
    @employer = @job.employer
    @sms = TextMessage.new
    unless (!current_employer.nil? && @employer.id == current_employer.id)
      @vacancy.viewed
    end
  end
  
  def rate
    @vacancy.rate_it(params[:rating].to_i, candidate_logged_in? ? current_candidate.id : nil)
    respond_to do |format|
      format.html { redirect_to vacancy_path(@vacancy)}
      format.js
    end
  end
  
  def destroy
    if @vacancy.destroy_job_if_last
      @success = t('flash.jobs.vacancy.deleted')
    else
      @error = t('flash.jobs.vacancy.not_deleted')
    end
    
    respond_to do |format|
      format.html do
        if @success
          flash[:notice] = @success  
        else
          flash[:error] = @error
        end
        redirect_to employer_path(current_employer)
      end
      format.js
    end
  end
  
  def apply
    apply_for_vacancy(@vacancy)

    respond_to do |format|
      format.html do
        if @success
          flash[:notice] = @success  
        else
          flash[:error] = @error
        end
        redirect_to candidate_path(current_candidate)
      end
      format.js
    end    

  end

  def report
    if @vacancy.report
      @success = t('flash.jobs.vacancy.reported')
    else
      @error = t('flash.jobs.vacancy.not_reported')
    end
    
    respond_to do |format|
      format.js do
        ajax_flash(:notice, @success) if @success
        ajax_flash(:error, @error) if @error        
      end
    end

  end
  
  def sms
    #TODO: refactor the following (data / functionality) if sms is required elsewhere
    message = "#{current_user.try(:name) || current_user.try(:person_name)} has sent you the below job at #{@vacancy.job.employer.name}:\n#{@vacancy.job.title}\n For more information click #{vacancy_url(@vacancy)}"
    @sms = TextMessage.new(:numbers => params.nested_try_get(:sms, :numbers), :body => message)
    @success = t('flash.sms.sent') if @sms.save
  end
  
  [:heat, :unheat, :remove, :unremove, :clear_reports].each do |m|
    define_method(m) do
      if params[:reason]
        @vacancy.removal_reason = params[:reason]
      end
      @vacancy.send(m)
      respond_to do |format|
        format.js { render(:update) {|p| p << "OW7.Jobs.Search.update();" } }
      end
    end
    
    define_method("mass_#{m}") do
      Vacancy.send("mass_#{m}", params[:ids])
      respond_to do |format|
        format.js { render(:update) {|p| p << "OW7.Jobs.Search.update();" } }
      end
    end
  end
  
  
  #######
  private
  #######
  
  def no_vacancy_found
      @error = t('flash.jobs.vacancy.not_found')
      respond_to do |format|
        format.html do
          flash[:error] = @error
          redirect_back_or(root_path)
        end
        format.js do
          ajax_flash(:error, @error)
          render :nothing => true
        end
      end
  end

  def find_vacancy
    @vacancy = Vacancy.find_by_id params[:id], :include => {:job => [:employer]}
    @vacancy = nil if !@vacancy.try(:viewable_by?, current_user)
    unless @vacancy
      no_vacancy_found
    end    
  end
  
  def ensure_employer_is_owner
    unless @vacancy.job.employer.id == current_employer.id
      flash[:error] = t('flash.users.user_is_not_current_employer')
      redirect_back_or(employer_path(current_employer))
    end
  end
  
  def ensure_candidate
    if request.format.html?
      require_candidate
    elsif request.format.js?
      unless current_candidate
        session[:after_login] ||= {}
        session[:after_login][:apply_to] = params[:id].to_i
        
        render(:update) do |p|
          p << "window.location.href=\"#{candidates_login_path}\""
        end

        return false
      end
    end
  end
  
end
