class InvitationsController < ApplicationController
  before_filter :require_admin
  
  def index
    @invitations = Invitation.filter_search(params[:q], params[:page] || 1)
    @invitation = Invitation.new
    respond_to do |format|
      format.html
      format.js
    end
  end
  
  def create
    @invitation = Invitation.new(params[:invitation])
    @invitation.admin = current_admin
    if @invitation.save
      @success = t('flash.invitations.created')
      @invitation = Invitation.new
    else
      @error = @invitation.errors.full_messages.first
    end
    
    respond_to do |format|
      format.html do
        flash[:notice] = @success if @success
        redirect_to :action => :index
      end
      format.js
    end
  end
  
  
  def destroy
    @invitation = Invitation.find_by_id params[:id]
    if !@invitation
      @error = t('flash.invitations.not_found')
    elsif @invitation.destroy
      @success = t('flash.invitations.deleted')
    else
      @error ||= t('flash.invitations.not_deleted')
    end
    
    respond_to do |format|
      format.html do
        @success ? flash[:notice] = @success : flash[:error] = @error
        redirect_to :action => :index
      end
      format.js
    end
  end
  
end
