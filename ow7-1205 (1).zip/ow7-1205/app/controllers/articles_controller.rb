class ArticlesController < ApplicationController
  PER_PAGE = 5
  MANAGE_PER_PAGE = 10
  Publish = "Publish"
  SaveDraft = "Save Draft"
  
  before_filter :find_show_article, :only => [:show]
  before_filter :require_admin_or_employer!, :only => [:new, :create, :edit, :update,
                                           :manage, :destroy, :draft, :publish,
                                           :mass_destroy, :mass_publish, :mass_draft]
  before_filter :find_edit_article, :only => [:edit, :update, :destroy, :publish, :draft]
  
  def index
    @articles = Article.status_published.descend_by_published_at.paginate :page => params[:page], :per_page => PER_PAGE
  end
  
  def manage
    @articles = Article.scope_for(current_user).descend_by_created_at.paginate :page => params[:page], :per_page => MANAGE_PER_PAGE
  end
  
  def show
    
  end
  
  def new
    @article = Article.new
  end
  
  def create
    @article = current_user.articles.build(params[:article])
    @article.status_id = params[:commit] == SaveDraft ? Article::Status[:draft].id : Article::Status[:published].id 
    if @article.save
      redirect_to article_path(@article)
    else
      render :action => :new
    end
  end
  
  def edit
    
  end
  
  def update
    new_status_id = @article.status_id
    unless @article.status_blocked?
      new_status_id = params[:commit] == SaveDraft ? Article::Status[:draft].id : Article::Status[:published].id
    end
    if @article.update_attributes(params[:article].merge({:status_id => new_status_id}))
      redirect_to article_path(@article)
    else
      render :action => :edit
    end
  end
  
  def destroy
    @article.destroy
    
    respond_to do |format|
      format.html { redirect_to articles_path}
      format.js
    end
  end
  
  def publish
    if @article.make_status_published
      respond_to do |format|
        format.html { redirect_to article_path(@article) }
        format.js
      end
    end
  end
  
  def draft
    if @article.make_status_draft
      respond_to do |format|
        format.html { redirect_to article_path(@article) }
        format.js
      end
    end    
  end
  
  def mass_destroy
    Article.mass_destroy_for(current_user, params[:ids]) if params[:ids]
    
    respond_to do |format|
      format.html { redirect_to manage_articles_path}
    end
  end
  
  def mass_publish
    Article.mass_publish_for(current_user, params[:ids]) if params[:ids]
    
    respond_to do |format|
      format.html { redirect_to manage_articles_path}
    end
  end
  
  def mass_draft
    Article.mass_draft_for(current_user, params[:ids]) if params[:ids]
    
    respond_to do |format|
      format.html { redirect_to manage_articles_path}
    end
  end
  
  #########
  protected
  #########
  
  def find_show_article
    @article = Article.find(params[:id])
    raise ActiveRecord::RecordNotFound unless @article.viewable_by?(current_user)
  end
  
  def find_edit_article
    @article = Article.find(params[:id])
    raise ActiveRecord::RecordNotFound unless @article.editable_by?(current_user)
  end
end
