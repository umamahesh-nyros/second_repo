class WelcomeController < ApplicationController

  helper EnquiriesHelper
  
  def index
    @hot_jobs = Vacancy.filter_search({:hot => [true]}, :order_by => :random, :per_page => 4).results
  end
  
  def privacy
  end
  
  def terms
  end
  
  def about
  end
  
  def contact
    @enquiry = Enquiry.new
  end

  def update_profile
    if current_candidate.nil?
      @candidate =  Candidate.find_using_perishable_token(params[:token], 1.month)
      if @candidate
        @candidate.perishable_token = nil
        @candidate.save
        CandidateSession.create(@candidate)
        write_flash_messages_to_cookies
        redirect_to "/candidates/#{@candidate.id}/edit"
      else
        redirect_to candidates_login_url
      end
    else
      redirect_to "/candidates/#{current_candidate.id}/edit"
    end
  end
   
end
