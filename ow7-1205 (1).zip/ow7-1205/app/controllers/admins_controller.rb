class AdminsController < ApplicationController
  before_filter :require_admin
  before_filter :require_super_admin, :only => [:index, :new, :create, :destroy]
  before_filter :find_admin, :only => [:show, :edit, :update, :destroy]
  before_filter :ensure_admin_is_current_admin, :only => [:edit, :update, :show]
  before_filter :ensure_admin_is_not_current_admin, :only => [:destroy]
  before_filter :filter_params, :only => [:update]
  
  def index
    @admins = Admin.all.reject {|a| a.id == current_admin.id }
    @admin = Admin.new
  end
  
  def create
    @admin = Admin.new(params[:admin])
    # Since they are protected against mass assignment
    # Generate password
    @admin.email = params[:admin][:email] if params[:admin] && params[:admin][:email]
    if @admin.save
      @success = t('flash.users.create.notice')
      @admin = Admin.new
    else
      @error = @admin.errors.full_messages.first
    end
    
    respond_to do |format|
      format.html do
        flash[:notice] = @success if @success
        flash[:error] = @error if @error
        redirect_to :action => :index
      end
      format.js do
        ajax_flash(:notice, @success) if @success
      end
    end
  end
  
  def show
    
  end

  def edit
    
  end
  
  def update
    @admin.change_password(params[:admin][:old_password], params[:admin][:password])
    @admin.email = params[:admin][:email] if params[:admin][:email]
    if @admin.update_attributes(params[:admin])
      @success = t('flash.users.update.notice')
    else
      @error = t('flash.users.update.error')
    end
    
    if params[:edit_form]
      respond_to do |format|
        format.html do
          if @success
            flash[:notice] = @success
            redirect_to admins_home_path
          else
            render :edit
          end
        end
        format.js
      end      
    else
      respond_to do |format|
        format.html do
          if @success
            flash[:notice] = @success
            redirect_to admins_home_path
          else
            render :edit
          end
        end
        format.js { ajax_flash(:error, @error) if @error }
      end
    end
  end

  def destroy
    if @admin.destroy
      @success = t('flash.users.destroy.notice')
    else
      @error = t('flash.users.destroy.error')
    end

    respond_to do |format|
      format.html do
        flash[:notice] = @success if @success
        flash[:error] = @error if @error
        redirect_to :action => :index
      end
      format.js { ajax_flash(:error, @error) if @error }
    end
  end
  
  
  #######
  private
  #######

  def find_admin
    @admin = Admin.find_by_id params[:id]
    unless @admin
      filter_error(t('flash.users.user_not_found'))
    end
  end
  
  def ensure_admin_is_current_admin
    unless @admin.id == current_admin.id || current_admin.super?
      filter_error(t('flash.users.user_not_authorized'))
    end
  end

  def ensure_admin_is_not_current_admin
    if @admin.id == current_admin.id
      filter_error(t('flash.users.user_not_authorized'))
    end
  end
  
  def filter_params
    if params[:admin]
      params[:admin].delete(:super_admin) unless current_admin.super?
      unless current_admin.id == @admin.id
        params[:admin].delete(:old_password)
        params[:admin].delete(:password)        
      end
    end
  end
end
