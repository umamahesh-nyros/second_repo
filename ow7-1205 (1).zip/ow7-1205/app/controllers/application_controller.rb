# Filters added to this controller apply to all controllers in the application.
# Likewise, all the methods added will be available for all controllers.

class ApplicationController < ActionController::Base
  Flashes = [:notice, :error, :warning]
  DateFormats = Constants.new(:full => {:string => "yy-mm-dd", :regex => /\d{4}-\d{2}-\d{2}/},
                              :year_month => {:string => "yy-mm", :regex => /\d{4}-\d{2}/})
  helper ApplicationHelper
  helper JavascriptsHelper
  helper SeoHelper
  
  HTTP_STATUS = {:failure => 406}
  # make methods available to views
  helper_method :candidate_logged_in?, :current_candidate_session, :current_candidate,
                :employer_logged_in?, :current_employer_session, :current_employer,
                :admin_logged_in?, :current_admin_session, :current_admin,
                :logged_in?, :current_user, 
                :none_logged_in?, :date_for_input, :for_paying_only_filter
  helper CommentsHelper
  
  # See ActionController::RequestForgeryProtection for details
  protect_from_forgery
  
  # See ActionController::Base for details 
  # Uncomment this to filter the contents of submitted sensitive data parameters
  # from your application log (in this case, all fields with names like "password"). 
  filter_parameter_logging :password, :confirm_password, :password_confirmation
  
  before_filter :set_locale
  before_filter :candidate_should_complete_registration, :if => :candidate_logged_in?
  before_filter :handle_blocked_candidate
  before_filter :handle_blocked_employer
  after_filter :write_flash_messages_to_cookies
  
  def candidate_logged_in?
    !current_candidate_session.nil?
  end
  
  def employer_logged_in?
    !current_employer_session.nil?
  end
  
  def admin_logged_in?
    !current_admin_session.nil?
  end
  
  def none_logged_in?
    !candidate_logged_in? && !employer_logged_in? && !admin_logged_in?
  end
  
  def logged_in?
    candidate_logged_in? || employer_logged_in? || admin_logged_in?
  end
  
  def current_user
    current_candidate || current_employer || current_admin
  end
  
  def clear_non_admin_sessions
    [current_candidate_session, current_employer_session].each {|session| session.destroy if session}
  end

  #########
  protected
  #########
  def filter_error(error)
    respond_to do |format|
      format.html do
        flash[:error] = error
        redirect_back_or(root_path)
      end
      format.js do
        ajax_flash(:error, error)
        render :nothing => true
      end
    end  
  end

  def apply_after_login
    after_login = session[:after_login]
    vacancy_id = after_login[:apply_to] if after_login
    
    if vacancy_id
      vacancy = Vacancy.find_by_id(vacancy_id)

      if vacancy
        apply_for_vacancy(vacancy)
      else
        flash[:error] = t('flash.jobs.job_not_found')
      end
    end  
  end
  
  def goto_after_login
    after_login = session[:after_login]
    after_login ? after_login[:go_to] : nil
  end
  
  def candidate_after_login
    
    apply_after_login
    @go_to ||= goto_after_login
    
    session.delete :after_login

  end
  
  def apply_for_vacancy(vacancy)
    candidate = current_candidate || current_candidate(false)
    
    return if !candidate
    
    application_url = vacancy.application_url
    @go_to = application_url if application_url.present?
    return if @go_to
    
    begin
      vacancy.add_application!(candidate)
      @success = t('flash.jobs.vacancy.candidate.applied')
    rescue Exception => e
      @error = e.message == 'applied' ? t('flash.jobs.vacancy.candidate.already_applied') : t('flash.jobs.vacancy.candidate.not_applied')
    end
    
    if request.format.html?
      flash[:notice] = @success if @success
      flash[:error] = @error if @error
    end
  end
  
  #######
  private
  #######
  
  #before_filter
  def handle_blocked_employer
    redirect_to edit_employer_path(current_employer) if employer_logged_in? && current_employer.blocked? &&
    !(self.class == EmployersController && ["edit", "update", "request_unblock"].include?(action_name) ||
    self.class == Employers::SessionsController || self.class == AutocompleteController)
  end
  
  #before_filter
  def handle_blocked_candidate
    redirect_to edit_candidate_path(current_candidate) if candidate_logged_in? && current_candidate.blocked? &&
    !(self.class == CandidatesController && ["show", "edit", "update", "request_unblock"].include?(action_name) ||
    self.class == Candidates::SessionsController || self.class == AutocompleteController)
  end
  
  #before_filter
  def candidate_should_complete_registration
    if current_candidate.incomplete_registration?
      flash[:warning] = t('flash.complete_registration')
      redirect_to register_candidates_path
      write_flash_messages_to_cookies
    end
  end
  
  def current_candidate_session(cached = true)
    return @current_candidate_session if defined?(@current_candidate_session) and cached
    @current_candidate_session = CandidateSession.find
  end
  
  def current_candidate(cached = true)
    return @current_candidate if defined?(@current_candidate) and cached
    session = current_candidate_session(cached)
    @current_candidate = session && session.candidate
  end
  
  def require_candidate_silently
    require_candidate(true)
  end
  
  def require_candidate(silent = false)
    unless current_candidate
      store_location
      flash[:error] = t('flash.require_user') unless silent
      redirect_to candidates_login_path
    end
  end
  
  def require_no_candidate_silently
    require_no_candidate(true)
  end
  
  def require_no_candidate(silent = false)
    logout_required(silent) if current_candidate
  end
  
  def current_employer_session
    return @current_employer_session if defined?(@current_employer_session)
    @current_employer_session =EmployerSession.find
  end
  
  def current_employer
    return @current_employer if defined?(@current_employer)
    @current_employer = current_employer_session && current_employer_session.employer
  end

 
  def for_paying_only_filter(candidate)
    candidate.for_paying_only? ? (yield if access_for_paying_only?) : yield
  end

  def access_for_paying_only?
    return @access_for_paying_only if defined?(@access_for_paying_only)
    @access_for_paying_only = !!(current_admin || (current_employer && current_employer.paying?))
  end

  
  def require_employer_silently
    require_employer(true)
  end
  
  def require_employer(silent = false)
    unless current_employer
      store_location
      flash[:error] = t('flash.require_user') unless silent
      redirect_to employers_login_path
    end
  end
  
  def require_no_employer_silently
    require_no_employer(true)
  end
  
  def require_no_employer(silent = false)
    logout_required(silent) if current_employer
  end
  
  
  def current_admin_session
    return @current_admin_session if defined?(@current_admin_session)
    @current_admin_session =AdminSession.find
  end
  
  def current_admin
    return @current_admin if defined?(@current_admin)
    @current_admin = current_admin_session && current_admin_session.admin
  end
  
  def require_admin_silently
    require_admin(true)
  end
  
  def require_admin(silent = false)
    unless current_admin
      store_location
      flash[:error] = t('flash.require_user') unless silent
      redirect_to admins_login_path
    end
  end
  
  def require_super_admin(silent = false)
    if !current_admin
      require_admin(silent)
    elsif !current_admin.super?
      store_location
      flash[:error] = t('flash.users.user_not_authorized') unless silent
      redirect_to root_path
    end
  end
  
  def require_no_admin_silently
    require_no_admin(true)
  end
  
  def require_no_admin(silent = false)
    logout_required(silent) if current_admin
  end
  
  def store_location
    session[:return_to] = session[:return_to].nil? ? request.request_uri : nil
  end
  
  def redirect_back_or_default(default)
    redirection = session[:return_to] || default
    session[:return_to] = nil
    redirect_to(redirection)
  end
  
  def redirect_back_or(path)
    redirect_to(request.env["HTTP_REFERER"] || path)
  end
  
  # before_filter
  def require_admin_or_employer!
    if ![Admin, Employer].include?(current_user.class)
      raise ActiveRecord::RecordNotFound, "Admin or Employer expected but got #{current_user.class}"
    end
  end
  
  # before_filter
  def require_admin!
    raise ActiveRecord::RecordNotFound unless [Admin].include?(current_user.class)
  end
  
  def require_user
    if !logged_in?
      @error = t('flash.users.user_not_authorized')
      respond_to do |f|
        f.html do
          flash[:error] = @error
          redirect_back_or_default root_path
        end
        f.js do
          ajax_flash(:error, @error)
          render :nothing => true
        end
      end
    end
  end
  
  def logout_required(silent = false)
    @error = t('flash.require_no_user')
    respond_to do |f|
      f.html do
        store_location
        flash[:error] = @error unless silent
        redirect_to root_path
      end
      f.js do
        ajax_flash(:error, @error)
        render :nothing => true
      end
    end
  end
  
  def require_no_user
    logout_required if logged_in?
  end
  
  def set_locale
    I18n.locale = :en
  end
  
  # NOTE since this is an after_filter, if a before_filter halts,
  # this method has to be called explicitly in that before_filter
  # before_filters that redirect shouldn't have this issue, only
  # ones which render directly as is the case with filters that
  # intercept ajax requests
  def write_flash_messages_to_cookies
    Flashes.each do |f|
      if flash[f]
        cookies["flash_#{f}"] = flash[f]
        break
      end
    end
  end
  
  def ajax_flash(name, value)
    flash.now[name] = value
    write_flash_messages_to_cookies
  end
  
  def date_for_input(date, format)
    date.try(:to_s, :db).try(:match, ApplicationController::DateFormats.find_by_sym_id(format.to_sym).regex).try(:[],0)
  end
  
  def filter_for_paying_only_ids(klass)
    unless access_for_paying_only?
      for_paying_only_ids = klass.all(:conditions => {:id => params[:ids]}).select(&:for_paying_only?).collect &:id
      for_paying_only_ids_params = for_paying_only_ids.collect &:to_s
      params[:ids] = params[:ids] - for_paying_only_ids - for_paying_only_ids_params
    end  
  end

end
