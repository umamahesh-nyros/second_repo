class ArabicCandidatesController < ApplicationController
  before_filter :require_no_user
  
  def new
    @arabic_candidate = ArabicCandidate.new
  end
  
  def create
    @arabic_candidate = ArabicCandidate.new(params[:arabic_candidate])
    if @arabic_candidate.save
      respond_to do |format|
        format.html do
          flash[:notice] = 
          redirect_to root_path
        end
      end
    else
      render :template => "/arabic_candidates/new"
    end
  end
  
  #########
  protected
  #########
  
  def set_locale
    I18n.locale = :ar
  end
end
