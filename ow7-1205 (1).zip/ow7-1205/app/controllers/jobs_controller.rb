class JobsController < ApplicationController
  before_filter :require_employer, :except => [:show, :index]
  before_filter :find_job, :only => [:show, :edit, :update, :destroy]
  before_filter :ensure_employer_is_owner, :only => [:edit, :update]
  
  helper EmployersHelper
  
  def index
    respond_to do |format|
      format.html {
        @city_id = (params[:q] && params[:q][:city_id].collect(&:to_i)) || []
        results = []
        @city_id.each do |id|
          if id == -1
            results << City.find_by_name("Riyadh").id
          elsif id == -2
            results << City.find_by_name("Jeddah").id
          elsif id == -3
            City.all(:conditions => ["name in (?)",
                ['Khobar','Dhahran','Dammam','Qatif','Jubail']]).each do |c|
              results << c.id
            end
          elsif id == -4
            country_id = Country.find_by_name("SAUDI ARABIA").id
            City.find_by_sql("select distinct c.id from cities c inner join vacancies v on v.city_id = c.id
              where c.country_id != #{country_id}").each do |c|
              results << c.id
            end
          elsif id == -5
            if params[:q][:ac_city_id]
              params[:q][:ac_city_id].collect(&:to_i).each do |ac_id|
                results << ac_id
              end
            end
          end
        end
        results.each do |id|
          @city_id << id
        end
      }
      format.js {
        if params[:q]
          # deal with composition type for Full time job and Graduate Programs
          composite_type = Jobs::Type.array_of(:full_time, :graduate_program)
          ct_id =  composite_type.collect {|t| t.id}.join(",")
          if params[:q][:type_id].to_s == ct_id
            params[:q][:type_id] = [composite_type[0].id, composite_type[1].id]
          end
          # deal with city groups
          if params[:q][:city_id]
            city_ids = params[:q][:city_id].join(',')
            params[:q][:city_id] = []
            city_ids.split(',').each do |c|
              params[:q][:city_id] << c
            end
          end
          @duration = Time.now
          @search = Vacancy.filter_search(params[:q], :filter => params[:filter], :user => current_user, :page => params[:page] || 1)
          @duration = (Time.now - @duration).round(3)
        end
      }
    end
  end
  
  def new
    @job = current_employer.jobs.build
  end
  
  def create
    if current_employer.update_attributes(params[:employer])
      section_ids = []
      section_ids = params[:section_ids] unless params[:section_ids].nil?
      sections = Section.find(:all, :conditions => {:id => section_ids})
      @job = current_employer.jobs.last
      @job.sections = sections
      @job.save
      flash[:notice] = t('flash.jobs.create.notice')
      redirect_to employer_path(current_employer)
    else
      @job = current_employer.jobs.select {|j| j.new_record? }.first
      render :template => "jobs/new"
    end
  end
  
  def edit
  end
  
  def update
    if current_employer.update_attributes(params[:employer])
      section_ids = []
      section_ids = params[:section_ids] unless params[:section_ids].nil?
      sections = Section.find(:all, :conditions => {:id => section_ids})
      if @job
        @job.sections = sections
      end
      @job.save
      flash[:notice] = t('flash.jobs.edit.notice')
      redirect_to employer_path(current_employer)
    else
      @job = current_employer.jobs.select {|j| j.id == params[:id].to_i}.first
      render :template => "jobs/edit"
    end
  end
  
  #--Before filters--#
  def find_job
    @job = Job.find_by_id params[:id]
    unless @job
      flash[:error] = t('flash.jobs.job_not_found')
      redirect_back_or(root_path)
    end
  end
  
  def ensure_employer_is_owner
    unless @job.employer.id == current_employer.id
      flash[:error] = t('flash.users.user_is_not_current_employer')
      redirect_back_or(employer_path(current_employer))
    end
  end
  
end
