# NOTE: for an overview of how interviews work, check the doc folder for the file
# README_FOR_INTERVIEWS
class Interviews::Slot < ActiveRecord::Base
  set_table_name 'interviews_slots'
  # NOTE if you change the value for :open, update the migration
  # for creatings slots
  Status = Constants.new(:open => {:id => 0, :name => "Open"},
                         :booked => {:id => 1, :name => "Booked"})
  #--Attributes--#
  attr_accessor :time_date
  attr_accessor :time_hour
  attr_accessor :time_minute
  attr_accessor :time_ampm
  
  #--Validations--#
  validates_presence_of :interview_id
  validates_time :time, :after => lambda {|s| Time.now}, :if => lambda {|s| s.time_changed?}
  validate :time_greater_than_confirmation_deadline
  
  #--Associations--#
  belongs_to :interview, :class_name => "Interviews::Interview", :foreign_key => "interview_id"
  #NOTE :dependent is maintained by hand in remove_slot_from_connection callback
  has_one :interview_connection, :class_name => "Interviews::Connection", :foreign_key => "slot_id"
  has_one :candidate, :through => :interview_connection
  
  #--Named Scopes--#
  Status.all.each do |s|
    named_scope "status_#{s.sym_id}", :conditions => {:status_id => s.id}
  end
  
  #--Callbacks--#
  before_validation :construct_time_from_parts
  after_save :set_interview_connection_time
  before_destroy :remove_slot_from_connection
  #  
  #--Instance Methods--#
  Status.all.each do |s|
    define_method("status_#{s.sym_id}?") { self.status_id == s.id }
    define_method("status_#{s.sym_id}!") { self.status_id = s.id; self.save! }
  end
  
  def status
    Status.find_by_id self.status_id
  end
  
  # before_validation
  def construct_time_from_parts
    parts_not_blank = [self.time_date, self.time_hour, self.time_minute, self.time_ampm].inject(true) {|acc, v| acc && !v.blank? } 
    if parts_not_blank
      self.time = ActiveSupport::TimeZone.new('UTC').parse "#{self.time_date} #{self.time_hour}:#{self.time_minute}#{self.time_ampm}"
    end
    true
  end
  
  # validate
  def time_greater_than_confirmation_deadline
    if self.time_changed? && self.time && self.interview && self.interview.confirmation_deadline
      self.errors.add(:time, I18n.t('activerecord.errors.models.interviews/slot.after_deadline')) if self.time.to_date < self.interview.confirmation_deadline
    end
  end
  
  def time_date
    @time_date||=self.time.try(:to_date).try(:to_s, :db)
  end
  
  def time_hour
    @time_hour||=self.time.try(:strftime, "%I")
  end
  
  def time_minute
    @time_minute||=self.time.try(:strftime, "%M")
  end
  
  def time_ampm
    @time_ampm||=self.time.try(:strftime, "%p")
  end
  
  #########
  protected
  #########
  
  # after_save
  def set_interview_connection_time
    Interviews::Connection.update_all "time = '#{self.time.to_s(:db)}'", "slot_id = #{self.id}"
    true
  end
  
  # before_destroy
  def remove_slot_from_connection
    self.try(:interview_connection).try(:remove_slot!, false)
    true
  end
end
