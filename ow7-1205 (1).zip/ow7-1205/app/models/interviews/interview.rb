# NOTE: for an overview of how interviews work, check the doc folder for the file
# README_FOR_INTERVIEWS
class Interviews::Interview < ActiveRecord::Base
  set_table_name 'interviews'
  
  #--Attributes--#
  attr_protected :employer_id
  
  # For use during creation only, used to create appropriate slots
  attr_accessor :start_time
  attr_accessor :start_time_date
  attr_accessor :start_time_hour
  attr_accessor :start_time_minute
  attr_accessor :start_time_ampm
  attr_accessor :slot_count
  attr_accessor :fake_slots
  
  #--Validations--#
  validates_presence_of :employer_id
  validates_presence_of :vacancy_id
  validates_presence_of :city_id
  validates_presence_of :location
  validates_presence_of :contact_person
  validates_presence_of :contact_phone
  validate Proc.new {|record| Validator.phone_format_of(record, :contact_phone)}
  validates_format_of :contact_email, :with =>  Authlogic::Regex.email, :message => I18n.t('activerecord.errors.messages.invalid_email')
  validates_numericality_of :duration, :greater_than_or_equal_to => 10 #minutes
  validate :slots_validations
  # NOTE the following validation depends on the previous validation
  # so their order should not be changed
  validates_date :confirmation_deadline,
               :before => lambda {|r| if r.new_record? && r.start_time
                                        r.start_time.to_date + 1
                                      elsif r.slots.count > 0
                                        r.slots.ascend_by_time.first.time.to_date + 1
                                      else # a strange case, so let's just put a distant future date
                                        Date.today+5.years
                                      end
               },
               :after => lambda {|r| if r.new_record?
                                       Date.today
                                     else # a strange case, so let's just put a distant past date
                                       Date.today-5.years
                                     end
               },
               :if => lambda {|r| (r.new_record? && !r.errors.invalid?(:start_time)) || 
                                  (!r.new_record? && r.confirmation_deadline_changed?)}
  
  #--Associations--#
  belongs_to :employer
  belongs_to :vacancy
  belongs_to :city
  has_many :slots, :class_name => "Interviews::Slot", :foreign_key => "interview_id", :dependent => :delete_all
  accepts_nested_attributes_for :slots, :allow_destroy => true,
                                :reject_if => lambda {|attrs| !(attrs[:time_date] =~ /\d\d\d\d-\d\d-\d\d/ && attrs[:time_hour] =~ /\d\d/) && attrs[:time_minute] =~ /\d\d/}
  has_many :connections, :class_name => "Interviews::Connection", :foreign_key => "interview_id", :dependent => :delete_all
  accepts_nested_attributes_for :connections, :allow_destroy => true
  has_many :candidates, :through => :connections, :source => :candidate
  
  #--Callbacks--#
  before_validation :set_some_defaults
  before_validation_on_create :set_connections_interview
  before_validation :set_slots_interview
  before_validation :prepare_slot_attributes
  after_save :process_slot_attributes
  
  #--Instance Methods--#
  def title(format = :long)
    t = "#{self.city.name} interview"
    if format == :long
      t = "#{self.vacancy.full_title} - #{t}" 
    end
    t
  end
  
  def build_connections_for_ids(ids)
    ids = Array(ids).reject {|i| i.blank? }.collect {|i| i.to_i}
    return if ids.length == 0
    new_user_ids = ids - self.candidate_ids
    ids.collect {|i| self.connections.build :candidate_id => i}
  end
  
  def new_connections
    self.connections.select {|c| c.new_record? }
  end
  
  def start_time_date
    @start_time_date||=self.start_time.try(:to_date).try(:to_s, :db)
  end
  
  def start_time_hour
    @start_time_hour||=self.start_time.try(:strftime, "%I")
  end
  
  def start_time_minute
    @start_time_minute||=self.start_time.try(:strftime, "%M")
  end
  
  def start_time_ampm
    @start_time_ampm||=self.start_time.try(:strftime, "%p")
  end
  
  def slots_for_view
    if self.fake_slots
      fake_the_slots(:build) || []
    else
      self.slots.select {|s| !s.marked_for_destruction? || s.new_record?}
    end
  end
  
  def open?
    #NOTE: keep this condition in sync with Interviews::Connection#with_open_interview named scope
    self.confirmation_deadline >= Date.today  
  end
  
  #########
  protected
  #########
  
  # before_validation
  def set_some_defaults
    self.employer_id = self.vacancy.employer_id if self.vacancy_id_changed? && self.vacancy
    [:fake_slots].each do |attr|
      v = self.send(attr)
      self.send("#{attr}=", !!(v =~ /(yes|1|true)/)) if !v.blank? && ![TrueClass, FalseClass].include?(v.class) 
    end
    true
  end
  
  # before_validation_on_create
  def set_connections_interview
    self.connections.each {|c| c.interview = self}
  end
  
  # before_validation
  def set_slots_interview
    self.slots.each {|s| s.interview = self}
  end
  
  # before validation
  def prepare_slot_attributes
    if self.fake_slots
      begin
        if self.start_time.is_a?(String) && !self.start_time.blank?
          self.start_time = ActiveSupport::TimeZone.new('UTC').parse self.start_time
          # if all params are there
        elsif [self.start_time_date, self.start_time_hour, self.start_time_minute, self.start_time_ampm].inject(true) {|acc, v| acc && !v.blank? }
          self.start_time = ActiveSupport::TimeZone.new('UTC').parse "#{self.start_time_date} #{self.start_time_hour}:#{self.start_time_minute}#{self.start_time_ampm}"
        end
      rescue Exception => e
        self.start_time = nil
      end
      self.slot_count = self.slot_count.to_i unless self.slot_count.blank?
    end
  end
  
  # validate
  def slots_validations
    if self.fake_slots
      # Minutes numericality
      self.errors.add(:slot_count, I18n.t('activerecord.errors.messages')[:not_a_number]) unless self.slot_count.is_a?(Fixnum)
      self.errors.add(:slot_count, I18n.t("activerecord.errors.models.interviews_interview.no_slots")) if !self.errors.invalid?(:slot_count) && self.slot_count == 0
      
      # Start Time is a time after now
      self.errors.add(:start_time, I18n.t("activerecord.errors.models.interviews_interview.invalid_time")) unless self.start_time.is_a?(Time)
      if !self.errors.invalid?(:start_time)
        self.errors.add(:start_time, I18n.t("activerecord.errors.models.interviews_interview.future_time")) if self.start_time.past?
      end
      
      # Slots fit in the day?
      unless self.errors.invalid?(:start_time) || self.errors.invalid?(:slot_count) || self.errors.invalid?(:duration)
        # if interviews end time is greater than the start_time end of day
        if (self.start_time + self.slot_count * self.duration.minutes) > self.start_time.midnight + 1.day 
          self.errors.add_to_base I18n.t("activerecord.errors.interviews_interview.slots_dont_fit")
        end
      end
    end
  end
  
  # after_save
  def process_slot_attributes
    # This method should always build slots that are valid
    fake_the_slots(:create!)
  end
  
  def fake_the_slots(m)
    if self.fake_slots
      allowed_methods = [:create!, :build]
      raise ArgumentError, "m should be from the values #{allowed_methods.inspect}" unless allowed_methods.include?(m)
      if [:start_time, :slot_count, :duration].inject(true) {|acc, v| acc && !self.errors.invalid?(:start_time)}
        fs = []
        self.slot_count.times {|i| fs << self.slots.send(m, :time => (self.start_time + i * duration.minutes))}
        fs
      end
    end
  end
end
