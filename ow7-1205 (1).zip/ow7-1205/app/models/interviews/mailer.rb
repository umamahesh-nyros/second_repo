class Interviews::Mailer < ActionMailer::Base
  layout 'email'
  include ApplicationHelper
  helper ApplicationHelper
  
  def invitation(connection)
    setup_email
    subject       I18n.t('email.candidates.interviews.invitation.subject')
    recipients    connection.candidate.email
    body          :connection => connection
  end
  
  def assign_slot(connection, old_slot)
    setup_email
    subject       I18n.t('email.candidates.interviews.assign_slot.subject')
    recipients    connection.candidate.email
    body          :connection => connection, :old_slot => old_slot
  end
  
  def cancellation(connection)
    setup_email
    subject       I18n.t('email.candidates.interviews.cancellation.subject')
    recipients    connection.candidate.email
    body          :connection => connection
  end
  
  def deadline_confirmation(connection)
    setup_email
    subject       I18n.t('email.candidates.interviews.deadline_confirmation.subject')
    recipients    connection.candidate.email
    body          :connection => connection
  end
  
  def reminder(connection, hours)
    setup_email
    subject       I18n.t('email.candidates.interviews.reminder.subject')
    recipients    connection.candidate.email
    body          :connection => connection, :hours => hours
  end
  
  def setup_email
    content_type "text/html"
    from AppConfig.from_no_reply
    sent_on Time.now
  end
end
