# NOTE: for an overview of how interviews work, check the doc folder for the file
# README_FOR_INTERVIEWS
class Interviews::Connection < ActiveRecord::Base
  set_table_name 'interviews_connections'
  # NOTE if you change the value for :visible, update the migration
  # for creating connections
  Status = Constants.new({:visible => {:id => 0}, :hidden => {:id => 1}})
  
  #--Attributes--#
  attr_protected :interview_id, :status_id, :slot_id, :time
  
  #--Validations--#
  validate :presence_of_interview
  validates_presence_of :candidate_id
  validate :candidate_allowed
  validates_uniqueness_of :candidate_id, :scope => :interview_id, :message => I18n.t('activerecord.errors.models.interviews/connection.already_invited')
  validate_on_create :for_paying_only_conditions
  
  #--Associations--#
  belongs_to :interview, :class_name => "Interviews::Interview", :foreign_key => "interview_id"
  has_one :vacancy, :through => :interview
  has_one :employer, :through => :interview
  belongs_to :candidate
  belongs_to :slot, :class_name => "Interviews::Slot", :foreign_key => "slot_id"
  
  #--Named Scopes--#
  Status.all.each do |s|
    named_scope "status_#{s.sym_id}", :conditions => {:status_id => s.id}
  end
  named_scope :with_slot, :conditions => "slot_id is not null"
  named_scope :without_slot, :conditions => "slot_id is null"
  named_scope :with_open_interview, lambda {
    #NOTE: keep this condition in sync with Interviews::Interview#open?
    {:joins => :interview, :conditions => "interviews.confirmation_deadline >= '#{Date.today.to_s(:db)}'"}
  }
  named_scope :with_active_employer,
  #:joins => :employer, this was not used because it generates a wrong sql
              :select => "#{self.table_name}.*",
              :from => "#{self.table_name} INNER JOIN #{Interviews::Interview.table_name} ON (#{Interviews::Interview.table_name}.id = #{Interviews::Connection.table_name}.interview_id)"+
                       " INNER JOIN #{Employer.table_name} ON (#{Employer.table_name}.id=#{Interviews::Interview.table_name}.employer_id)",
              :conditions => "#{Employer.table_name}.status_id=#{Employer::Status[:active].id}"
  named_scope :with_active_candidate,
              :joins => :candidate,
              :conditions => "#{Candidate.table_name}.status_id not in (#{Candidate::Status[:blocked]},#{Candidate::Status[:unblock_requested]})"
  
  #--Callbacks--#
  after_create :deliver_invitation
  after_create :deliver_invitation_sms, :if => lambda {|c| c.candidate.can_receive_sms? }
  
  #--Class Methods--#
  def self.deliver_deadline_confirmations(date = Date.yesterday)
    Interviews::Interview.confirmation_deadline_equals(date).find_each do |i|
      i.connections.status_visible.with_slot.each {|c| c.deliver_deadline_confirmation}
    end
  end
  
  def self.deliver_reminders(hours)
    #beginning of this hour
    time = Time.parse(Time.now.utc.to_s(:db).gsub(/:\d\d:\d\d$/, ":00:00 UTC"))+hours.hours
    self.time_greater_than_or_equal_to(time).time_less_than(time+1.hour).find_each do |c|
      c.deliver_reminder(hours)
      c.deliver_reminder_sms(hours) if c.candidate.can_receive_sms?
    end
  end
  
  #--Instance Methods--#
  Status.all.each do |s|
    define_method("status_#{s.sym_id}?") { self.status_id == s.id }
  end
  
  def status
    Status.find_by_id self.status_id
  end
  
  def with_slot?
    !self.slot_id.blank?
  end
  
  def without_slot?
    !with_slot?
  end
  
  def remove_slot!(update_slot = true)
    unless self.slot_id.blank?
      self.class.transaction do
        Interviews::Slot.update_all("status_id=#{Interviews::Slot::Status[:open].id}", "id=#{self.slot_id}") if update_slot
        self.class.update_all "slot_id=NULL, time=NULL", "id=#{self.id}"
        self.reload
        Interviews::Mailer.deliver_cancellation(self)
      end
    end
  end
  
  def assign_slot!(new_slot)
    raise ArgumentError, "Slot is not open" unless new_slot.status_open?
    raise ArgumentError, "Slot doesn't belong to interview" unless new_slot.interview_id == self.interview_id
    
    old_slot = self.slot
    self.slot = new_slot
    self.class.transaction do
      self.time = self.slot.time
      self.save!
      old_slot.status_open! if old_slot
      self.slot.status_booked!
      Interviews::Mailer.deliver_assign_slot(self, old_slot)
    end
  end
  
  # after_create
  def deliver_invitation
    Interviews::Mailer.deliver_invitation(self)
    true
  end
  
  # after_create
  def deliver_invitation_sms
    TextMessage.send_message([self.candidate.residence_phone],
                               "Dear #{candidate.first_name}, congratulations, "+
                               "you have been short-listed for an interview with #{employer.name}. "+
                               "Login at www.oilwell7.com for more details")
    true
  end
  
  def deliver_deadline_confirmation
    Interviews::Mailer.deliver_deadline_confirmation(self)
  end
  
  def deliver_reminder(hours)
    Interviews::Mailer.deliver_reminder(self, hours)
  end
  
  def deliver_reminder_sms(hours)
    TextMessage.send_message([self.candidate.residence_phone],
                              "Dear #{candidate.first_name}, this is a reminder that you "+
                              "have an interview with #{employer.name} in #{hours} hours. "+
                              "Login at www.oilwell7.com for more details")
  end
  
  #########
  protected
  #########
  
  # validate
  def presence_of_interview
    self.errors.add(:interview_id, I18n.translate('activerecord.errors.messages')[:blank]) if self.interview.blank? && self.interview_id.blank?
  end
  
  # validate
  def candidate_allowed
    # validates that this candidate already applied to the job (has an application)
    if self.candidate_id_changed? && !self.errors.invalid?(:candidate_id)
      v = self.new_record? ? self.interview.vacancy : self.vacancy
      self.errors.add(:candidate_id, I18n.t('activerecord.errors.models.interviews/connection.no_application')) unless v.candidate_ids.include?(self.candidate_id)
    end
  end
  
  # validate_on_create
  def for_paying_only_conditions
    if self.candidate_id && !self.errors.invalid?(:candidate_id)
      self.errors.add_to_base(I18n.t('activerecord.errors.models.interviews/connection.for_paying_only')) if self.candidate.for_paying_only? && !self.interview.employer.paying?
    end
  end
end
