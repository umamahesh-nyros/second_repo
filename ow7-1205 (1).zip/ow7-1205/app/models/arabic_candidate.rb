class ArabicCandidate < ActiveRecord::Base
  validates_presence_of :name
  validates_format_of :email, :with => Authlogic::Regex.email
  
  has_attached_file :cv,
                    :path => ":rails_root/public/candidates/:attachment/ac:id.:extension",
                    :url => "/candidates/:attachment/ac:id.:extension"
  validates_attachment_size :cv, :less_than => 1.megabytes
  validates_attachment_presence :cv, :message => I18n.translate('activerecord.errors.messages')[:blank]
  
  #TODO cv content types
  #validates_attachment_content_type :cv, :content_type => ['application/pdf', 'image/jpeg', 'image/pjpeg', 'image/gif', 'image/png', 'image/x-png', 'image/jpg']
end
