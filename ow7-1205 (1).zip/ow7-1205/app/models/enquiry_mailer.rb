class EnquiryMailer < ActionMailer::Base
  layout 'email'
  helper ApplicationHelper
  
  def contact_us_enquiry(enquiry)
    setup_email
    subject I18n.t('email.contact_us_enquiry.subject')
    from I18n.t('email.contact_us_enquiry.from')
    recipients ["#{AppConfig.contact_us}"]
    body :enquiry => enquiry
  end
  
  def setup_email
    content_type "text/html"
    sent_on Time.now
  end
end
