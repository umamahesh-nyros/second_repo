class CandidateMailer < ActionMailer::Base
  layout 'email'
  
  def welcome(candidate)
    setup_email
    subject       I18n.t('email.candidates.welcome.subject')
    recipients    candidate.email
    body          :candidate => candidate
  end
  
  def password_reset_instructions(candidate)
    setup_email
    subject       I18n.t('email.candidates.password_reset_instructions.subject')
    recipients    candidate.email
    body          :password_reset_url => edit_candidates_password_reset_url(candidate.perishable_token), :candidate => candidate
  end
  
  
  def block_notification(candidate)
    setup_email
    subject       I18n.t('email.candidates.block_notification.subject')
    recipients    candidate.email
    body          :candidate => candidate
  end
  
  def unblock_notification(candidate)
    setup_email
    subject       I18n.t('email.candidates.unblock_notification.subject')
    recipients    candidate.email
    body          :candidate => candidate
  end
  
  def old_notification(candidate)
    setup_email
    subject       I18n.t('email.candidates.old_notification.subject')
    recipients    candidate.email
    body          :candidate => candidate
  end

  def edit(candidate)
    setup_email
    subject       I18n.t('email.candidates.edit.subject')
    recipients    candidate.email
    body          :candidate => candidate
  end
  
  def setup_email
    content_type "text/html"
    from AppConfig.from_no_reply
    sent_on Time.now
  end
end
