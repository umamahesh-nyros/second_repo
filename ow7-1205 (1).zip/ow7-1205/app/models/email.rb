class Email < ActiveRecord::Base
end
