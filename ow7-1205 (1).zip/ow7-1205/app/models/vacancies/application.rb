class Vacancies::Application < ActiveRecord::Base
  set_table_name :applications
  
  Status = Constants.new({:visible => {:id => 0}, :hidden => {:id => 1}})
  
  #--Attributes--#
  attr_protected :job_id, :short_listed, :screening, :rejected
  
  #--Validations--#
  validates_presence_of :candidate_id
  validates_presence_of :vacancy_id
  
  #--Associations--#
  belongs_to :candidate
  belongs_to :vacancy
  belongs_to :job
  
  #--Named Scopes--#
  Status.all.each do |s|
    named_scope "status_#{s.sym_id}", :conditions => {:status_id => s.id}
  end
  
  named_scope :short_listed, :conditions => {:short_listed => true}
  named_scope :rejected, :conditions => {:rejected => true}
  named_scope :passed_screening, :conditions => {:screening => true}
  
  #--Instance Methods--#
  Status.all.each do |s|
    define_method("status_#{s.sym_id}?") { self.status_id == s.id}
  end

  # application should be either short listed or rejected, cannot be both
  def short_list
    self[:short_listed] = true
    self[:rejected] = false
    self.save
  end

  def reject
    self[:rejected] = true
    self[:short_listed] = false
    self.save
  end

  # unaction put them back into inbox
  def unshort_list
    self[:short_listed] = false
    self.save
  end

  def unreject
    self[:rejected] = false
    self.save
  end

  # define methods for individual and mass setting of booleans
  {:short_list => :short_listed , :reject => :rejected}.each do |action, field|

    metaclass.instance_eval do
      define_method("mass_#{action}") do |ids|
        vs = self.all(:conditions => {:id => ids})
        self.transaction do
          vs.each {|v| v.send("#{action}")}
        end
        vs
      end

      define_method("mass_un#{action}") do |ids|
        vs = self.all(:conditions => {:id => ids})
        self.transaction do
          vs.each {|v| v.send("un#{action}")}
        end
        vs
      end

    end
  end

  def ivy?
    self.candidate.ivy?
  end
  
  def for_paying_only?
    self.candidate.for_paying_only?
  end
  
  #--Callbacks--#
  before_save :maintain_job_id, :if => lambda {|a| a.vacancy_id_changed? }
  before_save :update_screening_and_status_id
  
  #########
  protected
  #########
  
  # before_save
  def maintain_job_id
    self.job_id = self.vacancy.job_id
  end
  
  # before_save
  def update_screening_and_status_id
    # 0 if passed screening
    # 1 if candidate has status id 0, rejected by system
    # 2 if candidate has status id non 0, accepted by system but failed job filter
    screen_result = self.job.passed_screening?(self.candidate)
    if(screen_result == 0)
      self.screening = true
    elsif(screen_result == 1)
      self.screening = false
    elsif(screen_result == 2)
      self.screening = true
      self.rejected = true
    end
    self.status_id = (self.candidate.blocked? || !self.vacancy.status_visible?)? Vacancies::Application::Status[:hidden].id : Vacancies::Application::Status[:visible].id
  end
end
