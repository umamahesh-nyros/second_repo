class City < ActiveRecord::Base
  #--Validations--#  
  validates_presence_of :name
  validates_presence_of :country_id
  
  #--Associations--#
  belongs_to :country
  
  #--Callbacks--#
  named_scope :saudi, lambda {{:conditions => {:country_id => Country.saudi_arabia.id}}}
  named_scope :job, :conditions => {:job => true}
  
  searchable do
    integer :instance_id, :using => :id
    string(:names, :multiple => true) { names.map {|n| n.downcase} }
    integer :country_id
    boolean :job
  end
  
  def autocomplete_hash
    {:name => self.name, :value => self.id, :display_name => "#{self.name}, #{self.country.printable_name}", :dialing_codes => self.country.dialing_codes}
  end
  
  def names
    @names ||= [name, arabic_name, *(alternate_names.blank? ? [] : alternate_names.split(","))].reject {|n| n.blank?}
  end

end
