class Event < ActiveRecord::Base
  Creators = [Admin, Employer]
  Types = Constants.new(:career_event => {:id => 0, :name => "Career event"},
                        :career_workshop => {:id => 1, :name => "Career support workshop"})
  Status = Constants.new(:draft => {:id => 0, :name => "Draft"},
                         :published => {:id => 1, :name => "Published"},
                         :blocked => {:id => 2, :name => "Blocked"})
  Gender = Constants.new(:male => {:id => 1, :name => "Male", :position => 0},
                        :female => {:id => 2, :name => "Female", :position => 1})
  AllowedGenderValues = [0, Gender[:male].id, Gender[:female].id, Gender[:male].id | Gender[:female].id]
  
  attr_accessor :step
  
  #--Validations--#
  # step 1 validations
  validates_presence_of :title
  validates_presence_of :location
  validates_presence_of :start_time
  validates_presence_of :end_time
  validate {|e| e.errors.add_to_base(I18n.translate('activerecord.errors.full_messages')[:start_time_before_end_time]) if e.end_time && e.start_time && e.end_time <= e.start_time}
  
  # step 2 validations
  should_validate_step_2 = lambda {|r| r.step.to_i == 2 || r.step.blank? } 
  with_options :if => should_validate_step_2 do |e|
    e.validates_inclusion_of :status_id, :in => Status.all.collect {|s| s.id}
    e.validates_inclusion_of :type_id, :in => Types.all.collect {|s| s.id}
    e.validates_inclusion_of :employer_gender, :in => AllowedGenderValues
    e.validates_inclusion_of :candidate_gender, :in => AllowedGenderValues
    e.validates_presence_of :creator_id
    e.validates_inclusion_of :creator_type, :in => Creators.collect {|c| c.name}
  end
  validate do |r|
    if should_validate_step_2.call(r) && !r.candidate_attendees? && !r.employer_attendees?
      r.errors.add_to_base(I18n.translate('activerecord.errors.full_messages')[:no_attendees])
    end
  end
  
  #--Associations--#
  belongs_to :creator, :polymorphic => true
  belongs_to :city
  has_many :comments, :as => :commentable, :dependent => :delete_all
  
  
  #--Attachments--#
  has_attached_file :image,
                    :path => ":rails_root/public/events/:attachment/:id/:style.:extension",
                    :url => "/events/:attachment/:id/:style.:extension",
                    :default_url => '/images/defaults/events/:style-event.gif',
                    :styles => {
                      :tiny => "35x35",
                      :small => "55x55",
                      :medium => "70x70",
                      :large =>   "140x140"
  }
  validates_attachment_size :image, :less_than => 1.megabytes
  validates_attachment_content_type :image, :content_type => ['image/bmp', 'image/jpeg', 'image/pjpeg', 'image/gif', 'image/png', 'image/x-png', 'image/jpg']
  
  #--Callbacks--#
  before_validation :may_be_nullify_some_attributes
  before_save :maintain_published_at
  before_save :check_if_notify_employers
  after_save :may_be_notify_employers
  
  #--Named Scopes--#
  named_scope :month_year, lambda {|month, year|
    {:conditions =>["(extract(month from start_time) = ? AND extract(year from start_time) = ?) OR " +
                    "(extract(month from end_time) = ? AND extract(year from end_time) = ?)",
                    month, year, month, year]}
  }
  Status.all.each do |s|
    named_scope "status_#{s.name.underscore}", :conditions => {:status_id => s.id}
  end
  
  named_scope :scope_for, lambda {|user|
    if user.is_a?(Admin)
      {:conditions => {:creator_type => Admin.name}}
    elsif user.is_a?(Employer)
      {:conditions => {:creator_type => Employer.name, :creator_id => user.id}}
    else
      raise ArgumentError, "Unsupported user type"
    end
  }
  
  Creators.each do |klass|
    named_scope "creator_#{klass.name.underscore}", :conditions => {:creator_type => klass.name}
  end
  
  #--Class Methods--#
  def self.mass_destroy_for(user, ids)
    scope_for(user).destroy_all(["id in (?)", (ids.map &:to_i)])
  end
  
  def self.mass_publish_for(user, ids)
    #TODO if we introduce blocking make sure to choose those that are not blocked
    scope_for(user).update_all("status_id = #{Status[:published].id}", ["id in (?)", (ids.map &:to_i)])
  end
  
  def self.mass_draft_for(user, ids)
    #TODO if we introduce blocking make sure to choose those that are not blocked
    scope_for(user).update_all("status_id = #{Status[:draft].id}", ["id in (?)", (ids.map &:to_i)])
  end
  
  #--Instance Methods--#
  Status.all.each do |s|
    define_method("status_#{s.name.underscore}?") {self.status_id == s.id}
    define_method("make_status_#{s.name.underscore}") {self.status_id = s.id; self.save}
  end
  
  Gender.all.each do |g|
    [:candidate, :employer].each do |s|
      define_method("#{s}_gender_#{g.sym_id}") { self.send("#{s}_gender") & g.id == g.id }
      define_method("#{s}_gender_#{g.sym_id}=") do |value|
        value = !!(value =~ /(yes|1|true)/) if ![TrueClass, FalseClass].include?(value.class)
        if value
          self.send("#{s}_gender=", self.send("#{s}_gender") | g.id)
        else
          self.send("#{s}_gender=", self.send("#{s}_gender") & ~g.id)
        end
      end
    end
  end
  
  [:candidate, :employer].each do |s|
    define_method("#{s}_attendees?") { self.send("#{s}_gender") > 0 }
  end
  
  def viewable_by?(user)
    self.status_published? || user.is_a?(Admin) || self.creator == user
  end
  
  def editable_by?(user)
    self.creator.is_a?(Admin) && user.is_a?(Admin) || self.creator == user
  end
  
  def start_date
    #NOTE pay attention to the format"
    self.start_time.strftime("%d/%m/%Y") if self.start_time
  end
  
  def end_date
    #NOTE pay attention to the format
    self.end_time.strftime("%d/%m/%Y") if self.end_time
  end
  
  def type
    Types.find_by_id(self.type_id)
  end
  
  [:employer, :candidate].each do |attr|
    define_method("#{attr}_genders") do
      gs = []
      Gender.all.each {|g| gs << g if self.send("#{attr}_gender_#{g.sym_id}")}
      gs
    end
  end
  
  #########
  protected
  #########
  
  # before_validation
  def may_be_nullify_some_attributes
    [:more_info, :city_id, :street].each do |attr|
      self.send("#{attr}=", nil) if self.send(attr).blank?
    end
  end
  
  #before_save
  def maintain_published_at
    self.published_at = Time.now if self.status_id_changed? && self.status_published?
  end
  
  #before_save
  def check_if_notify_employers
    @notify_employers = self.status_id_changed? && self.status_published?
    true
  end
  
  #after_save
  def may_be_notify_employers
    #TODO mass mailing or mail queue solution
    if @notify_employers
      Employer.find_each do |e|
        EmployerMailer.deliver_event_notification(e, self)
      end
    end
  end
end
