class Degree < ActiveRecord::Base
  LevelsInfo = {:below_high_school => {:id => 0, :name => "Below High School"}, :high_school => {:id => 1, :name => "High School"},
                :diploma => {:id => 2, :name => "Diploma"}, :some_university => {:id => 3, :name => "Some University"},
                :bachelors => {:id => 4, :name => "Bachelors"}, :masters => {:id => 5, :name => "Masters"},
                :phd => {:id => 6, :name => "Phd"}}
  Levels  = {}; LevelsInfo.each_pair {|k,v| Levels[k] = v[:id]}
  LevelsNames = {}; LevelsInfo.each_pair {|k,v| LevelsNames[v[:id]] = v[:name]}
  LevelAIds = Levels.values.select {|x| x >= 4}
  LevelBIds = Levels.values.select {|x| x < 4}
  LevelsC = Constants.new LevelsInfo
  
  MethodOfStudyInfo = {:traditional_learning => {:id => 0, :name => "Full-time learning", :position => 0},
                       :distance_learning => {:id => 1, :name => "Distance learning", :position => 1},
                       :online_learning => {:id => 2, :name => "Online learning", :position => 2},
                       :other => {:id => 3, :name => "Other", :position => 3}}
  MethodOfStudy = {}; MethodOfStudyInfo.each_pair {|k,v| MethodOfStudy[k] = v[:id]}
  MethodOfStudyC = Constants.new(MethodOfStudyInfo)
  
  #--Validations--#
  validate_on_create :presence_of_candidate
  validates_presence_of :candidate_id, :on => :update
  validates_presence_of :institution_id
  validates_date :date, :before => lambda {|c| 5.year.from_now }, :after => lambda {|c| 100.years.ago},
                 :before_message => "must be within a year from now"
  validates_inclusion_of :level_id, :in => Levels.values
  validates_inclusion_of :method_of_study_id, :in => MethodOfStudy.values
  validates_presence_of :category_id
  with_options :if => lambda {|d| d.level_class == "a"} do |d|
    #d.validates_presence_of :sub_category_id
    d.validates_presence_of :gpa
  end
  validate :category_and_sub_category_match_level
  
  #--Associations--#
  belongs_to :candidate
  belongs_to :institution
  belongs_to :category
  belongs_to :sub_category, :class_name => "Category", :foreign_key => "sub_category_id"
  #--Instance Methods--#
  # Could have used the following line, but it raises exceptions
  #   when institution is nil
  # delegate :country, :country_id, :to => :institution
  [:country, :country_id, :group_ids].each {|attr| define_method(attr) { self.try(:institution).try(attr) }}
  
  #--Callbacks--#
  before_validation :set_category_to_sub_category_parent
  
  def level_class
    if self.level_id.blank?
      "c"
    elsif LevelAIds.include?(self.level_id)
      "a"
    elsif LevelBIds.include?(self.level_id)
      "b"
    end
  end
  
  def level_name
    LevelsNames[self.level_id]
  end
  
  def level
    LevelsC.find_by_id(self.level_id)
  end
  
  def full_category_name
    if self.sub_category
    "#{self.category.name} - #{self.sub_category.name}"
    else
      self.category.name
    end
  end
  
  def institution_name
    self.institution.try(:name)
  end
  
  #########
  protected
  #########
  
  # before_validation
  def set_category_to_sub_category_parent
    self.category_id = self.sub_category.parent_id if (self.category_id_changed? || self.sub_category_id_changed?) && self.sub_category_id
  end
  
  # validation
  def presence_of_candidate
    self.errors.add(:candidate_id, I18n.translate('activerecord.errors.messages')[:blank]) if self.candidate.blank? && self.candidate_id.blank?
  end
  
  # validation
  def category_and_sub_category_match_level
    if self.category_id_changed? && self.category
      self.errors.add(:category_id, I18n.translate('activerecord.errors.models.degree')[:category_level_mismatch]) if self.level_class == "a" && !self.category.level_a? || self.level_class == "b" && !self.category.level_b?
    end
  end
end
