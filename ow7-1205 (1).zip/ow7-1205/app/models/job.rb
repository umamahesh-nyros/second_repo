require 'base64'

class Job < ActiveRecord::Base
  Weekends = Constants.new(:not_applicable => {:id => 0, :name => "Not applicable", :position => 1},
                          :one_day => {:id => 1, :name => "One day", :position => 2},
                          :two_days => {:id => 2, :name => "Two days", :position => 3})
  DefaultFilters = {
    :degree_language_class_id => Candidate::DegreeLanguageClasses[:en_bachelor],
    :saudi_status_ids => [Candidate::SaudiStatus[:saudi]],
    :gender_ids => [],
    :job_mixing_id => []
  }.with_indifferent_access
  
  #TODO: extend Defaultfilters with:
  # :job_mixing_id
  # :degrees_university_group_ids
  # :degrees_institution_ids
  # :degrees_country_ids
  # :degrees_category_ids
  # :degrees_level_ids
  # :gpa_range_ids
  # :degrees_group_ids
  
  
  ScreeningFilters = {
    :keys => [:degree_language_class_id, :saudi_status_ids, :gender_ids],
    :depends => {:gender_ids => {Candidate::Gender[:female] => :job_mixing_id}}
  }
  OfflineState = Constants.new(:offline_state => {:name => "Offline", :description => "This job has expired"})[:offline_state]
  
  attr_accessor_with_default :should_have_vacancies, true
  attr_protected :should_have_vacancies, :offline
  
  #--Validations--#
  validates_presence_of :title
  validates_presence_of :type_id
  # Check the comment at Employer#set_jobs_employer for an explanation
  # why 2 validations for essentialy the same thing
  validate_on_create :presence_of_employer
  validates_presence_of :employer_id, :on => :update
  validate :at_least_one_vacancy
  
  ngo_conditions = lambda {|j| j.try(:employer).try(:ngo) }
  with_options :if => ngo_conditions do |v|
    v.validates_presence_of :employer_name
    v.validates_presence_of :employer_city_id
    v.validates_presence_of :employer_website
  end
  validate Proc.new {|record| ngo_conditions.call(record) ? Validator.url_format_of(record, :employer_website) : true}
  validate Proc.new {|record| Validator.url_format_of(record, :application_url) unless record.application_url.blank?}
  
  #--Attachments--#
  has_attached_file :employer_logo,
                    :path => ":rails_root/public/jobs/:attachment/:id/:style.:extension",
                    :url => "/jobs/:attachment/:id/:style.:extension",
                    :default_url => '/images/defaults/employer/:style-logo.gif',
                    :styles => {
                      :tiny => "55x25",
                      :small => "110x50",
                      :medium => "140x64",
                      :large =>   "140x140"
  }
  validates_attachment_size :employer_logo, :less_than => 1.megabytes
  validates_attachment_content_type :employer_logo, :content_type => ['image/bmp', 'image/jpeg', 'image/pjpeg', 'image/gif', 'image/png', 'image/x-png', 'image/jpg']
  
  #--Associations--#
  belongs_to :type, :class_name => 'Jobs::Type', :foreign_key => "type_id"
  belongs_to :employer
  
  has_many :vacancies, :dependent => :destroy
  accepts_nested_attributes_for :vacancies, :allow_destroy => true
  has_many :cities, :through => :vacancies, :source => :city
  has_many :applications, :class_name => 'Vacancies::Application', :dependent => :delete_all
  has_many :jobs_section
  has_and_belongs_to_many :sections

  # NGO associations
  belongs_to :employer_city, :class_name => "City", :foreign_key => "employer_city_id"
  
  #--Named Scopes--#
  named_scope :offline, :conditions => {:offline => true}
  
  #--Callbacks--#
  before_save :nullify_employer_attributes, :if => lambda {|j| !j.ngo}
  after_save :update_applications!
  
  #--Class Methods--#
  def self.offline_after_days
    AppConfig.job_offline_after_days
  end
  
  def self.mark_old_jobs_as_offline(date = Date.today - self.offline_after_days)
    self.created_at_lte(date).find_each do |j|
      j.offline!
    end
  end
  
  #--Instance Methods--# 
  delegate :ngo, :to => :employer
  
  def offline!
    self.class.transaction do
      self.offline = true
      self.save!
      # So that it's reindexed properly
      self.vacancies.each {|v| v.save!}
    end
  end
  
  # a virtual attribute filters (Hash) containing candidate filtering info
  # with setter and getter so as to be saved as marshalled hash attribute: filter_hash
  def filters
    Marshal.load(Base64.decode64(self.filters_hash)) if self.filters_hash
  end
  
  def filters=(hash)
    self.filters_hash = Base64.encode64(Marshal.dump(hash.with_indifferent_access)) if hash && hash.is_a?(Hash)
  end
  
  #TODO: has to be changed to check for keys or empty values
  def has_matching_filters?
    self.filters && !(self.filters.keys - DefaultFilters.keys).empty?
  end
  
  def filter(filter, value = nil)
    if value
      self.filters = self.filters.merge({filter => Array(value)})
    else
      v = self.filters[filter]
      v ? Array(v).reject {|x| x.blank?}.collect {|s| s.to_f == s.to_i ? s.to_i : s.to_f } : []
    end
  end

  # return 0 if passed screening
  # return 1 if candidate has status id 0, rejected by system
  # return 2 if candidate has status id non 0, accepted by system but failed job filter
  def passed_screening?(candidate)
    if candidate.status_system_rejected?
      return 1
    elsif screen(candidate)[:pass] == true
      return 0
    else
      return 2
    end
  end
  
  def screening_filters_keys
    dependants = []
    ScreeningFilters[:depends].each do |d, value_filter|
      value_filter.each do |value, filter|
        f = self.filter(d)
        dependants << filter if !f.empty? && f.include?(value)
      end
    end
    dependants + ScreeningFilters[:keys]
  end
  
  def screen(candidate)
    result = {}
    pass = true
    screening_filters.each do |key, values|
      v = candidate.send(key.to_s.singularize)
      result[key] = v
      pass &&= values.empty? || values.include?(v)
    end
    return {:result => result, :pass => pass}
  end
  
  def screening_filters
    f = {}
    screening_filters_keys.each do |key|
      f[key] = self.filter(key)
    end
    return f
  end
  
  def weekend
    self.weekend_id ? self.class::Weekends.find_by_id(self.weekend_id) : nil
  end
  
  [:name, :logo, :website].each do |m|
    define_method("company_#{m}") { self.ngo ? self.send("employer_#{m}") : self.employer.send(m)}
  end
  
  def editable_by?(user)
    user == self.employer
  end
  
  #########
  protected
  #########
  
  # after_save
  def update_applications!
    # force saving of all applications to allow the applications
    # callbacks to set screening and status_id
    self.applications.all(:include => [:candidate]).each {|a| a.save!}
  end
  
  # DegreeLanguageClasses = {:ar => 0, :en_high_school => 1, :en_bachelor => 2}
  # Gender        = {:male => 1, :female => 2}
  # SaudiStatus = {:saudi => 0, :half_saudi => 1, :non_saudi_in_ksa => 2, :non_saudi => 3}
  def after_initialize
    if new_record?
      self.type ||= Jobs::Type.find_by_identifier!(Jobs::Type::Identifiers[:full_time])
      self.filters ||= {}.merge(DefaultFilters)
    end
  end
  
  def presence_of_employer
    self.errors.add(:employer_id, I18n.translate('activerecord.errors.messages')[:blank]) if self.employer.blank? && self.employer_id.blank?
  end
  
  def at_least_one_vacancy
    # This condition is just for test factories, if it weren't 
    # for factories we could've just ommitted it
    if self.should_have_vacancies
      self.errors.add(:vacancies, I18n.translate('activerecord.errors.messages')[:blank]) if self.vacancies.reject{|r| r.marked_for_destruction?}.blank?
    end
  end
  
  def nullify_employer_attributes
    [:employer_name, :employer_website, :employer_city_id].each {|attr| self.send("#{attr}=",nil)}
    self.employer_logo.clear
    true
  end
end
