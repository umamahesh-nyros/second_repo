require File.join(Rails.root, 'vendor', 'plugins', 'acts_as_commentable', 'lib', 'comment')

class Comment < ActiveRecord::Base
  Status = Constants.new({:visible => {:id => 0}, :hidden => {:id => 1}})
  
  #--Named Scopes--#
  Status.all.each do |s|
    named_scope "status_#{s.sym_id}", :conditions => {:status_id => s.id}
  end
  
  #--Instance Methods--#
  Status.all.each do |s|
    define_method("status_#{s.sym_id}?") { self.status_id == s.id}
  end
end
