class Jobs::Type < ActiveRecord::Base
  set_table_name :jobs_types
  
  Identifiers = {:full_time => 1,
                 :graduate_program => 2,
                 :internship => 3,
                 :summer_job => 4}
  
  #--Validations--#
  validates_presence_of :name
  
  #--Associations--#
  has_many :jobs, :foreign_key => "type_id", :dependent => :delete_all
  
  #--Class Methods--#
  def self.array_of(*args)
    args.collect {|x| self.find_by_identifier! Identifiers[x]}
  end
  
  #--Instance Methods--#
  Identifiers.each_pair do |k,v|
    define_method("#{k}?") { self.identifier == v }
  end
  
end
