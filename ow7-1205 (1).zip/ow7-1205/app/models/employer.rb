class Employer < ActiveRecord::Base
  Status = Constants.new({:active => {:id => 0, :name => "Unblocked", :position => 1},
                          :blocked => {:id => 1, :name => "Blocked", :position => 2},
                          :unblock_requested => {:id => 2, :name => "Unblock requested", :position => 3}})
  #--Authentication--#
  acts_as_authentic do |config|
    config.disable_perishable_token_maintenance = true
  end
  
  #--Attributes--#
  attr_protected :crypted_password, :password_salt, :persistence_token,
                 :single_access_token, :perishable_token, :email, :password,
                 :status_id, :ngo, :invitation, :paid, :paid_expiry_date
  
  attr_accessor :invitation
  attr_accessor :old_password
  attr_accessor :check_old_password
  
  validates_each :old_password, :if => Proc.new {|u| !u.new_record? && !u.password.nil? && u.check_old_password} do |record, field, value|
    if record.old_password.nil? || Authlogic::CryptoProviders::Sha512.encrypt(record.old_password + record.password_salt_was) != record.crypted_password_was
      record.errors.add(:old_password, I18n.translate('activerecord.errors.models.employer')[:old_password])
    end
  end
  
  #--Attachments--#
  has_attached_file :logo,
                    :path => ":rails_root/public/employers/:attachment/:id/:style.:extension",
                    :url => "/employers/:attachment/:id/:style.:extension",
                    :default_url => '/images/defaults/employer/:style-logo.gif',
                    :styles => {
                      :tiny => "55x25",
                      :small => "110x50",
                      :medium => "140x64",
                      :large =>   "140x140"
  }
  validates_attachment_size :logo, :less_than => 1.megabytes
  validates_attachment_content_type :logo, :content_type => ['image/bmp', 'image/jpeg', 'image/pjpeg', 'image/gif', 'image/png', 'image/x-png', 'image/jpg']  
  
  #--Validations--#
  validates_presence_of :invitation, :on => :create
  validates_presence_of :name
  validates_presence_of :person_name
  validates_presence_of :website
  validate Proc.new {|record| Validator.url_format_of(record, :website) }
  validates_presence_of :city_id
  validates_presence_of :phone
  validate Proc.new {|record| Validator.phone_format_of(record, :phone) }
  validates_presence_of :paid_expiry_date, :if => proc {|r| r.paid }
  
  #--Associations--#
  has_many :invitations, :as => :invited, :dependent => :delete_all
  has_many :jobs, :dependent => :destroy
  accepts_nested_attributes_for :jobs
  has_many :vacancies, :through => :jobs
  has_many :interviews, :dependent => :destroy, :class_name => "Interviews::Interview"
  has_many :connections, :through => :interviews, :class_name => "Interviews::Connection"
  belongs_to :city
  has_many :articles, :as => :creator, :dependent => :destroy
  has_many :events, :as => :creator, :dependent => :destroy
  has_many :comments, :as => :commenter, :dependent => :delete_all
  
  #--Callbacks--#
  before_validation_on_create :set_jobs_employer
  after_validation :falsify_paid_on_expiry_date_errors
  after_create :expire_invitation
  after_save :handle_block_status
  
  #--Search--#
  searchable do
    string(:sort_name) { name.try(:downcase) }
    text :name
    text :person_name
    text :email
    text :website
    text :more_info
    integer :city_id
    integer :status_id
    date :created_at
  end
  
  #--Named Scopes--#
  named_scope :for, lambda {|status|
    raise(ArgumentError, "Unsupported status") unless [:unblock].include?(status)
    if status == :unblock
      {:conditions => {:status_id => [Status[:blocked].id,Status[:unblock_requested].id]}}
    end
  }
  
  #--Class Methods--#
  def self.filter_search(q, page = 1, per_page = 10)
    sorter = (q[:sorter] =~ /(sort_name|created_at)/ && $1) || "created_at"
    sorter_dir = sorter == "created_at" ? "desc" : "asc"
    solr_search do
      q.each_pair do |k,v|
        k = k.to_s
        if k =~ /_ids?$/
          non_empty_v = Array(v).reject {|x| x.blank? }
          with(k).any_of(non_empty_v) if non_empty_v.length > 0
        elsif k =~ /^keywords$/
          fulltext(v) unless v.blank?
        end
      end
      order_by sorter, sorter_dir
      paginate :page => page, :per_page => per_page
    end
  end
  
  def self.check_payments
    self.expire_paying_employers
    self.notify_for_upcoming_expiries
  end
  
  def self.notify_for_upcoming_expiries
    self.paying.each {|e| e.send_payment_expiry_notification if e.should_send_payment_expiry_notification? }
  end
  
  def self.expire_paying_employers
    self.paying.each {|e| e.expire_payment if e.should_expire_payment? }
  end
  
  def self.paying
    self.paid
  end
  
  def self.non_paying
    self.not_paid.all :conditions => "paid_expiry_date is null"
  end
  
  def self.expired_paying
    self.not_paid.all :conditions => "paid_expiry_date is not null"
  end
  
  #--Instance Methods--#
  Status.all.each do |s|
    define_method("status_#{s.sym_id}?") {self.status_id == s.id}
  end
  
  {:block => Status[:blocked]}.each_pair do |k,v|
    define_method(k) {self.status_id = v.id; self.save; EmployerMailer.deliver_block_notification(self); true}
    define_method("#{k}!") {self.status_id = v.id; self.save!;EmployerMailer.deliver_block_notification(self) ; true}
    metaclass.instance_eval do
      define_method("mass_#{k}!") do |ids|
        cs = self.find(ids)
        self.transaction do
          cs.each do |c|
            c.block_reason = nil
            c.send("#{k}!")
          end
        end
        cs
      end
    end
  end
  
  {:unblock => Status[:active]}.each_pair do |k,v|
    define_method(k) {self.status_id = v.id; self.block_reason = nil; self.save; EmployerMailer.deliver_unblock_notification(self); true}
    define_method("#{k}!") {self.status_id = v.id; self.block_reason = nil; self.save!; EmployerMailer.deliver_unblock_notification(self); true}
    metaclass.instance_eval do
      define_method("mass_#{k}!") do |ids|
        cs = self.for(k).all(:conditions => {:id => ids})
        self.transaction do
          cs.each {|c| c.send("#{k}!")}
        end
        cs
      end
    end
  end
  
  def paying_till(expiry_date)
    self.paid = true
    self.paid_expiry_date = expiry_date
    self.save
  end
  
  def non_paying
    self.paid = false
    self.paid_expiry_date = nil
    self.save
  end
  
  def expire_payment
    self.paid = false
    self.save
  end
  
  def days_to_expiry
    paid_expiry_date - Date.today
  end
  
  def expiry_date_passed?
    paid_expiry_date.present? && days_to_expiry < 0
  end
  
  def should_expire_payment?
    paid? && expiry_date_passed?
  end
  
  def expired_paying?
    !paid? && expiry_date_passed?
  end
  
  def paying?
    paid?
  end
  
  def non_paying?
    !paid? && paid_expiry_date.blank?
  end
  
  def send_payment_expiry_notification
    EmployerMailer.deliver_payment_expiry_notification(self)
  end
  
  def should_send_payment_expiry_notification?
    days = days_to_expiry.days
    days == 2.weeks || days == 1.week || days == 1.day
  end
  
  def blocked?
    self.status_blocked? || self.status_unblock_requested?
  end
  
  def request_unblock!
    self.status_id = Status[:unblock_requested].id
    save!
  end
  
  def change_password(old_password, new_password)
    unless old_password.blank? && new_password.blank?
      self.check_old_password = true
      self.old_password = old_password
      self.password = self.password_confirmation = new_password
    end
  end
  
  def deliver_password_reset_instructions!
    reset_perishable_token!
    EmployerMailer.deliver_password_reset_instructions(self)
  end
  
  def invitation=(value)
    if value
      @invitation = value
      self.ngo = @invitation.type_ngo?      
    end
  end
  
  def phone_code
    self.city.country.dialing_codes.first if self.city
  end
  
  def phone_with_code
    "#{self.phone_code} #{self.phone}"
  end
  
  #########
  protected
  #########
  
  # after_save
  def handle_block_status
    if self.status_id_changed?
      self.comments.update_all "status_id = #{self.blocked? ? Comment::Status[:hidden].id : Comment::Status[:visible].id}"
      # force each vacancy to save which will force saving
      # applications and interviews connections and updating 
      # ther visibility
      self.vacancies.each {|v| v.save! }
    end
    
  end
  
  # after_validation
  def falsify_paid_on_expiry_date_errors
    self.paid = false if self.errors.on(:paid_expiry_date).present?
  end
  
  def after_initialize
    if self.new_record?
      self.contacts_hidden ||= true
    end
    
  end
  
  def expire_invitation
    self.invitation.invited = self
    self.invitation.save!
    true
  end
  
  # this method is part of the solution to the problem of validates_presence_of :parent_id
  # when both the parent and the child are still new records (in memory). we will validate
  # the presence of parent in child on create and parent_id otherwise (save)
  # In later versions of rails, this should be solved by using the option :inverse_of
  # according to the discussion here
  # https://rails.lighthouseapp.com/projects/8994/tickets/1943
  def set_jobs_employer
    self.jobs.each {|j| j.employer = self}
  end
end
