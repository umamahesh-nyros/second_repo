class Enquiry < ActiveRecord::Base

  TypeInfo = {
    :problems => {:id => 1, :name => "Problems with the site", :position => 1},
    :feedback => {:id => 2, :name => "Feedback & Suggestions", :position => 2},
    :invitatoin => {:id => 3, :name => "Invitation request", :position => 3},
    :other    => {:id => 4, :name => "Other", :position => 4}
  }
  Type={};TypeInfo.each {|k,v| Type[k] = v[:id]}
  TypeC = Constants.new TypeInfo

  #--Validations--#
  validates_presence_of :name
  validates_presence_of :email
  validates_presence_of :type_id
  validates_inclusion_of :type_id, :in => Type.values , :if => lambda {|r| r.type_id.present?}
  validates_format_of :email, :with =>  Authlogic::Regex.email, :message => I18n.t('activerecord.errors.messages.invalid_email'),
                      :if => lambda {|r| r.email.present? }


  def send_email
    EnquiryMailer.deliver_contact_us_enquiry(self) rescue return false
    return true
  end

end
