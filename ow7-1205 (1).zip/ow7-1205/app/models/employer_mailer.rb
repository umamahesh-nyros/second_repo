class EmployerMailer < ActionMailer::Base
  layout 'email'
  include ApplicationHelper
  helper ApplicationHelper
  
  def password_reset_instructions(employer)
    setup_email
    subject       I18n.t('email.password_reset_instructions.subject')
    recipients    employer.email
    body          :password_reset_url => edit_employers_password_reset_url(employer.perishable_token), :employer => employer
  end
  
  def event_notification(employer, event)
    setup_email
    subject       "#{event.title} on #{formatted_date(event.start_time, :short)}"
    recipients    employer.email
    body :event => event, :employer => employer
  end
  
  def block_notification(employer)
    setup_email
    subject       I18n.t('email.employers.block_notification.subject')
    recipients    employer.email
    body          :employer => employer
  end
  
  def unblock_notification(employer)
    setup_email
    subject       I18n.t('email.employers.unblock_notification.subject')
    recipients    employer.email
    body          :employer => employer
  end
  
  def payment_expiry_notification(employer)
    setup_email
    subject       I18n.t('email.employers.payment_expiry_notification.subject')
    recipients    employer.email
    body          :employer => employer
  end
  
  def setup_email
    content_type "text/html"
    from AppConfig.from_no_reply
    sent_on Time.now
  end
end
