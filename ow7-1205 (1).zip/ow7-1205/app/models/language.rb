class Language < ActiveRecord::Base
  #--Validations--#
  validates_uniqueness_of :name
  
  #--Instance Methods--#
  def method_missing(name, *args)
    if name.to_s =~ /is_(.+)\?/
      self.name.underscore == $1
    else
      super(name, *args)
    end
  end
end
