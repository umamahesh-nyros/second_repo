class InvitationMailer < ActionMailer::Base
  layout 'email'
  helper ApplicationHelper
  
  def employer_invitation(invitation)
    setup_email
    subject I18n.t('email.employer_invitation.subject')
    from I18n.t('email.employer_invitation.from')
    reply_to I18n.t('email.employer_invitation.reply_to')
    #headers['Sender'] = "noreply@oilwell7.com"
    recipients ["#{invitation.name} <#{invitation.email}>"]
    body :invitation => invitation
  end
  
  def setup_email
    content_type "text/html"
    sent_on Time.now
  end
end
