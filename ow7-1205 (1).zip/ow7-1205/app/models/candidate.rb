class Candidate < ActiveRecord::Base
  #--Constants--#
  OldState = Constants.new(:old_state => {:name => "Old", :description => "Not active for more than #{AppConfig.candidate_old_after_days} days"})[:old_state]
  AgeRanges = Constants.new(:twenties => {:id => 1, :low => 20, :high => 29, :name => "20 - 29", :position => 1},
                            :thirties => {:id => 2, :low => 30, :high => 39, :name => "30 - 39", :position => 2},
                            :forty_and_more => {:id => 3, :low => 40, :high => nil, :name => "More than 40", :position => 3})
  
  GenderInfo = {:male => {:id => 1, :name => "Male", :style_class => "male"}, :female => {:id => 2, :name => "Female", :style_class => "female"}}
  Gender={};GenderInfo.each {|k,v| Gender[k] = v[:id]}
  GenderC = Constants.new GenderInfo
  
  MaritalStatusInfo ={:single => {:id => 1, :name => "Single", :position => 1}, :married => {:id => 2, :name => "Married", :position => 2}}
  MaritalStatus={};MaritalStatusInfo.each {|k,v| MaritalStatus[k] = v[:id]}
  MaritalStatusC = Constants.new MaritalStatusInfo
  
  IqamaTypes    = {:none => 0, :untransferrable => 1, :transferrable => 2}
  
  MixingLevelsInfo = {:strict_segregation => {:id => 0, :name => "Strict segregated", :image_id => 1},
                      :semi_segregated => {:id => 1, :name => "Semi segregated", :image_id => 2},
                      :unsegregated_conservative => {:id => 2, :name => "Unsegregated conservative", :image_id => 3},
                      :unsegregated_unconservative => {:id => 3, :name => "Unsegregated relaxed", :image_id => 4}} 
  MixingLevels={};MixingLevelsInfo.each {|k,v| MixingLevels[k] = v[:id]}
  MixingLevelsC = Constants.new MixingLevelsInfo 
  
  
  SaudiStatus = {:saudi => 0, :half_saudi => 1, :non_saudi_in_ksa => 2, :non_saudi => 3}
  DegreeLanguageClasses = {:ar => 0, :en_high_school => 1, :en_bachelor => 2}
  Languages = {:en => 0, :ar => 1}
  
  StatusInfo = {:system_rejected => {:id => 0, :name => "System rejected", :position => 1},
                :system_accepted => {:id => 1, :name => "Accepted", :position => 0},
                :completed_registration_step_1 => {:id => 2}, 
                :completed_registration_step_2 => {:id => 3},
                :blocked => {:id => 4, :name => "Blocked", :position => 3},
                :unblock_requested => {:id => 5, :name => "Unblock requested", :position => 4},
                :rejected => {:id => 6, :name => "Admin rejected", :position => 2}}
  StatusC = Constants.new StatusInfo
  Status = {}; StatusInfo.each_pair {|k,v| Status[k] = v[:id]}
  
  #--Attributes--#
  attr_accessor :skip_registration_steps
  attr_accessor :residence_phone_code, :residence_phone_number,
                :saudi_phone_code, :saudi_phone_number,
                :has_saudi_contacts, :confirmation
  attr_accessor_with_default :should_maintain_status, true
  attr_protected :crypted_password, :password_salt, :persistence_token,
                 :single_access_token, :perishable_token, :email, :password,
                 :status_id, :skip_registration_steps, :should_maintain_status
  
  #--Validations--#
  # Always
  validates_presence_of :first_name
  validates_presence_of :last_name
  validates_date :last_updated
  validates_date :date_of_birth, :before => lambda {|c| Date.today - 18.years}, :before_message => I18n.translate('activerecord.errors.messages')[:past_date]
  {
    :gender_id => Gender,
    :marital_status_id => MaritalStatus,
    :language_id => Languages
  }.each do |member, hash|
    validates_inclusion_of member, :in => hash.values  
  end
  validates_inclusion_of :iqama_id, :in => IqamaTypes.values,
                         :if => lambda {|c| c.country_ids.length > 0 && !c.country_ids.include?(Country.saudi_arabia.id)}
  
  validate :presence_of_degree
  validate :presence_of_nationality
  # Step 2 or with no steps
  validates_inclusion_of :job_mixing_id, :in => MixingLevels.values, :if => lambda {|c| c.gender_female? && c.completed_registration_steps > 0}
  validate :presence_of_job_types
  validate :presence_of_job_cities
  
  # Step 3 or with no steps
  step_3_or_more_lambda = lambda {|c| c.completed_registration_steps > 1} 
  with_options :if => step_3_or_more_lambda do |c|
    c.validates_presence_of :residence_country_id
    #TODO validates city in country if it's present
    #TODO c.validates_presence_of :residence_city_id
    c.validates_presence_of :residence_phone
  end
  # the job start date is validated when it's blank or when it's changed such that
  # a candidate who already registered doesn't get invalid automatically
  validates_date :job_start_date, :after => lambda {|c| (Date.today-Date.today.day)}, :if => lambda {|c| step_3_or_more_lambda.call(c) && (c.job_start_date.blank? || c.job_start_date_changed?)}
  validate Proc.new {|record| Validator.phone_format_of(record, :residence_phone, :country => record.residence_country) if step_3_or_more_lambda.call(record) }
  
  step_3_or_more_and_has_saudi_contacts = lambda {|c| step_3_or_more_lambda.call(c) && c.has_saudi_contacts }
  with_options :if => step_3_or_more_and_has_saudi_contacts do |c|
    c.validates_presence_of :saudi_city_id
    #TODO validate saudi city
    c.validates_presence_of :saudi_phone
  end
  validate Proc.new {|record| Validator.phone_format_of(record, :saudi_phone, :saudi => true) if step_3_or_more_and_has_saudi_contacts.call(record) }
  validate :presence_of_entry_level
  validate :confirmation_of_info
  
  #--Associations--#
  belongs_to :residence_country, :class_name => 'Country'
  belongs_to :residence_city, :class_name => 'City'
  belongs_to :saudi_city, :class_name => 'City'
  has_many :candidates_countries, :class_name => 'Candidates::Country', :dependent => :delete_all, :autosave => true
  has_many :countries, :through => :candidates_countries
  has_many :candidates_job_types, :class_name => 'Candidates::JobType', :dependent => :delete_all
  has_many :job_types, :through => :candidates_job_types
  has_many :candidates_job_cities, :class_name => 'Candidates::JobCity', :dependent => :delete_all
  has_many :job_cities, :through => :candidates_job_cities, :source => :city
  has_many :degrees, :dependent => :delete_all, :autosave => true
  accepts_nested_attributes_for :degrees, :allow_destroy => true
  has_many :institutions, :through => :degrees
  
  has_many :applications, :class_name => "Vacancies::Application", :dependent => :delete_all
  has_many :vacancies, :through => :applications
  has_many :jobs, :through => :applications
  
  has_many :visible_applications, :class_name => 'Vacancies::Application', :foreign_key => "candidate_id",
         :conditions => {:status_id => Vacancies::Application::Status[:visible].id}
  has_many :visible_vacancies, :through => :visible_applications, :source => :vacancy
  has_many :visible_jobs, :through => :visible_applications, :source => :job
  
  has_many :comments, :as => :commenter, :dependent => :delete_all
  
  has_many :connections, :class_name => "Interviews::Connection", :dependent => :destroy
  has_many :interviews, :class_name => "Interviews::Interview", :through => :connections
  has_many :visible_connections, :class_name => "Interviews::Connection",
           :conditions => {:status_id => Interviews::Connection::Status[:visible].id}
  has_many :visible_interviews, :class_name => "Interviews::Interview", :through => :visible_connections
  has_many :candidate_section
  has_and_belongs_to_many :sections
  
  # Named scopes
  named_scope :for, lambda {|status|
    raise(ArgumentError, "Unsupported status") unless [:unblock, :unreject].include?(status)
    if status == :unblock
      {:conditions => {:status_id => [StatusC[:blocked].id, StatusC[:unblock_requested].id]}}
    elsif status == :unreject
      {:conditions => {:status_id => StatusC[:rejected].id}}
    end
  }
  
  named_scope :for_user, lambda {|user|
    rules = {Employer => {:conditions => {:status_id => StatusC[:system_accepted].id}},
             Admin => {}}
    rules[user.class] || raise(ArgumentError, "Unsupported user")    
  }
  
  #--Callbacks--#
  before_validation :may_be_nullify_some_attributes
  before_validation :convert_artificial_attributes_to_booleans
  before_validation :collect_phones_parts
  before_validation :process_saudi_contacts_info
  before_validation_on_create :set_degrees_candidate
  before_save :maintain_status, :if => lambda {|r| r.skip_registration_steps || r.should_maintain_status }
  after_create :deliver_welcome
  
  #--Authentication--#
  acts_as_authentic do |config|
    config.disable_perishable_token_maintenance = true
    config.require_password_confirmation = false
  end
  
  #--Search index--#
  # TODO this should be optimized to index the candidate only when
  # relevant info are changed...it's not a light operation !
  searchable do
    #text
    text :name
    text :degrees_full_category_names
    text :degrees_institution_names
    text(:nationalities) { self.countries.collect {|c| c.printable_name}.join(" ") }
    
    # personal stuff
    string(:name) { name.downcase }
    integer :gender_id
    integer :marital_status_id
    integer :iqama_id
    date :date_of_birth
    integer :saudi_status_id
    
    # job stuff
    integer :job_type_ids, :multiple => true
    integer :job_mixing_id
    date :job_start_date
    integer :job_city_ids, :multiple => true
    
    # education stuff
    integer :degree_language_class_id
    date :degrees_dates, :multiple => true
    integer :degrees_institution_ids, :multiple => true
    integer :degrees_group_ids, :multiple => true
    integer :degrees_country_ids, :multiple => true
    integer :degrees_level_ids, :multiple => true
    integer :degrees_category_ids, :multiple => true
    integer :degrees_method_of_study_ids, :multiple => true
    float :degrees_gpas, :multiple => true
    integer :countries_of_education_ids, :multiple => true
    
    # saudi stuff
    integer :saudi_status_id
    
    integer :age_range_id
    integer :residence_city_id
    integer :residence_country_id
    
    integer :status_id
    time :current_login_at
    date :created_at
  end
  # NOTE
  # Sunspot doesn't support supplying conditions for indexing an instance
  # instead v1.0rc2 relies on 2 callbacks
  #   before_save :maybe_mark_for_auto_indexing
  #   after_save :maybe_auto_index
  # which both use @marked_for_auto_indexing. I will modify this variable
  # in a before_save based on my own conditions
  before_save :maintain_solr_existence
  #after_save :may_be_remove_from_solr
  after_save :update_applications
  after_save :handle_block_status
  
  #--Attachments--#
  has_attached_file :avatar,
                    :path => ":rails_root/public/candidates/:attachment/:id/:style.:extension",
                    :url => "/candidates/:attachment/:id/:style.:extension",
                    :default_url => '/images/defaults/candidate/:style-male.png',
                    :styles => {
                      :tiny => "35x35",
                      :small => "55x55",
                      :medium => "70x70",
                      :large =>   "140x140"
  }
  validates_attachment_size :avatar, :less_than => 1.megabytes
  validates_attachment_content_type :avatar, :content_type => ['image/bmp', 'image/jpeg', 'image/pjpeg', 'image/gif', 'image/png', 'image/x-png', 'image/jpg']  
  
  has_attached_file :cv,
                    :path => ":rails_root/public/candidates/:attachment/:id.:extension",
                    # NOTE this works in co-ordination ith server side rewrite rules
                    # The nginx rewrite rule is
                    #   rewrite  /candidates/cvs/(\d+)-([\w-]+)(\..*)$  /candidates/cvs/$1$3  last;
                    # To try it in development mode with no rewrites, uncomment the following line instead
                    #   :url => "/candidates/:attachment/:id.:extension"
                    :url => "/candidates/:attachment/:id-:name.:extension"
  validates_attachment_size :cv, :less_than => 1.megabytes
  #TODO cv content types
  #validates_attachment_content_type :cv, :content_type => ['image/bmp', 'image/jpeg', 'image/pjpeg', 'image/gif', 'image/png', 'image/x-png', 'image/jpg']
  
  #--Class Methods--#
  def self.saudi_contacts_attributes
    [:saudi_city_id, :saudi_phone]
  end
  
  def self.old_after_days
    AppConfig.candidate_old_after_days
  end
  
  def self.deliver_old_notifications(date = Date.today - Candidate.old_after_days.days)
    self.find_each(:conditions =>["(extract(year from current_login_at) = ? AND "+
                                  "extract(month from current_login_at) = ? AND "+
                                  "extract(day from current_login_at) = ?)",
                                  date.year, date.month, date.day]) do |c|
      c.deliver_old_notification
    end
  end
  
  def self.filter_search(q, user, page = 1, per_page = 10)
    q = q.clone
    if q.delete(:order) =~ /job_start_date/
      sorter = "job_start_date"
      sorter_dir = "asc"
    else
      sorter = "current_login_at"
      sorter_dir = "desc"
    end
    non_admin_defaults = {:system_accepted => true}
    
    solr_search(:include => [{:degrees => [:category, :sub_category, :institution], :residence_city => :country}, :countries]) do
      fulltext(q[:keywords]) unless q[:keywords].blank?
      all_of do
        unless user.is_a?(Admin)
          q.delete(:status_id)
          with(:status_id, Candidate::StatusC[:system_accepted].id)
        end
        if q[:gender_id]
          any_of do
            with(:gender_id, Candidate::Gender[:male]) if q[:gender_id].include?(Candidate::Gender[:male].to_s)
            all_of do
              with(:gender_id, Candidate::Gender[:female])
              with(:job_mixing_id).any_of(q[:job_mixing_id])
            end if q[:gender_id].include?(Candidate::Gender[:female].to_s)
          end
          q.delete :gender_id
          q.delete :job_mixing_id
        end
        q.each_pair do |k,v|
          k = k.to_s
          if k =~ /_ids?$/
            non_empty_v = Array(v).reject {|x| x.blank? }
            with(k).any_of(non_empty_v) if non_empty_v.length > 0
          elsif k =~ /_gpas$/
            with(k).greater_than(v.is_a?(Array) ? v.first : v)
          end
        end
      end
      order_by sorter, sorter_dir
      paginate :page => page, :per_page => per_page
    end
  end
  
  #--Instance Methods--#
  def old?
    self.current_login_at.nil? || self.current_login_at.to_date <= (Date.today-Candidate.old_after_days.days)
  end
  
  def set_last_updated(t = Time.now)
    self.last_updated = t
  end
  def deliver_old_notification
    CandidateMailer.deliver_old_notification(self)
  end
  
  def unbooked_interviews_count
    self.visible_connections.without_slot.with_open_interview.count
  end
  
  def blocked?
    self.status_blocked? || self.status_unblock_requested?
  end
  
  def ivy?
    self.institutions.inject(false) {|s, i| s || i.ivy_league }
  end
  
  def for_paying_only?
    non_saudi_institution?
  end
  
  def non_saudi_institution?
    self.institutions.inject(false) {|s, i| s || i.country != Country.saudi_arabia }
  end
  
  def countries_of_education
    self.institutions.collect &:country
  end
  
  def countries_of_education_ids
    self.institutions.collect &:country_id
  end
  
  def preferred_country
    @preferred_country||= (self.countries.to_a.find {|c| c.saudi_arabia?} || self.countries.first)
  end
  
  def age_range_id(a = age)
    x = AgeRanges.ascend_by_low.select {|ar| (ar.low.blank? ? true : a >= ar.low ) && (ar.high.blank? ? true : a <= ar.high )}.first
    x ? x.id : nil
  end
  
  def highest_degree
    self.degrees.sort {|a,b| b.level_id <=> a.level_id}.first
  end
  
  def name
    "#{first_name} #{last_name}"
  end
  
  def age
    if self.date_of_birth
      now = Date.today
      now.year - self.date_of_birth.year - (self.date_of_birth.change(:year => now.year) > now ? 1 : 0)
    else
      nil
    end
  end
  
  Gender.each_pair do |k,v|
    define_method("gender_#{k}?") {self.gender_id == v}
  end
  
  Status.each_pair do |k,v|
    define_method("status_#{k}?") {self.status_id == v}
  end
  
  Languages.each_pair do |k,v|
    define_method("language_#{k}?") {self.language_id == v}
  end
  
  [:date, :institution_id, :group_ids, :country_id, :level_id,
   :method_of_study_id, :gpa, :full_category_name, :institution_name].each do |degree_attribute|
    define_method("degrees_#{degree_attribute.to_s.pluralize}") { self.degrees.collect {|d| d.send(degree_attribute)}.reject {|d| d.nil? }.flatten }
  end
  
  def degrees_category_ids
    self.degrees.collect {|d| [d.category_id, d.sub_category_id]}.flatten.uniq.reject {|d| d.nil? }
  end
  
  def degree_language_class_id
    if self.language_ar?
      DegreeLanguageClasses[:ar]
    elsif self.degrees_level_ids.any? do |x|
        [Degree::Levels[:some_university], Degree::Levels[:bachelors],
        Degree::Levels[:masters], Degree::Levels[:phd]].include?(x)        
      end
      DegreeLanguageClasses[:en_bachelor]
    else #lower degrees
      DegreeLanguageClasses[:en_high_school]
    end
  end
  
  def saudi_status_id
    saudia = Country.saudi_arabia 
    if saudia && self.country_ids.include?(saudia.id)
      SaudiStatus[:saudi]
    elsif self.gender_male? && (self.saudi_mother || self.saudi_spouse)
      SaudiStatus[:half_saudi]
    elsif self.iqama_id == IqamaTypes[:transferrable]
      SaudiStatus[:non_saudi_in_ksa]
    else
      SaudiStatus[:non_saudi]
    end
  end
  
  def deliver_password_reset_instructions!
    reset_perishable_token!
    CandidateMailer.deliver_password_reset_instructions(self)
  end
  
  def deliver_welcome
    CandidateMailer.deliver_welcome(self)
  end
  
  def incomplete_registration?
    self.status_completed_registration_step_1? || self.status_completed_registration_step_2?
  end
  
  def completed_registration_steps
    if self.new_record?
      # Normaly this should mean 0, but if we're trying to skip
      # steps, then let's just simulate so that all validations
      # should be run now
      self.skip_registration_steps ? 3 : 0
    elsif self.status_completed_registration_step_1?
      1
    elsif self.status_completed_registration_step_2?
      2
    else
      3
    end
  end
  
  def residence_phone_number=(num)
    @residence_phone_number = num.gsub(/^0*/, '') if num.respond_to? :gsub
  end
  
  def residence_phone_number
    @residence_phone_number ||= self.residence_phone ? self.residence_phone.gsub(/^#{self.residence_phone_code}/, '') : nil
  end
  
  def residence_phone_code    
    @residence_phone_code ||= self.residence_phone ? self.residence_country.dialing_codes.select {|c| self.residence_phone =~ /^#{c}/ }.first.to_s : nil
  end
  
  def saudi_phone_number=(num)
    @saudi_phone_number = num.gsub(/^0*/, '') if num.respond_to? :gsub
  end
  
  def saudi_phone_number
    @saudi_phone_number ||= self.saudi_phone ? self.saudi_phone.gsub(/^#{self.saudi_phone_code}/, '') : nil
  end
  
  def saudi_phone_code
    @saudi_phone_code ||= self.saudi_phone ? Country.saudi_arabia.dialing_codes.select {|c| self.saudi_phone =~ /^#{c}/ }.first.to_s : nil
  end
  
  def has_saudi_contacts
    return @has_saudi_contacts unless @has_saudi_contacts.nil?  
    @has_saudi_contacts = (self.residence_country_id != Country.saudi_arabia.id &&
                           self.class.saudi_contacts_attributes.inject(false) {|acc, attr| acc || !self.send(attr).nil? })
  end
  
  def viewable_by_employer?
    [StatusC[:system_accepted].id, StatusC[:system_rejected].id, StatusC[:rejected].id].include?(self.status_id)
  end  
  
  def viewable_by?(user)
    !!(user && (user == self || user.is_a?(Admin) || user.is_a?(Employer) && self.viewable_by_employer?))
  end
  
  def marital_status
    MaritalStatusC.find_by_id(self.marital_status_id)
  end
  
  def gender
    GenderC.find_by_id(self.gender_id)
  end
  
  def mixing_level
    MixingLevelsC.find_by_id(self.job_mixing_id)
  end

  {:block => StatusC[:blocked], :reject => StatusC[:rejected]}.each_pair do |k,v|
    if k =~ /block/
      define_method(k) {self.status_id = v.id; self.save; CandidateMailer.deliver_block_notification(self); true}
      define_method("#{k}!") {self.status_id = v.id; self.save!;CandidateMailer.deliver_block_notification(self) ; true}
    else
      define_method(k) {self.status_id = v.id; self.save}
      define_method("#{k}!") {self.status_id = v.id; self.save!}
    end
    metaclass.instance_eval do
      define_method("mass_#{k}!") do |ids|
        cs = self.find(ids)
        self.transaction do
          cs.each {|c| c.send("#{k}!")}
        end
        cs
      end
    end
  end
  [:unblock, :unreject].each do |m|
    if m =~ /block/
      define_method(m) {self.mark_as_accepted_or_rejected; self.save; CandidateMailer.deliver_unblock_notification(self); true}
      define_method("#{m}!") {self.mark_as_accepted_or_rejected; self.save!; CandidateMailer.deliver_unblock_notification(self); true}
    else
      define_method(m) {self.mark_as_accepted_or_rejected; self.save}
      define_method("#{m}!") {self.mark_as_accepted_or_rejected; self.save!}      
    end
    metaclass.instance_eval do
      define_method("mass_#{m}!") do |ids|
        cs = self.for(m).all(:conditions => {:id => ids})
        self.transaction do
          cs.each {|c| c.send("#{m}!")}
        end
        cs
      end
    end
  end
  
  def request_unblock!
    self.status_id = StatusC[:unblock_requested].id
    save!
  end
  
  def check_system_acceptance
    return {
      :level => {:value => self.entry_level, :pass => !!(self.entry_level)},
      :age => {:value => self.age, :pass => !!(self.age <= AppConfig.age_system_filter)},
      :saudi_status_id => {
        :value => self.saudi_status_id, 
        :pass => !!(SaudiStatus.reject {|k,v| v == SaudiStatus[:non_saudi]}.values.include?(self.saudi_status_id))
      },
      :job_start_date => {:value => self.job_start_date, :pass => !!(self.job_start_date <= 6.month.from_now.to_date)}
    }
  end
  
  def preferred_phone
    self.saudi_phone || self.residence_phone
  end
  
  
  def can_receive_sms?
    self.ivy?
  end
  #########
  protected
  #########
  
  def satisfy_system_acceptance?
    !!(self.entry_level &&
       self.age <= AppConfig.age_system_filter &&
       self.job_start_date <= 6.month.from_now.to_date &&
       SaudiStatus.reject {|k,v| v == SaudiStatus[:non_saudi]}.values.include?(self.saudi_status_id))
  end  
  
  def mark_as_accepted_or_rejected
    self.status_id = self.satisfy_system_acceptance? ? Status[:system_accepted] : Status[:system_rejected]
  end
  
  # validation
  def presence_of_job_types
    if self.completed_registration_steps > 0
      self.errors.add_to_base(I18n.translate('activerecord.errors.full_messages')[:job_types_presence]) if self.job_types.length == 0
    end
  end
  #validation
  def presence_of_job_cities
    if self.completed_registration_steps > 0
      self.errors.add_to_base(I18n.translate('activerecord.errors.full_messages')[:job_cities_presence]) if self.job_cities.length == 0
    end
  end
  # validation
  def presence_of_nationality
    countries_count = self.new_record? ? self.countries.length : self.candidates_countries.reject{|r| r.marked_for_destruction?}.length
    #self.errors.add_to_base(I18n.translate('activerecord.errors.full_messages')[:nationality_presence]) if countries_count == 0
    self.errors.add_on_blank(:nationality) if countries_count == 0
  end
  # validation
  def presence_of_degree
    degrees_count = self.new_record? ? self.degrees.length : self.degrees.reject{|r| r.marked_for_destruction?}.length
    self.errors.add_to_base(I18n.translate('activerecord.errors.full_messages')[:degree_presence]) if degrees_count == 0
  end
  
  def set_degrees_candidate
    self.degrees.each {|j| j.candidate = self}
  end
  
  # before_save
  def maintain_status
    if self.status_completed_registration_step_2? || self.skip_registration_steps || self.status_system_accepted? || self.status_system_rejected? 
      mark_as_accepted_or_rejected
      #NOTE dont remove the following line, this is such that candidates created 
      #by the test Factory will work normally afterwards
      self.skip_registration_steps = nil
    elsif self.status_completed_registration_step_1?
      self.status_id = Status[:completed_registration_step_2]
    elsif self.new_record?
      self.status_id = Status[:completed_registration_step_1]
    end
    true
  end
  
  # before_save with 2 responsibilities
  # 1. hack into sunspot to provide conditions if this instance should be indexed
  # 2. mark the instance for removal from solr index if necessary
  # NOTE: should happen after Candidate#maintain_status 
  def maintain_solr_existence
    @marked_for_auto_indexing = @marked_for_auto_indexing && self.completed_registration_steps > 2
    #@marked_for_index_removal = (self.status_id_changed? && self.status_id_was == Status[:system_accepted] && !self.status_system_accepted?)
    true
  end
  
  # after_save 
  #  def may_be_remove_from_solr
  #    self.remove_from_index if @marked_for_index_removal
  #    remove_instance_variable(:@marked_for_index_removal)
  #    true
  #  end
  
  #after_save
  def update_applications
    self.vacancies.each {|v| v.update_application(self) }
  end
  
  #before_validation
  def may_be_nullify_some_attributes
    attrs = [:iqama_id, :saudi_mother, :saudi_spouse]
    attrs_changed = attrs.inject(false) {|acc,attr| acc || send("#{attr}_changed?")}
    if attrs_changed && self.country_ids.include?(Country.saudi_arabia.id)
      attrs.each {|attr| self.send("#{attr}=", nil)}
    end
    true
  end
  
  #before_validation
  def convert_artificial_attributes_to_booleans
    [:has_saudi_contacts, :confirmation].each do |attr|
      v = self.send(attr)
      self.send("#{attr}=", !!(v =~ /(yes|1|true)/)) if !v.blank? && ![TrueClass, FalseClass].include?(v.class) 
    end
    true
  end
  
  #before_validation
  def collect_phones_parts
    if self.saudi_phone_code && self.saudi_phone_number
      self.saudi_phone = self.saudi_phone_code + self.saudi_phone_number
    end
    if self.residence_phone_code && self.residence_phone_number
      self.residence_phone = self.residence_phone_code + self.residence_phone_number
    end
  end
  
  def saudi_contacts_info_changed?
    change = true
    self.class.saudi_contacts_attributes.each {|x| change = change && self.changed.include?(x.to_s)}
    change
  end
  
  #before_validation
  def process_saudi_contacts_info
    #if saudi_contacts_info_changed? && !self.has_saudi_contacts
    if !self.has_saudi_contacts
      self.class.saudi_contacts_attributes.each {|attr| self.send("#{attr}=", nil)}
    end
  end
  
  #validation
  def presence_of_entry_level
    if self.completed_registration_steps > 1
      self.errors.add(:entry_level, I18n.translate('activerecord.errors.messages')[:blank]) if self.entry_level.nil?
    end
  end
  
  #validation
  def confirmation_of_info
    if self.status_completed_registration_step_2? && self.confirmation != true
      self.errors.add_to_base(I18n.translate('activerecord.errors.full_messages')[:no_confirmation])
    end
  end
  
  #after_save
  def handle_block_status
    if self.status_id_changed?
      # comments
      self.comments.update_all "status_id = #{self.blocked? ? Comment::Status[:hidden].id : Comment::Status[:visible].id}"
      
      # force each vacancy to save which will force saving
      # applications and interviews connections and updating 
      # ther visibility
      self.vacancies.each {|v| v.save! }
    end
  end
end

