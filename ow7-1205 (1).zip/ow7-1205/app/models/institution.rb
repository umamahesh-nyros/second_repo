class Institution < ActiveRecord::Base
  # NOTE: Keep those the same as in the seeds
  Names = {:kfupm => "KING FAHD University of Petroleum & Minerals",
           :dmc => "Dammam Community College",
           :ipa => "Institute of Public Administration",
           :hacc =>  "Hafr Al-Batin Community College"}
  
  # NOTE: if these ids ever change please modify them accordingly in
  # employers_candidates.js Autocompleter
  TypesInfo = {:other => {:id => 0, :name => "Other"},
               :university =>{:id => 1, :name => "University"}}
  TypesC = Constants.new(TypesInfo)
  Types = {}; TypesC.all.each {|c| Types[c.sym_id] = c.id}
  # TODO ivy_league should be removed from rankings... but first, seeds must be re run in order
  # to assign new values to ranking_id
  Rankings = Constants.new({:ivy_league => {:id => 0, :name => "Ivy League", :style_class => "top-1"},
                            :top100 => {:id => 1, :name => "Top 100", :style_class => "top-2"},
                            :top400 => {:id => 2, :name => "Top 400", :style_class => "top-3"}, 
                            :other => {:id => 3, :name => "Other", :style_class => nil}})
  
  IvyLeague = Constants.new({:ivy_league => {:id => 0, :name => "Ivy League", :style_class => "top-1"}})[:ivy_league]
  
  AdderTypes = Constants.new({:system => {:id => 0, :name => "System"},
                              :other => {:id => 1, :name => "Other"}})
  GroupsInfo = {
    :other => {:id => 0, :name => "Other"},
    #Universities
    :us_unis => {:id => 1, :name => "U.S. Universities"},
    :eu_unis => {:id => 2, :name => "U.K. & West European Universities"},
    :au_unis => {:id => 3, :name => "Australian Universities"},
    :kfupm_unis => {:id => 4, :name => "K.F.U.P.M.", :tooltip => "King Fahd University of Petroleum & Minerals in Dhahran, "+
                                                                 "Saudi Arabia. Well-known amongst Saudi recruiters & businessmen to be "+
                                                                 "the No.1. University for Engineering, Business & Science Graduates"},
    :sa_en_unis => {:id => 5, :name => "English Universities in Saudi Arabia", :tooltip => "Like C.B.A., Prince Sultan University, Prince Mohammed Bin Fahd University"},
    :sa_ar_unis => {:id => 6, :name => "Arabic Universities in Saudi Arabia", :tooltip => "Like Imam University, Um Al-Qura University"},
    #Institutions
    :ipa_ins => {:id => 7, :name => "I.P.A.", :tooltip => "Institute of Public Administration, is well known amongst recruiter to be "+
                                                          "the No.1 source for Diploma level secretaries, accountants, IT staff, and "+
                                                          "other specialities"},
    :us_ins => {:id => 8, :name => "U.S. Institutions"},
    :au_ins => {:id => 9, :name => "Australian Institutions"},
    :dmc_ins => {:id => 10, :name => "Dammam Community College"},
    :hacc_ins => {:id => 11, :name => "Hafr Al-Batin Community College"},
    :sa_ar_ins => {:id => 12, :name => "Arabic Institutions in Saudi Arabia"},
  }
  Groups = {}; GroupsInfo.each_pair {|k,v| Groups[k] = v[:id]}
  
  attr_protected :adder_type_id
  
  #--Validations--#  
  validates_presence_of :name
  validates_presence_of :country_id
  validates_presence_of :type_id
  validates_inclusion_of :ranking_id, :in => Rankings.all.collect {|r| r.id}
  validates_presence_of :adder_type_id, :in => AdderTypes.all.collect {|r| r.id}
  
  #--Associations--#
  belongs_to :country
  belongs_to :language
  has_many :degrees, :dependent => :delete_all
  has_many :candidates, :through => :degrees
  
  #--Callbacks--#
  before_save :maybe_set_language_id
  before_save :set_ranking_id
  
  #--Named Scopes--#
  Types.each_pair do |k,v|
    named_scope "type_#{k}", :conditions => "type_id=#{v}"
  end
  
  AdderTypes.all.each do |at|
    named_scope "adder_type_#{at.sym_id}", :conditions => {:adder_type_id => at.id}
  end
  
  searchable do
    integer :instance_id, :using => :id
    string(:name) { name.downcase }
    text :name
    integer :type_id
    integer :adder_type_id
  end
  
  #--Class Methods--#
  def self.filter_search(q = {}, page = 1, per_page = 10)
    solr_search do
      fulltext(q[:keywords]) unless q[:keywords].blank?
      with(:adder_type_id, q[:adder_type_id]) if q[:adder_type_id]
      paginate :page => page, :per_page => per_page
    end
  end
  
  def self.for_adder(adder_type)
    if adder_type == Institution::AdderTypes[:system].sym_id.to_s
      self.adder_type_system
    elsif adder_type == Institution::AdderTypes[:other].sym_id.to_s
      self.adder_type_other
    else
      self
    end
  end
  
  def self.merge!(id, ids)
    id = id.to_i
    ids = ids.collect {|i| i.to_i}.select {|i| i!= id}
    
    self.transaction do
      #NOTE this is as ineffecient as it gets... no direct workaround!
      Degree.update_all(Degree.send(:sanitize_sql_for_assignment, {:institution_id => id}),
                        {:institution_id => ids})
      Institution.destroy_all({:id => ids})
      Institution.find(id).solr_reindex_candidates
    end
  end
  
  #--Instance Methods--#
  AdderTypes.all.each do |at|
    define_method("adder_type_#{at.sym_id}?") {self.adder_type_id == at.id}
  end
  Types.each_pair do |k,v|
    define_method("type_#{k}?") {self.type_id == v}
  end
  Rankings.all.each do |r|
    define_method("ranking_#{r.sym_id}?") {self.ranking_id == r.id}
  end
  
  def ranking
    Rankings.find_by_id(self.ranking_id)
  end
  
  def group_ids
    return @gids if @gids
    @gids = []
    if self.type_university?
      if Country.united_states.include?(self.country)
        @gids << Groups[:us_unis]
      elsif Country.western_europe.include?(self.country)
        @gids << Groups[:eu_unis]
      elsif Country.australia.include?(self.country)
        @gids << Groups[:au_unis]
      elsif Country.saudi_arabia == self.country
        @gids << Groups[:sa_en_unis] if self.language.try(:is_english?)
        @gids << Groups[:sa_ar_unis] if self.language.try(:is_arabic?)
      end
      @gids << Groups[:kfupm_unis] if self.name == Names[:kfupm]
    elsif self.type_other?
      if Country.united_states.include?(self.country)
        @gids << Groups[:us_ins]
      elsif Country.australia.include?(self.country)
        @gids << Groups[:au_ins]
      elsif Country.saudi_arabia == self.country && self.language.try(:is_arabic?)
        @gids << Groups[:sa_ar_ins]
      end
      if self.name == Names[:dmc]
        @gids << Groups[:dmc_ins]
      elsif self.name == Names[:ipa]
        @gids << Groups[:ipa_ins]
      elsif self.name == Names[:hacc]
        @gids << Groups[:hacc_ins]
      end
    end
    @gids << Groups[:other] if @gids.length == 0
    @gids
  end
  
  def autocomplete_hash
    {:name => self.name, :value => self.id}
  end
  
  
  def safe_destroy
    if self.degrees.size > 0
      self.errors.add_to_base(I18n.t('activerecord.errors.models.institution.has_degrees'))
      return false
    else
      self.destroy
    end
  end
  
  def solr_reindex_candidates
    #NOTE isnt there someway to batch index those?!
    self.candidates.find_each {|c| c.solr_index}
  end
  
  #########
  protected
  #########
  
  # before_save
  def maybe_set_language_id
    self.language_id = self.country.degree_language_id if self.language_id.blank? && self.country
  end
  
  # before_save
  def set_ranking_id
    self.global_rank = 0 if self.global_rank.blank?
    self.ranking_id = if self.global_rank == 0
      Institution::Rankings[:other].id
    elsif self.global_rank <= 100
      Institution::Rankings[:top100].id
    elsif self.global_rank <= 400
      Institution::Rankings[:top400].id
    else
      Institution::Rankings[:other].id
    end
  end
end
