class CandidateSession < Authlogic::Session::Base
  generalize_credentials_error_messages "Your login information is invalid"
  before_save :should_mark_no_status_maintainance
  
  #########
  protected
  #########
  
  def should_mark_no_status_maintainance
    self.record.should_maintain_status = false
  end
end