class Admin < ActiveRecord::Base
  @@password_chars = ("a".."z").to_a + ("A".."Z").to_a + ("0".."9").to_a
  #--Authentication--#
  acts_as_authentic do |config|
    config.disable_perishable_token_maintenance = true
  end
  
  #--Attributes--#
  attr_protected :crypted_password, :password_salt, :persistence_token,
                 :single_access_token, :perishable_token, :email, :password
  attr_accessor :code
  attr_accessor :old_password
  attr_accessor :check_old_password
  attr_accessor :skip_activation
                   
  #--Assoications--#
  has_many :articles, :as => :creator, :dependent => :destroy
  has_many :events, :as => :creator, :dependent => :destroy
  has_many :invitations, :dependent => :nullify

  #--Callbacks--#
  before_validation_on_create :generate_password
  after_create :send_email!
  validates_each :old_password, :if => Proc.new {|u| !u.new_record? && !u.password.nil? && u.check_old_password} do |record, field, value|
    if record.old_password.nil? || Authlogic::CryptoProviders::Sha512.encrypt(record.old_password + record.password_salt_was) != record.crypted_password_was
      record.errors.add(:old_password, I18n.translate('activerecord.errors.models.admin')[:old_password])
    end
  end
  
  #--Class Methods--#
    
  #--Instance Methods--#
  
  def super?
    self.super_admin?
  end
    
  def deliver_password_reset_instructions!
    # password resets controller is handling not sending this email
    # if the user email is not yet activated
    reset_perishable_token!
    AdminMailer.deliver_password_reset_instructions(self)
  end

  def change_password(old_password, new_password)
    unless old_password.blank? && new_password.blank?
      self.check_old_password = true
      self.old_password = old_password
      self.password = self.password_confirmation = new_password
    end
  end
  
  #########
  protected
  #########

  #######
  #private
  #######
  def generate_password
    unless self.skip_activation
      i = 0
      while i < 25
        i += 1
        self.code = ""
        1.upto(10) { |j| self.code << @@password_chars[rand(@@password_chars.size-1)] }
      end
      self.password_confirmation = self.password = self.code
    end
  end

  def send_email!
    unless self.skip_activation
      reset_perishable_token!
      AdminMailer.deliver_activation_instructions(self)
    end
  end
  
end
