class Category < ActiveRecord::Base
  Levels = {:a => 0, :b => 1}
  
  #--Validations--#
  validates_presence_of :name
  validates_presence_of :level_id
  validate :no_more_than_2nd_level
  
  #--Associations--#
  belongs_to :parent, :class_name => "Category", :foreign_key => "parent_id"
  has_many :subs, :class_name => "Category", :foreign_key => "parent_id"
  
  #--Named Scopes--#
  named_scope :type_parent, :conditions => "parent_id is null"
  named_scope :type_sub, :conditions => "parent_id is not null"
  Levels.each do |k,v|
    named_scope "level_#{k}", :conditions => {:level_id => v}
  end
  
  #--Class Methods--#
  
  # parent: true for parents, false for sub
  # level: "a" or "b" or nil
  def self.sorted(parent, level)
    x = parent ? self.type_parent : self.type_sub
    x = x.send("level_#{level}") if level
    x.all.sort do |a,b|
      if a.name == "Other"
        1
      elsif b.name == "Other"
        -1
      else
        a.name <=> b.name
      end
    end
  end
  
  #--Instance Methods--#
  Levels.each do |k,v|
    define_method "level_#{k}?", lambda { level_id == v}
  end
  
  def parent?
    self.parent_id.blank?
  end
  
  def sub?
    !self.parent_id.blank?
  end
  
  #########
  protected
  #########
  
  def no_more_than_2nd_level
    errors.add_to_base(I18n.t("activerecord.errors.full_messages.category_2_levels_only")) if self.parent_id && self.parent.parent_id
  end
end
