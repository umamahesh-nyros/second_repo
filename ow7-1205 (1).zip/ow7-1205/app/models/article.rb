class Article < ActiveRecord::Base
  Creators = [Admin, Employer]
  Status = Constants.new(:draft => {:id => 0, :name => "Draft"},
                         :published => {:id => 1, :name => "Published"},
                         :blocked => {:id => 2, :name => "Blocked"})
  
  #--Validations--#
  validates_inclusion_of :status_id, :in => Status.all.collect {|s| s.id}
  validates_inclusion_of :creator_type, :in => Creators.collect {|c| c.name}
  validates_presence_of :creator_id
  validates_presence_of :title
  validates_presence_of :body
  
  #--Attachments--#
  has_attached_file :image,
                    :path => ":rails_root/public/news/:attachment/:id/:style.:extension",
                    :url => "/news/:attachment/:id/:style.:extension",
                    :styles => {
                      :tiny => "35x35",
                      :small => "55x55",
                      :medium => "150x100",
                      :large =>   "300x200"
  }
  validates_attachment_size :image, :less_than => 1.megabytes
  validates_attachment_content_type :image, :content_type => ['image/bmp', 'image/jpeg', 'image/pjpeg', 'image/gif', 'image/png', 'image/x-png', 'image/jpg']
  
  #--Associations--#
  belongs_to :creator, :polymorphic => true
  has_many :comments, :as => :commentable, :dependent => :delete_all
  
  #--Callbacks--#
  before_save :maintain_published_at
  
  #--Named Scopes--#
  Status.all.each do |s|
    named_scope "status_#{s.name.underscore}", :conditions => {:status_id => s.id}
  end
  named_scope :scope_for, lambda {|user|
    if user.is_a?(Admin)
      {:conditions => {:creator_type => Admin.name}}
    elsif user.is_a?(Employer)
      {:conditions => {:creator_type => Employer.name, :creator_id => user.id}}
    else
      raise ArgumentError, "Unsupported user type"
    end
  }
  
  
  Creators.each do |klass|
    named_scope "creator_#{klass.name.underscore}", :conditions => {:creator_type => klass.name}
  end
  
  #--Class Methods--#
  def self.mass_destroy_for(user, ids)
    scope_for(user).destroy_all(["id in (?)", (ids.map &:to_i)])
  end
  
  def self.mass_publish_for(user, ids)
    #TODO if we introduce blocking make sure to choose those that are not blocked
    scope_for(user).update_all("status_id = #{Status[:published].id}", ["id in (?)", (ids.map &:to_i)])
  end
  
  def self.mass_draft_for(user, ids)
    #TODO if we introduce blocking make sure to choose those that are not blocked
    scope_for(user).update_all("status_id = #{Status[:draft].id}", ["id in (?)", (ids.map &:to_i)])
  end
  
  #--Instance Methods--#
  Status.all.each do |s|
    define_method("status_#{s.name.underscore}?") {self.status_id == s.id}
    define_method("make_status_#{s.name.underscore}") {self.status_id = s.id; self.save}
  end
  
  def viewable_by?(user)
    self.status_published? || user.is_a?(Admin) || self.creator == user
  end
  
  def editable_by?(user)
    self.creator.is_a?(Admin) && user.is_a?(Admin) || self.creator == user
  end
  
  #########
  protected
  #########
  
  def maintain_published_at
    self.published_at = Time.now if self.status_id_changed? && self.status_published?
  end
  
end
