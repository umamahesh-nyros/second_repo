class Country < ActiveRecord::Base
  WesternEuropeISOs = ["AT","BE","DK","FI","FR","DE",
                       "IS","IE","IT","LU","NL","NO","PT",
                       "ES","SE","CH","GB"]
  
  #--Associations--#
  has_many :cities, :dependent => :destroy
  belongs_to :degree_language, :class_name => "Language"
  
  #--Named Scopes--#
  named_scope :united_states, :conditions => {:iso => "US"}
  named_scope :western_europe, :conditions => "iso in (#{WesternEuropeISOs.collect {|x| "'#{x}'"}.join(',')})"
  named_scope :australia, :conditions => {:iso => "AU"}
  
  #--Search--#
  searchable do
    integer :instance_id, :using => :id
    string(:name) { printable_name.downcase }
  end
  
  def self.saudi_arabia
    @saudi_arabia||=find_by_iso("SA")
  end
  
  def dialing_codes
    @dialing_codes ||= [dialing_code_1, dialing_code_2, dialing_code_3].reject {|x| x.nil? }
  end
  
  def nationality
    self.printable_name
  end
  
  def autocomplete_hash
    @autocomplete_hash ||= {:name => self.printable_name, :value => self.id, :dialing_codes => self.dialing_codes}
  end
  
  def saudi_arabia?
    self.id == self.class.saudi_arabia.id
  end
end
