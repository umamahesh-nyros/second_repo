class CandidatesSection < ActiveRecord::Base
  set_table_name "candidates_sections"
  belongs_to :candidate
  belongs_to :section

  validates_presence_of :section_id
  validates_presence_of :candidate_id
end
