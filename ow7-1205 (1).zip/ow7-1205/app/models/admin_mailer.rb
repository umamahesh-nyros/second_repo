class AdminMailer < ActionMailer::Base
  layout 'email'

  def password_reset_instructions(admin)
    setup_email
    subject       I18n.t('email.password_reset_instructions.subject')
    recipients    admin.email
    body          :password_reset_url => edit_admins_password_reset_url(admin.perishable_token), :admin => admin
  end

  def activation_instructions(admin)
    setup_email
    subject       I18n.t('email.admins.activation_instructions.subject')
    recipients    admin.email
    body          :password_reset_url => edit_admins_password_reset_url(admin.perishable_token), :admin => admin
  end
  
  def setup_email
    content_type "text/html"
    from AppConfig.from_no_reply
    sent_on Time.now
  end
end
