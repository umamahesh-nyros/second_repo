class Invitation < ActiveRecord::Base
  @@code_chars = ("a".."z").to_a + ("A".."Z").to_a + ("0".."9").to_a
  
  #--Attributes--#
  @@types = {:employer => 1, :ngo => 2}
  cattr_accessor :types
  attr_accessor :message
  
  #--Validations--#
  validates_uniqueness_of :code
  validates_inclusion_of :type_id, :in => @@types.values
  validates_format_of :email, :with =>  Authlogic::Regex.email, :message => I18n.t('activerecord.errors.messages.invalid_email')
  with_options :if => lambda {|r| r.type_employer_or_ngo?} do |i|
    i.validates_presence_of :first_name
    i.validates_presence_of :last_name
  end
  
  #--Associations--#
  belongs_to :invited, :polymorphic => true
  belongs_to :admin
  
  #--Named Scopes--#
  named_scope :used, :conditions => "invited_id IS NOT NULL"
  named_scope :unused, :conditions => "invited_id IS NULL"
  @@types.each_pair do |k,v|
    named_scope "type_#{k}", :conditions => {:type_id => v}
  end
  named_scope :type_employer_or_ngo, :conditions => {:type_id => [@@types[:employer], @@types[:ngo]]}
  
  #--Callbacks--#
  before_validation_on_create :generate_code
  after_create :send_email
  
  #--Class Methods--#
  def self.filter_search(q = nil, page = 1, per_page = 10)
    filter = q && q[:filter]
    if filter && [:used, :unused].include?(filter.to_sym)
      order = q[:order] == 'asc' ? :ascend_by_created_at : :descend_by_created_at
      Invitation.send(filter).send(order).paginate :page => page, :per_page => per_page
    else
      Invitation.descend_by_created_at.paginate :page => page, :per_page => per_page
    end
  end
  
  #--Instance Methods--#
  @@types.each_pair do |k,v|
    define_method("type_#{k}?") { self.type_id == v}
  end
  def type_employer_or_ngo?
    self.type_employer? || self.type_ngo?
  end
  
  def name
    "#{self.first_name} #{self.last_name}"
  end
  
  def used?
    !self.unused?
  end
  
  def unused?
    invited_id.blank?
  end
  
  #######
  private
  #######
  
  def generate_code
    i = 0
    while i < 25 && (self.code.blank? || self.class.exists?(:code => self.code))
      i += 1
      self.code = ""
      1.upto(10) { |j| self.code << @@code_chars[rand(@@code_chars.size-1)] }
    end
  end
  
  def send_email
    case self.type_id
      when @@types[:employer], @@types[:ngo] 
      InvitationMailer.deliver_employer_invitation(self)
    else
      raise Exception, I18n.t('activerecord.invitation.unsupported_type')
    end
  end
end
