
class JobsSection < ActiveRecord::Base
  set_table_name "jobs_sections"
  belongs_to :job
  belongs_to :section

  validates_presence_of :section_id
  validates_presence_of :job_id
end
