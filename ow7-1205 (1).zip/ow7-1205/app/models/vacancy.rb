class Vacancy < ActiveRecord::Base
  Status = Constants.new(:visible => {:id => 0},
                         :hidden => {:id => 1})
  Ratings = Constants.new(:one => {:name => "1", :value => 1},
                         :two => {:name => "2", :value => 2},
                         :three => {:name => "3", :value => 3},
                         :four => {:name => "4", :value => 4},
                         :five => {:name => "5", :value => 5})
  acts_as_commentable
  acts_as_rateable
  
  attr_protected :hot, :removed, :job_id
  
  #--Validations--#
  validates_presence_of :city_id
  #TODO: should find an alternative to using validates_presence_of for job_id
  #validates_presence_of :job_id
  
  #--Associations--#
  belongs_to :job
  belongs_to :city
  has_many :applications, :class_name => 'Vacancies::Application', :dependent => :delete_all
  has_many :visible_applications, :class_name => 'Vacancies::Application', :foreign_key => "vacancy_id",
           :conditions => {:status_id => Vacancies::Application::Status[:visible].id}
  has_many :candidates, :through => :applications
  has_many :interviews, :dependent => :destroy, :class_name => "Interviews::Interview"
  has_many :connections, :through => :interviews, :class_name => "Interviews::Connection"
  has_many :slots, :through => :interviews, :class_name => "Interviews::Slot"
  has_many :jobs_section, :through => :job, :class_name => "JobsSection", :foreign_key => "job_id"
  has_many :sections, :through =>:jobs_section, :class_name => "Section"
  
  #--Callbacks--#
  before_validation :nullify_removal_reason
  after_save :update_applications!
  after_save :update_connections!
  
  #--Search--#
  searchable do
    integer :instance_id, :using => :id
    integer :job_id
    integer :city_id
    integer :type_id
    integer :section_id, :multiple => true
    integer :employer_id
    integer :degree_language_class_id
    integer :saudi_status_ids, :multiple => true
    integer :gender_ids, :multiple => true
    integer :job_mixing_id
    integer :degrees_group_ids, :multiple => true
    integer :degrees_institution_ids, :multiple => true
    integer :degrees_country_ids, :multiple => true
    integer :degrees_category_ids, :multiple => true
    integer :degrees_level_ids, :multiple => true
    integer :degrees_category_ids, :multiple => true
    
    boolean :removed
    boolean :hot
    boolean :reported
    integer :reports
    string :title
    string :city_name
    integer :status_id
    date :created_at
    boolean :offline
    integer :views
  end
  
  #--Class Methods--#
  def self.filter_search(q, options={})
    q = q && q.clone
    # instance_id for sorting is a last resort where vacancies of the same
    # title, city are sorted differently at each request
    os = {:order_by => [{:key => :created_at, :direction => :desc}, :title, :city_name, :instance_id], :default_direction => :asc}.merge(options)
    user = os[:user]
    filter = os[:filter]
    page = os[:page]
    per_page = os[:per_page]
    
    if user.is_a?(Admin)
      case filter
        when "removed"
        q[:removed] = [true]
        when "published"
        q[:removed] = [false]
        when "hot"
        q[:hot] = [true]
        when "reported"
        q[:reported] = [true]
        os[:order_by] = [{:key => :reports, :direction=> :desc}, {:key => :created_at, :direction=> :desc}, :title, :city_name, :instance_id]
        os[:default_direction] = :asc
      end
    else
      q[:removed] = [false]
    end
    
    # Eager load job
    solr_search(:include => [{:job => [:employer]}, :city, :jobs_section]) do
      all_of do
        with(:status_id, Vacancy::Status[:visible].id) unless user.is_a?(Admin)
        with(:offline, false)
        q.each_pair do |k,v|
          non_empty_v = Array(v).reject {|x| x.blank? && x.class != FalseClass}
          with(k).any_of(non_empty_v) if non_empty_v.length > 0
        end
      end
      
      Array(os[:order_by]).each { |o| o.is_a?(Hash) ? order_by(o[:key], o[:direction]) : order_by(o, os[:default_direction]) }
      paginate(:page => page || 1, :per_page => per_page || 10) if page || per_page
    end
  end
  
  def self.for_candidate(candidate, options={})
    os = {:page => 1, :per_page => 10}.merge(options)
    
    # TODO factors to be taken into consideration?
    # job start date? (couldn't find any data for it)
    
    solr_search(:include => [{:job => [:employer]}, :city]) do
      all_of do
        with(:status_id, Vacancy::Status[:visible].id)
        any_of do
          with(:type_id).any_of(candidate.job_type_ids)
          with(:city_id).any_of(candidate.job_city_ids)
        end
        with(:offline, false)
        with(:created_at).greater_than(1.month.ago)
        any_of do
          with(:degree_language_class_id, candidate.degree_language_class_id)
          with(:degree_language_class_id, nil)
        end
        any_of do
          with(:saudi_status_ids, candidate.saudi_status_id)
          with(:saudi_status_ids, nil)
        end
        [:degrees_group_ids, :degrees_institution_ids,
         :degrees_country_ids, :degrees_category_ids,
         :degrees_level_ids].each do |k|
          any_of do
            with(k).any_of(candidate.send(k))
            with(k, nil)
          end if candidate.send(k).length > 0
        end
        any_of do
          all_of do
            with(:gender_ids, candidate.gender_id)
            with(:job_mixing_id, candidate.job_mixing_id) if candidate.gender_female?
          end
          with(:gender_ids, nil)
        end
        #TODO what if he applied for a huge number of jobs?
        without(:instance_id).any_of(candidate.vacancy_ids) if candidate.vacancy_ids.length > 0
      end
      paginate :page => os[:page], :per_page => os[:per_page]
    end
  end
  
  def self.rateable_by?(user)
    user.is_a?(Candidate)
  end

  #--Instance Methods--#
  def full_title
    "#{self.title} (#{self.city.name})"
  end

  def section_id
    ids = []
    j = Job.find_by_id(self.job_id)
    j.sections.each do |s|
      ids << s.id
    end
    ids
  end
  
  def rateable_by?(user)
    self.class.rateable_by?(user)
  end
  
  def status_id
   (self.removed || self.employer.blocked?) ? Vacancy::Status[:hidden].id : Vacancy::Status[:visible].id
  end
  
  Status.all.each do |s|
    define_method("status_#{s.sym_id}?") { self.status_id == s.id }
  end
  
  [:editable_by?, :ngo, :company_name, :company_logo, :application_url, :offline].each do |m|
    delegate m, :to => :job  
  end
  
  def viewable_by?(user)
    self.status_visible? || user.is_a?(Admin) || self.employer == user
  end
  
  def add_application!(candidate)
    raise "applied" if self.applications.find_by_candidate_id(candidate.id)
    application = self.applications.build(:candidate => candidate)
    application.save!
    return application
  end
  
  def update_application(candidate)
    application = self.applications.find_by_candidate_id(candidate.id)
    if application
      #force run callbakcs to update screening and status
      application.save
      return application
    end
  end
  
  [:title, :description,:weekend_id, :weekend,:employer_id, :employer,
   :type_id, :type].each {|a| delegate a, :to => :job}
  
  def city_name
    self.city.name
  end
  
  # TODO should be refactored to use Job::DefaultFilters
  # when it's completed
  # Job Filters
  [:saudi_status_ids, :gender_ids, :job_mixing_id,
   :degree_language_class_id, :degrees_group_ids,
   :degrees_institution_ids, :degrees_country_ids,
   :degrees_level_ids, :gpa_range_ids
  ].each do |k|
    define_method(k) {k.to_s =~ /id$/ ? self.job.filter(k).first : self.job.filter(k)}
  end
  
  def degrees_category_ids
    ids = self.job.filter(:degrees_category_ids)
    if ids.length > 0
      Category.find_all_by_id(self.job.filter(:degrees_category_ids)).collect {|c| [c.id, c.parent_id]}.flatten.uniq.reject {|d| d.nil? }
    else
      []
    end
  end
  
  def reported
    self.reports > 0
  end
  
  def report
    self.reports += 1
    self.save!
  end
  
  def published
    !self.removed
  end

  def viewed
    self.views += 1
    self.save!
  end
  
  # define methods for individual and mass setting of booleans
  {:heat => :hot , :remove => :removed}.each do |action, field|
    define_method("#{action}") { self[field] = true; self.save }
    define_method("un#{action}") { self[field] = false; self.save }
    
    metaclass.instance_eval do
      define_method("mass_#{action}") do |ids|
        vs = self.all(:conditions => {:id => ids})
        self.transaction do
          vs.each {|v| v.send("#{action}")}
        end
        vs
      end
      
      define_method("mass_un#{action}") do |ids|
        vs = self.all(:conditions => {:id => ids})
        self.transaction do
          vs.each {|v| v.send("un#{action}")}
        end
        vs
      end
      
    end
  end
  
  def clear_reports
    self.reports = 0
    self.save
  end
  
  def self.mass_clear_reports(ids)
    vs = self.all(:conditions => {:id => ids})
    self.transaction do
      vs.each {|v| v.clear_reports}
    end
    vs
  end
  
  
  def destroy_job_if_last
    destroyed = self.destroy
    self.job.destroy if destroyed && self.job.vacancies.empty?
    return destroyed
  end
  
  #########
  protected
  #########
  
  # before_validation
  def nullify_removal_reason
    self.removal_reason = nil if !self.removed
  end
  
  # after_save
  def update_applications!
    # force saving of all applications to allow the applications
    # callbacks to set screening and status_id
    self.applications.all(:include => [:candidate, :job]).each {|a| a.save!}
  end
  
  # after_save
  def update_connections!
    self.connections.all(:include => [:candidate]).each do |c|
      should_hide = self.status_hidden? || c.candidate.blocked? || self.employer.blocked?
      c.status_id = should_hide ? Interviews::Connection::Status[:hidden].id : Interviews::Connection::Status[:visible].id  
      c.save! if c.status_id_changed?
    end
  end
end