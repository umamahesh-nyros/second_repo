class Candidates::JobCity < ActiveRecord::Base
  set_table_name :candidates_job_cities

  #--Validations--#
  validates_presence_of :city_id
  validates_presence_of :candidate_id
  
  #--Associations--#
  belongs_to :candidate
  belongs_to :city
end
