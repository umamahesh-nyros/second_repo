class Candidates::JobType < ActiveRecord::Base
  set_table_name :candidates_job_types

  #--Validations--#
  validates_presence_of :job_type_id
  validates_presence_of :candidate_id
  
  #--Associations--#
  belongs_to :candidate
  belongs_to :job_type, :class_name => 'Jobs::Type'
end
