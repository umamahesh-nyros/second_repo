class Candidates::Country < ActiveRecord::Base
  set_table_name :candidates_countries
  
  #--Validations--#
  validates_presence_of :country_id
  validates_presence_of :candidate_id
  
  #--Associations--#
  belongs_to :candidate
  belongs_to :country, :class_name => '::Country'
end
