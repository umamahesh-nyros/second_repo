class TextMessage < ActiveRecord::Base
  validates_presence_of :to
  validates_presence_of :body
  validate :validate_phone_numbers
  
  attr_accessor_with_default :number_errors, {}
  
  def self.send_message(numbers, body)
    self.create(:numbers => numbers, :body => body)
    #self.create(:to => Array(numbers).collect {|n| n.to_s.gsub(/^(00|\+)/, '')}.join(","), :body => body)
  end
  
  def numbers=(array)
    self.to = array.is_a?(Array) ? numbers_to_s(array) : ""
  end
  
  def numbers
    self.to ? string_to_numbers(self.to) : []
  end
  
  def self.process(limit = 100)
    finder = ascend_by_id
    finder = finder.all(:limit => limit) if limit
    finder.each do |tm|
      tm.destroy if SMSSender.send_message tm.to, tm.body
    end
  end
  
  private
  
  def numbers_to_s(numbers)
    Array(numbers).reject(&:blank?).collect {|n| n.to_s.gsub(/^(00|\+)/, '')}.join(",")
  end
  
  def string_to_numbers(string)
    string.split(',').reject(&:blank?)
  end

  def validate_phone_numbers
    if self.numbers.present?
      self.errors.add(:to, I18n.t('activerecord.errors.messages.invalid_phone')) unless phone_numbers_valid?(self.numbers)
    else
      self.number_errors[:blank] = true
    end
  end
  
  def phone_numbers_valid?(numbers)
    self.number_errors = {}
    numbers.inject(true) do |s, n|
      valid = Validator.phone_format_valid?(n)
      self.number_errors[n] = !valid
      s && valid
    end
  end
  
end
