ActionController::Routing::Routes.draw do |map|
  map.resources :institutions,
                :collection => {:mass_destroy => :delete,
                                :mass_adder_system => :put,
                                :merge => :put}
  
  map.namespace(:admins) do |admin|
    admin.resource :home, :controller => "home", :member => {:job_reports => :get, :candidate_reports => :get}
    admin.resource :session
    admin.resources :password_resets
    admin.resources :activations
    admin.login 'login', :controller => 'sessions', :action => 'new'
    admin.logout 'logout', :controller => 'sessions', :action => 'destroy'
  end
  map.resources :admins
  map.resources :invitations
  map.resources :enquiries
  
  map.connect '/autocomplete/:action', :controller => "autocomplete"
  
  map.resources :jobs
  map.resources :vacancies, 
                :collection => {:mass_heat => :put, :mass_unheat => :put,
                                :mass_remove => :put, :mass_unremove => :put,
                                :mass_clear_reports => :put},
                :member => {:apply => :put, :heat => :put, :unheat => :put,
                            :remove => :put, :unremove => :put, :report => :put, :clear_reports => :put,
                            :rate => :put, :sms => :put} do |vacancy|
    vacancy.resources :comments
    vacancy.resources :applications,
                      :collection => {:mass_short_list => :put, :mass_unshort_list => :put,
                                :mass_reject => :put, :mass_unreject => :put},
                      :member => {:short_list => :put, :unshort_list => :put, :reject => :put, :unreject => :put}
    vacancy.resources :interviews, :controller => "vacancies/interviews",
                      :collection => {:invite => :get}
    vacancy.resources :slots, :controller => "vacancies/slots"
  end
  
  map.namespace(:employers) do |employer|
    #employer.resource :home, :controller => "home"
    employer.resource :session
    employer.resources :password_resets
    employer.login 'login', :controller => 'sessions', :action => 'new'
    employer.logout 'logout', :controller => 'sessions', :action => 'destroy'
  end
  
  map.resources :employers,
                :collection => {:mass_block => :put, :mass_unblock => :put},
                :member => {:block => :put, :unblock => :put,
                            :request_unblock => :put, :paying => :put, :non_paying => :put}
  
  map.namespace(:candidates) do |candidate|
    candidate.resource :home, :controller => "home"
    candidate.resource :session
    candidate.resources :password_resets
    candidate.resources :interviews
    candidate.login 'login', :controller => 'sessions', :action => 'new'
    candidate.logout 'logout', :controller => 'sessions', :action => 'destroy'
  end
  map.resources :candidates,
                :collection => {:register => :get, :complete_registration => :put,
                                :mass_block => :put, :mass_unblock => :put,
                                :mass_reject => :put, :mass_unreject => :put,
                                :mass_export => :get, :mass_export_application => :get},
                :member => {:block => :put, :unblock => :put, :reject => :put, :unreject => :put,
                            :request_unblock => :put}
                            
  map.resources :arabic_candidates
  
  map.resources :articles, :as => "news",
                :collection => {:manage => :get, :mass_destroy => :delete, :mass_publish => :put, :mass_draft => :put},
                :member => {:publish => :put, :draft => :put} do |article|
    article.resources :comments
  end
  
  map.resources :events,
                :collection => {:manage => :get, :mass_destroy => :delete, :mass_publish => :put, :mass_draft => :put},
                :member => {:publish => :put, :draft => :put} do |event|
    event.resources :comments
  end

  map.privacy 'privacy', :controller => 'welcome', :action => :privacy
  map.terms 'terms', :controller => 'welcome', :action => :terms
  map.about 'about', :controller => 'welcome', :action => :about
  map.contact 'contact', :controller => 'welcome', :action => :contact
  map.root :controller => 'welcome'
  
  # The priority is based upon order of creation: first created -> highest priority.
  
  # Sample of regular route:
  #   map.connect 'products/:id', :controller => 'catalog', :action => 'view'
  # Keep in mind you can assign values other than :controller and :action
  
  # Sample of named route:
  #   map.purchase 'products/:id/purchase', :controller => 'catalog', :action => 'purchase'
  # This route can be invoked with purchase_url(:id => product.id)
  
  # Sample resource route (maps HTTP verbs to controller actions automatically):
  #   map.resources :products
  
  # Sample resource route with options:
  #   map.resources :products, :member => { :short => :get, :toggle => :post }, :collection => { :sold => :get }
  
  # Sample resource route with sub-resources:
  #   map.resources :products, :has_many => [ :comments, :sales ], :has_one => :seller
  
  # Sample resource route with more complex sub-resources
  #   map.resources :products do |products|
  #     products.resources :comments
  #     products.resources :sales, :collection => { :recent => :get }
  #   end
  
  # Sample resource route within a namespace:
  #   map.namespace :admin do |admin|
  #     # Directs /admin/products/* to Admin::ProductsController (app/controllers/admin/products_controller.rb)
  #     admin.resources :products
  #   end
  
  # You can have the root of your site routed with map.root -- just remember to delete public/index.html.
  # map.root :controller => "welcome"
  
  # See how all your routes lay out with "rake routes"
  
  # Install the default routes as the lowest priority.
  # Note: These default routes make all actions in every controller accessible via GET requests. You should
  # consider removing or commenting them out if you're using named routes and resources.
  map.connect ':controller/:action/:id'
  map.connect ':controller/:action/:id.:format'

end
