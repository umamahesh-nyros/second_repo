if Rails.env == "development"
  WICKED_PDF = {
    #:wkhtmltopdf => '/usr/local/bin/wkhtmltopdf',
    :layout => "application.pdf.erb",
    #For windows, make sure no spaces in path
    :exe_path => '/Users/kai/Documents/workspace/mysvn/vendor/plugins/wicked_pdf/wkhtmltopdf-0.9.9-OS-X.i368'
    #:exe_path => 'C:\wkhtmltopdf\wkhtmltopdf.exe'
  }
else
    WICKED_PDF = {
    :wkhtmltopdf => '/usr/local/bin/wkhtmltopdf',
    :layout => "application.pdf.erb",
    :exe_path => '/usr/local/bin/wkhtmltopdf'
  }
end
