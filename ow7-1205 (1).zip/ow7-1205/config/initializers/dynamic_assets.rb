# if the required table exist, create the file, else
# it's creating the db for the first time while db:migrate
# so no need to create the javascript file
tables_exist = [Country].map(&:table_exists?).inject(true) {|acc,i| acc && i}
if tables_exist
  f = File.open(File.join(Rails.root, 'public', 'javascripts', 'constants.js'), "w")
  f.write <<-CODE
eSpace.require("OW7.Constants", {
  Gender: {male: #{Candidate::Gender[:male]}, female: #{Candidate::Gender[:female]}},
  SaudiArabia: #{(Country.saudi_arabia.try(:attributes) || {}).to_json},
  Flashes: #{ApplicationController::Flashes.to_json},
  DateFormats: #{ApplicationController::DateFormats.all.map {|c| {c.sym_id => c.string}}.inject({}) {|acc,h| acc.merge(h)}.to_json},
  DateRegexes: #{ApplicationController::DateFormats.all.map {|c| {c.sym_id => c.regex}}.inject({}) {|acc,h| acc.merge(h)}.to_json},
  ConfirmDeleteComment: #{I18n.t('confirm.delete.comment').to_json}
});
CODE
f.close
end
