class Hash
  def nested_try_get(*args)
    args.inject(self) {|acc, key| acc.try(:[], key)}
  end
end