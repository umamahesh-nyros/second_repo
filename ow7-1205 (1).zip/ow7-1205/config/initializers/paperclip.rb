Paperclip.interpolates :name do |attachment, style|
  attachment.instance.name.parameterize
end