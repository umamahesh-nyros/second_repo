require 'uri'

class Validator
  class << self
    # note: it appends http on the url if necessary
    def url_format_of(record, attr_name)
      return if record.send(attr_name).blank?
      record.send("#{attr_name}=", "http://#{record.send(attr_name)}") unless record.send(attr_name) =~ /^(http)/
      begin
        uri = URI.parse(record.send(attr_name))
        unless [URI::HTTP, URI::HTTPS].include? uri.class
          record.errors.add(attr_name, I18n.t('activerecord.errors.messages.invalid_url_http'))
        end
      rescue URI::InvalidURIError
        record.errors.add(attr_name, I18n.t('activerecord.errors.messages.invalid_url'))
      end
    end
    
    def phone_format_of(record, attr_name, options = {})
      attr_val = record.send(attr_name)
      return if attr_val.blank?
      #NOTE this is bad, but let's just live with it now
      record.send("#{attr_name}=", attr_val.gsub(/^(00|\+)/,""))
      record.errors.add(attr_name, I18n.t('activerecord.errors.messages.invalid_phone')) unless phone_format_valid?(attr_val, options)
    end
    
    def phone_format_valid?(phone, options = {})
      if options[:saudi]
        prefixes = Country.saudi_arabia.dialing_codes.join("|")
        prefixes = "(#{prefixes})" if prefixes.length > 0
      else
        prefixes = options[:country] ? options[:country].dialing_codes.join("|") : ""
        prefixes = "(#{prefixes})" if prefixes.length > 0
      end

      !!(phone =~ /^#{prefixes}\d{5,20}$/)
    end
    
  end
end
