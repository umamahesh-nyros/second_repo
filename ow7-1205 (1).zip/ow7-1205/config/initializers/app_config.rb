class AppConfig  
  def self.load
    config_file = File.join(Rails.root, "config", "application.yml")
    
    if File.exists?(config_file)
      yaml = YAML.load(File.read(config_file))
      config = yaml['default'] ? yaml['default'].merge(yaml[Rails.env]) : yaml[Rails.env]
      
      config.keys.each do |key|
        cattr_accessor key
        send("#{key}=", config[key])
      end
    end
  end
end
AppConfig.load

raise "server_host variable should be initialized in your application.yml" if !AppConfig.respond_to?(:server_host) || AppConfig.server_host.nil?
ActionMailer::Base.default_url_options[:host] = AppConfig.server_host

